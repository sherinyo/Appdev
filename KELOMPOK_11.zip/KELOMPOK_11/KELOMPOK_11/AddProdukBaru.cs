﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KELOMPOK_11
{
    public partial class AddProdukBaru : Form
    {
        MainPage mainPage;

        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        public string query;
        public AddProdukBaru(Form _sender)
        {
            InitializeComponent();
            mainPage = (MainPage) _sender;
            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = kelompok11");
        }

        private void AddProdukBaru_Load(object sender, EventArgs e)
        {

        }

        private void btn_save_addprodukbaru_Click(object sender, EventArgs e)
        {
            string namaprodukbaru = tb_namaprodukbaru.Text;
            string idprodukbaru = tb_idproduk.Text.ToUpper();
            string hargaprodukbaru = tb_hargaproduk.Text;
            string kategoriID = cb_kategoriID.SelectedItem?.ToString();
            int jumlahstok = Convert.ToInt32(numericUpDown_jumlahstok.Value);

            try
            {
                if (namaprodukbaru == "" || idprodukbaru == "" || hargaprodukbaru == "" || kategoriID == "")
                {
                    MessageBox.Show("Isi yang Lengkap");
                }
                else
                {
                    query = $"insert into PRODUK (PRODUK_ID, KATEGORI_ID, PRODUK_NAMA, PRODUK_HARGA, PRODUK_STOK, STATUS_DEL) values ('{idprodukbaru}', '{kategoriID}',' {namaprodukbaru}', '{hargaprodukbaru}', '{jumlahstok}', '0');";
                    command = new MySqlCommand(query, connection);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtProduk);
                    dgv_data.Refresh();
                    panelAddProdukBaru();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

            tb_namaprodukbaru.Clear();
            tb_idproduk.Clear();
            tb_hargaproduk.Clear();
            cb_kategoriID.SelectedItem = -1;
            numericUpDown_jumlahstok.Value = 0;
            jumlahstok = 0;
        }

        DataTable dtkategori;
        DataTable dtProduk;
        public void panelAddProdukBaru()
        {
            try
            {
                connection.Open();
                dtProduk = new DataTable();
                query = " select p.PRODUK_ID, p.KATEGORI_ID, p.PRODUK_NAMA, concat('Rp. ', format(sum(p.PRODUK_HARGA), 0)) as PRODUK_HARGA, p.PRODUK_STOK\r\n\t\tfrom produk p\r\n        where status_del = '0'\r\n        group by p.PRODUK_ID, p.KATEGORI_ID, p.PRODUK_NAMA, p.PRODUK_STOK; ";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtProduk);
                dgv_data.DataSource = dtProduk;

                dtkategori = new DataTable();
                query = "select KATEGORI_ID from KATEGORI where STATUS_DEL = '0';";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtkategori);

                cb_kategoriID.Items.Clear();
                foreach (DataRow dr in dtkategori.Rows)
                {
                    cb_kategoriID.Items.Add(dr["KATEGORI_ID"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }


        }

        private void tb_hargaproduk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
