﻿namespace KELOMPOK_11
{
    partial class MainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menustrip = new System.Windows.Forms.MenuStrip();
            this.mainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.produkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addProdukBaruToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateProdukToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addKategoriBaruToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invoiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.peminjamanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pengembalianToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_main_invoicePengembalian = new System.Windows.Forms.Label();
            this.dgv_main_invoicePengembalian = new System.Windows.Forms.DataGridView();
            this.dgv_main_invPeminjaman = new System.Windows.Forms.DataGridView();
            this.lbl_main_invoicePeminjaman = new System.Windows.Forms.Label();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel_date = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel_staff = new System.Windows.Forms.ToolStripStatusLabel();
            this.panelMain = new System.Windows.Forms.Panel();
            this.menustrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_main_invoicePengembalian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_main_invPeminjaman)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // menustrip
            // 
            this.menustrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menustrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menustrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainToolStripMenuItem,
            this.produkToolStripMenuItem,
            this.invoiceToolStripMenuItem,
            this.dendaToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.menustrip.Location = new System.Drawing.Point(0, 0);
            this.menustrip.Name = "menustrip";
            this.menustrip.Size = new System.Drawing.Size(1705, 33);
            this.menustrip.TabIndex = 0;
            this.menustrip.Text = "menuStrip1";
            // 
            // mainToolStripMenuItem
            // 
            this.mainToolStripMenuItem.Name = "mainToolStripMenuItem";
            this.mainToolStripMenuItem.Size = new System.Drawing.Size(67, 29);
            this.mainToolStripMenuItem.Text = "Main";
            this.mainToolStripMenuItem.Click += new System.EventHandler(this.mainToolStripMenuItem_Click);
            // 
            // produkToolStripMenuItem
            // 
            this.produkToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProdukBaruToolStripMenuItem,
            this.updateProdukToolStripMenuItem,
            this.addKategoriBaruToolStripMenuItem});
            this.produkToolStripMenuItem.Name = "produkToolStripMenuItem";
            this.produkToolStripMenuItem.Size = new System.Drawing.Size(85, 29);
            this.produkToolStripMenuItem.Text = "Produk";
            this.produkToolStripMenuItem.Click += new System.EventHandler(this.produkToolStripMenuItem_Click);
            // 
            // addProdukBaruToolStripMenuItem
            // 
            this.addProdukBaruToolStripMenuItem.Name = "addProdukBaruToolStripMenuItem";
            this.addProdukBaruToolStripMenuItem.Size = new System.Drawing.Size(259, 34);
            this.addProdukBaruToolStripMenuItem.Text = "Add Produk Baru";
            this.addProdukBaruToolStripMenuItem.Click += new System.EventHandler(this.addProdukBaruToolStripMenuItem_Click);
            // 
            // updateProdukToolStripMenuItem
            // 
            this.updateProdukToolStripMenuItem.Name = "updateProdukToolStripMenuItem";
            this.updateProdukToolStripMenuItem.Size = new System.Drawing.Size(259, 34);
            this.updateProdukToolStripMenuItem.Text = "Update Produk";
            this.updateProdukToolStripMenuItem.Click += new System.EventHandler(this.updateProdukToolStripMenuItem_Click);
            // 
            // addKategoriBaruToolStripMenuItem
            // 
            this.addKategoriBaruToolStripMenuItem.Name = "addKategoriBaruToolStripMenuItem";
            this.addKategoriBaruToolStripMenuItem.Size = new System.Drawing.Size(259, 34);
            this.addKategoriBaruToolStripMenuItem.Text = "Add Kategori Baru";
            this.addKategoriBaruToolStripMenuItem.Click += new System.EventHandler(this.addKategoriBaruToolStripMenuItem_Click);
            // 
            // invoiceToolStripMenuItem
            // 
            this.invoiceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.peminjamanToolStripMenuItem,
            this.pengembalianToolStripMenuItem});
            this.invoiceToolStripMenuItem.Name = "invoiceToolStripMenuItem";
            this.invoiceToolStripMenuItem.Size = new System.Drawing.Size(84, 29);
            this.invoiceToolStripMenuItem.Text = "Invoice";
            // 
            // peminjamanToolStripMenuItem
            // 
            this.peminjamanToolStripMenuItem.Name = "peminjamanToolStripMenuItem";
            this.peminjamanToolStripMenuItem.Size = new System.Drawing.Size(225, 34);
            this.peminjamanToolStripMenuItem.Text = "Peminjaman";
            // 
            // pengembalianToolStripMenuItem
            // 
            this.pengembalianToolStripMenuItem.Name = "pengembalianToolStripMenuItem";
            this.pengembalianToolStripMenuItem.Size = new System.Drawing.Size(225, 34);
            this.pengembalianToolStripMenuItem.Text = "Pengembalian";
            // 
            // dendaToolStripMenuItem
            // 
            this.dendaToolStripMenuItem.Name = "dendaToolStripMenuItem";
            this.dendaToolStripMenuItem.Size = new System.Drawing.Size(80, 29);
            this.dendaToolStripMenuItem.Text = "Denda";
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(85, 29);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // lbl_main_invoicePengembalian
            // 
            this.lbl_main_invoicePengembalian.AutoSize = true;
            this.lbl_main_invoicePengembalian.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_main_invoicePengembalian.Location = new System.Drawing.Point(23, 415);
            this.lbl_main_invoicePengembalian.Name = "lbl_main_invoicePengembalian";
            this.lbl_main_invoicePengembalian.Size = new System.Drawing.Size(271, 29);
            this.lbl_main_invoicePengembalian.TabIndex = 3;
            this.lbl_main_invoicePengembalian.Text = "Invoice Pengembalian";
            // 
            // dgv_main_invoicePengembalian
            // 
            this.dgv_main_invoicePengembalian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_main_invoicePengembalian.Location = new System.Drawing.Point(27, 454);
            this.dgv_main_invoicePengembalian.Name = "dgv_main_invoicePengembalian";
            this.dgv_main_invoicePengembalian.RowHeadersWidth = 62;
            this.dgv_main_invoicePengembalian.RowTemplate.Height = 28;
            this.dgv_main_invoicePengembalian.Size = new System.Drawing.Size(1494, 323);
            this.dgv_main_invoicePengembalian.TabIndex = 2;
            // 
            // dgv_main_invPeminjaman
            // 
            this.dgv_main_invPeminjaman.AllowUserToAddRows = false;
            this.dgv_main_invPeminjaman.AllowUserToDeleteRows = false;
            this.dgv_main_invPeminjaman.AllowUserToResizeColumns = false;
            this.dgv_main_invPeminjaman.AllowUserToResizeRows = false;
            this.dgv_main_invPeminjaman.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_main_invPeminjaman.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_main_invPeminjaman.Location = new System.Drawing.Point(27, 64);
            this.dgv_main_invPeminjaman.Name = "dgv_main_invPeminjaman";
            this.dgv_main_invPeminjaman.RowHeadersWidth = 62;
            this.dgv_main_invPeminjaman.RowTemplate.Height = 28;
            this.dgv_main_invPeminjaman.Size = new System.Drawing.Size(1494, 306);
            this.dgv_main_invPeminjaman.TabIndex = 1;
            // 
            // lbl_main_invoicePeminjaman
            // 
            this.lbl_main_invoicePeminjaman.AutoSize = true;
            this.lbl_main_invoicePeminjaman.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_main_invoicePeminjaman.Location = new System.Drawing.Point(23, 24);
            this.lbl_main_invoicePeminjaman.Name = "lbl_main_invoicePeminjaman";
            this.lbl_main_invoicePeminjaman.Size = new System.Drawing.Size(247, 29);
            this.lbl_main_invoicePeminjaman.TabIndex = 0;
            this.lbl_main_invoicePeminjaman.Text = "Invoice Peminjaman";
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel_date,
            this.toolStripStatusLabel_staff});
            this.statusStrip.Location = new System.Drawing.Point(0, 1038);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1705, 32);
            this.statusStrip.TabIndex = 4;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel_date
            // 
            this.toolStripStatusLabel_date.Name = "toolStripStatusLabel_date";
            this.toolStripStatusLabel_date.Size = new System.Drawing.Size(179, 25);
            this.toolStripStatusLabel_date.Text = "toolStripStatusLabel1";
            this.toolStripStatusLabel_date.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripStatusLabel_staff
            // 
            this.toolStripStatusLabel_staff.Name = "toolStripStatusLabel_staff";
            this.toolStripStatusLabel_staff.Size = new System.Drawing.Size(179, 25);
            this.toolStripStatusLabel_staff.Text = "toolStripStatusLabel2";
            this.toolStripStatusLabel_staff.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.lbl_main_invoicePengembalian);
            this.panelMain.Controls.Add(this.dgv_main_invoicePengembalian);
            this.panelMain.Controls.Add(this.dgv_main_invPeminjaman);
            this.panelMain.Controls.Add(this.lbl_main_invoicePeminjaman);
            this.panelMain.Location = new System.Drawing.Point(66, 84);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1550, 807);
            this.panelMain.TabIndex = 6;
            // 
            // MainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1705, 1070);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menustrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menustrip;
            this.Name = "MainPage";
            this.Text = "MainPage";
            this.Load += new System.EventHandler(this.MainPage_Load);
            this.menustrip.ResumeLayout(false);
            this.menustrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_main_invoicePengembalian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_main_invPeminjaman)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menustrip;
        private System.Windows.Forms.ToolStripMenuItem mainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem produkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addProdukBaruToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateProdukToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addKategoriBaruToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invoiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem peminjamanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pengembalianToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label lbl_main_invoicePengembalian;
        private System.Windows.Forms.DataGridView dgv_main_invoicePengembalian;
        private System.Windows.Forms.DataGridView dgv_main_invPeminjaman;
        private System.Windows.Forms.Label lbl_main_invoicePeminjaman;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_date;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel_staff;
        private System.Windows.Forms.Panel panelMain;
    }
}