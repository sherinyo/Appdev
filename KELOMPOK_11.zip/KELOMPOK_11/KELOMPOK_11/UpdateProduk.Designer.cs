﻿namespace KELOMPOK_11
{
    partial class UpdateProduk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.btn_save_updateproduk = new System.Windows.Forms.Button();
            this.numericUpDown_updateJumlahStok = new System.Windows.Forms.NumericUpDown();
            this.cb_updateKategoriID = new System.Windows.Forms.ComboBox();
            this.tb_hargaprodukUpdate = new System.Windows.Forms.TextBox();
            this.tb_updateIDproduk = new System.Windows.Forms.TextBox();
            this.tb_namaproduk = new System.Windows.Forms.TextBox();
            this.lbl_kategoriIDUpdate = new System.Windows.Forms.Label();
            this.lbl_jumlahstokupdate = new System.Windows.Forms.Label();
            this.lbl_hargaproduk = new System.Windows.Forms.Label();
            this.lbl_idproduk = new System.Windows.Forms.Label();
            this.lbl_namaproduk = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_updateJumlahStok)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_data
            // 
            this.dgv_data.AllowUserToAddRows = false;
            this.dgv_data.AllowUserToDeleteRows = false;
            this.dgv_data.AllowUserToResizeColumns = false;
            this.dgv_data.AllowUserToResizeRows = false;
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(675, 58);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 62;
            this.dgv_data.RowTemplate.Height = 28;
            this.dgv_data.Size = new System.Drawing.Size(906, 788);
            this.dgv_data.TabIndex = 1;
            this.dgv_data.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_data_CellMouseClick);
            // 
            // btn_save_updateproduk
            // 
            this.btn_save_updateproduk.Location = new System.Drawing.Point(409, 383);
            this.btn_save_updateproduk.Name = "btn_save_updateproduk";
            this.btn_save_updateproduk.Size = new System.Drawing.Size(99, 39);
            this.btn_save_updateproduk.TabIndex = 13;
            this.btn_save_updateproduk.Text = "save";
            this.btn_save_updateproduk.UseVisualStyleBackColor = true;
            this.btn_save_updateproduk.Click += new System.EventHandler(this.btn_save_updateproduk_Click);
            // 
            // numericUpDown_updateJumlahStok
            // 
            this.numericUpDown_updateJumlahStok.Location = new System.Drawing.Point(256, 325);
            this.numericUpDown_updateJumlahStok.Name = "numericUpDown_updateJumlahStok";
            this.numericUpDown_updateJumlahStok.Size = new System.Drawing.Size(120, 26);
            this.numericUpDown_updateJumlahStok.TabIndex = 10;
            // 
            // cb_updateKategoriID
            // 
            this.cb_updateKategoriID.Enabled = false;
            this.cb_updateKategoriID.FormattingEnabled = true;
            this.cb_updateKategoriID.Location = new System.Drawing.Point(256, 253);
            this.cb_updateKategoriID.Name = "cb_updateKategoriID";
            this.cb_updateKategoriID.Size = new System.Drawing.Size(252, 28);
            this.cb_updateKategoriID.TabIndex = 9;
            // 
            // tb_hargaprodukUpdate
            // 
            this.tb_hargaprodukUpdate.Enabled = false;
            this.tb_hargaprodukUpdate.Location = new System.Drawing.Point(256, 193);
            this.tb_hargaprodukUpdate.Name = "tb_hargaprodukUpdate";
            this.tb_hargaprodukUpdate.Size = new System.Drawing.Size(252, 26);
            this.tb_hargaprodukUpdate.TabIndex = 8;
            // 
            // tb_updateIDproduk
            // 
            this.tb_updateIDproduk.Enabled = false;
            this.tb_updateIDproduk.Location = new System.Drawing.Point(256, 134);
            this.tb_updateIDproduk.Name = "tb_updateIDproduk";
            this.tb_updateIDproduk.Size = new System.Drawing.Size(252, 26);
            this.tb_updateIDproduk.TabIndex = 7;
            // 
            // tb_namaproduk
            // 
            this.tb_namaproduk.Enabled = false;
            this.tb_namaproduk.Location = new System.Drawing.Point(256, 71);
            this.tb_namaproduk.Name = "tb_namaproduk";
            this.tb_namaproduk.Size = new System.Drawing.Size(252, 26);
            this.tb_namaproduk.TabIndex = 6;
            // 
            // lbl_kategoriIDUpdate
            // 
            this.lbl_kategoriIDUpdate.AutoSize = true;
            this.lbl_kategoriIDUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kategoriIDUpdate.Location = new System.Drawing.Point(62, 252);
            this.lbl_kategoriIDUpdate.Name = "lbl_kategoriIDUpdate";
            this.lbl_kategoriIDUpdate.Size = new System.Drawing.Size(115, 25);
            this.lbl_kategoriIDUpdate.TabIndex = 5;
            this.lbl_kategoriIDUpdate.Text = "Kategori ID:";
            // 
            // lbl_jumlahstokupdate
            // 
            this.lbl_jumlahstokupdate.AutoSize = true;
            this.lbl_jumlahstokupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jumlahstokupdate.Location = new System.Drawing.Point(62, 315);
            this.lbl_jumlahstokupdate.Name = "lbl_jumlahstokupdate";
            this.lbl_jumlahstokupdate.Size = new System.Drawing.Size(127, 25);
            this.lbl_jumlahstokupdate.TabIndex = 3;
            this.lbl_jumlahstokupdate.Text = "Jumlah Stok:";
            // 
            // lbl_hargaproduk
            // 
            this.lbl_hargaproduk.AutoSize = true;
            this.lbl_hargaproduk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hargaproduk.Location = new System.Drawing.Point(61, 193);
            this.lbl_hargaproduk.Name = "lbl_hargaproduk";
            this.lbl_hargaproduk.Size = new System.Drawing.Size(138, 25);
            this.lbl_hargaproduk.TabIndex = 2;
            this.lbl_hargaproduk.Text = "Harga Produk:";
            // 
            // lbl_idproduk
            // 
            this.lbl_idproduk.AutoSize = true;
            this.lbl_idproduk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idproduk.Location = new System.Drawing.Point(62, 131);
            this.lbl_idproduk.Name = "lbl_idproduk";
            this.lbl_idproduk.Size = new System.Drawing.Size(104, 25);
            this.lbl_idproduk.TabIndex = 1;
            this.lbl_idproduk.Text = "ID Produk:";
            // 
            // lbl_namaproduk
            // 
            this.lbl_namaproduk.AutoSize = true;
            this.lbl_namaproduk.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_namaproduk.Location = new System.Drawing.Point(62, 70);
            this.lbl_namaproduk.Name = "lbl_namaproduk";
            this.lbl_namaproduk.Size = new System.Drawing.Size(137, 25);
            this.lbl_namaproduk.TabIndex = 0;
            this.lbl_namaproduk.Text = "Nama Produk:";
            // 
            // UpdateProduk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1705, 909);
            this.Controls.Add(this.btn_save_updateproduk);
            this.Controls.Add(this.numericUpDown_updateJumlahStok);
            this.Controls.Add(this.cb_updateKategoriID);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.tb_hargaprodukUpdate);
            this.Controls.Add(this.lbl_namaproduk);
            this.Controls.Add(this.tb_updateIDproduk);
            this.Controls.Add(this.lbl_idproduk);
            this.Controls.Add(this.tb_namaproduk);
            this.Controls.Add(this.lbl_hargaproduk);
            this.Controls.Add(this.lbl_kategoriIDUpdate);
            this.Controls.Add(this.lbl_jumlahstokupdate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UpdateProduk";
            this.Text = "Update Produk";
            this.Load += new System.EventHandler(this.ProdukDropDownPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_updateJumlahStok)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.Button btn_save_updateproduk;
        private System.Windows.Forms.NumericUpDown numericUpDown_updateJumlahStok;
        private System.Windows.Forms.ComboBox cb_updateKategoriID;
        private System.Windows.Forms.TextBox tb_hargaprodukUpdate;
        private System.Windows.Forms.TextBox tb_updateIDproduk;
        private System.Windows.Forms.TextBox tb_namaproduk;
        private System.Windows.Forms.Label lbl_kategoriIDUpdate;
        private System.Windows.Forms.Label lbl_jumlahstokupdate;
        private System.Windows.Forms.Label lbl_hargaproduk;
        private System.Windows.Forms.Label lbl_idproduk;
        private System.Windows.Forms.Label lbl_namaproduk;
    }
}