﻿namespace KELOMPOK_11
{
    partial class AddKategoriBaru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_save_AddKategoriBaru = new System.Windows.Forms.Button();
            this.tb_IDKategori_akb = new System.Windows.Forms.TextBox();
            this.tb_namaKategori_akb = new System.Windows.Forms.TextBox();
            this.lbl_idKategori = new System.Windows.Forms.Label();
            this.lbl_namaKategori = new System.Windows.Forms.Label();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_save_AddKategoriBaru
            // 
            this.btn_save_AddKategoriBaru.Location = new System.Drawing.Point(422, 196);
            this.btn_save_AddKategoriBaru.Name = "btn_save_AddKategoriBaru";
            this.btn_save_AddKategoriBaru.Size = new System.Drawing.Size(78, 43);
            this.btn_save_AddKategoriBaru.TabIndex = 4;
            this.btn_save_AddKategoriBaru.Text = "Save";
            this.btn_save_AddKategoriBaru.UseVisualStyleBackColor = true;
            this.btn_save_AddKategoriBaru.Click += new System.EventHandler(this.btn_save_AddKategoriBaru_Click);
            // 
            // tb_IDKategori_akb
            // 
            this.tb_IDKategori_akb.Location = new System.Drawing.Point(230, 133);
            this.tb_IDKategori_akb.Name = "tb_IDKategori_akb";
            this.tb_IDKategori_akb.Size = new System.Drawing.Size(270, 26);
            this.tb_IDKategori_akb.TabIndex = 3;
            // 
            // tb_namaKategori_akb
            // 
            this.tb_namaKategori_akb.Location = new System.Drawing.Point(230, 82);
            this.tb_namaKategori_akb.Name = "tb_namaKategori_akb";
            this.tb_namaKategori_akb.Size = new System.Drawing.Size(270, 26);
            this.tb_namaKategori_akb.TabIndex = 2;
            // 
            // lbl_idKategori
            // 
            this.lbl_idKategori.AutoSize = true;
            this.lbl_idKategori.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idKategori.Location = new System.Drawing.Point(76, 132);
            this.lbl_idKategori.Name = "lbl_idKategori";
            this.lbl_idKategori.Size = new System.Drawing.Size(115, 25);
            this.lbl_idKategori.TabIndex = 1;
            this.lbl_idKategori.Text = "ID Kategori:";
            // 
            // lbl_namaKategori
            // 
            this.lbl_namaKategori.AutoSize = true;
            this.lbl_namaKategori.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_namaKategori.Location = new System.Drawing.Point(76, 82);
            this.lbl_namaKategori.Name = "lbl_namaKategori";
            this.lbl_namaKategori.Size = new System.Drawing.Size(148, 25);
            this.lbl_namaKategori.TabIndex = 0;
            this.lbl_namaKategori.Text = "Nama Kategori:";
            // 
            // dgv_data
            // 
            this.dgv_data.AllowUserToAddRows = false;
            this.dgv_data.AllowUserToDeleteRows = false;
            this.dgv_data.AllowUserToResizeColumns = false;
            this.dgv_data.AllowUserToResizeRows = false;
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(625, 82);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 62;
            this.dgv_data.RowTemplate.Height = 28;
            this.dgv_data.Size = new System.Drawing.Size(517, 675);
            this.dgv_data.TabIndex = 5;
            // 
            // AddKategoriBaru
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1683, 849);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.btn_save_AddKategoriBaru);
            this.Controls.Add(this.tb_IDKategori_akb);
            this.Controls.Add(this.tb_namaKategori_akb);
            this.Controls.Add(this.lbl_namaKategori);
            this.Controls.Add(this.lbl_idKategori);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddKategoriBaru";
            this.Text = "updateProduk";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_save_AddKategoriBaru;
        private System.Windows.Forms.TextBox tb_IDKategori_akb;
        private System.Windows.Forms.TextBox tb_namaKategori_akb;
        private System.Windows.Forms.Label lbl_idKategori;
        private System.Windows.Forms.Label lbl_namaKategori;
        private System.Windows.Forms.DataGridView dgv_data;
    }
}