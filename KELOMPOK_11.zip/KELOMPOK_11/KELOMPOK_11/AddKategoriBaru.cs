﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KELOMPOK_11
{
    public partial class AddKategoriBaru : Form
    {
        MainPage mainPage;
        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        public string query;

        DataTable dataKategoriBaru = new DataTable();
        public AddKategoriBaru(Form _sender)
        {
            InitializeComponent();
            mainPage = (MainPage)_sender;
            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = kelompok11");

        }

        private void btn_save_AddKategoriBaru_Click(object sender, EventArgs e)
        {
            string namaKategori = tb_namaKategori_akb.Text.ToUpper();
            string idkategori = tb_IDKategori_akb.Text.ToUpper();

            try
            {
                connection.Open();

                if (namaKategori == "" || idkategori == "")
                {
                    MessageBox.Show("Tolong input yang lengkap");
                    tb_namaKategori_akb.Clear();
                    tb_IDKategori_akb.Clear();
                    return;

                }

                query = $"insert into KATEGORI (KATEGORI_ID, KATEGORI_NAMA, STATUS_DEL) values ('{idkategori}', '{namaKategori}', '0');";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dataKategoriBaru);
                dgv_data.DataSource = dataKategoriBaru;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }

            refreshDataKategoriBaru();
            tb_namaKategori_akb.Clear();
            tb_IDKategori_akb.Clear();
        }

        private void refreshDataKategoriBaru()
        {
            connection.Open();
            connection.Close();
            query = "select KATEGORI_ID, KATEGORI_NAMA from KATEGORI;";


            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);

            dataKategoriBaru.Clear();
            adapter.Fill(dataKategoriBaru);
            dgv_data.DataSource = dataKategoriBaru;

        }

    }
}
