﻿namespace KELOMPOK_11
{
    partial class ProdukPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_produk = new System.Windows.Forms.DataGridView();
            this.cb_kategoriProduk = new System.Windows.Forms.ComboBox();
            this.lbl_produk = new System.Windows.Forms.Label();
            this.btn_allProduk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_produk)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_produk
            // 
            this.dgv_produk.AllowUserToAddRows = false;
            this.dgv_produk.AllowUserToDeleteRows = false;
            this.dgv_produk.AllowUserToResizeColumns = false;
            this.dgv_produk.AllowUserToResizeRows = false;
            this.dgv_produk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_produk.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_produk.Location = new System.Drawing.Point(43, 130);
            this.dgv_produk.Name = "dgv_produk";
            this.dgv_produk.RowHeadersWidth = 62;
            this.dgv_produk.RowTemplate.Height = 28;
            this.dgv_produk.Size = new System.Drawing.Size(1473, 465);
            this.dgv_produk.TabIndex = 0;
            this.dgv_produk.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_produk_CellContentClick);
            // 
            // cb_kategoriProduk
            // 
            this.cb_kategoriProduk.FormattingEnabled = true;
            this.cb_kategoriProduk.Location = new System.Drawing.Point(1345, 73);
            this.cb_kategoriProduk.Name = "cb_kategoriProduk";
            this.cb_kategoriProduk.Size = new System.Drawing.Size(153, 28);
            this.cb_kategoriProduk.TabIndex = 1;
            this.cb_kategoriProduk.SelectedIndexChanged += new System.EventHandler(this.cb_kategoriProduk_SelectedIndexChanged);
            // 
            // lbl_produk
            // 
            this.lbl_produk.AutoSize = true;
            this.lbl_produk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_produk.Location = new System.Drawing.Point(47, 79);
            this.lbl_produk.Name = "lbl_produk";
            this.lbl_produk.Size = new System.Drawing.Size(96, 29);
            this.lbl_produk.TabIndex = 2;
            this.lbl_produk.Text = "Produk";
            // 
            // btn_allProduk
            // 
            this.btn_allProduk.Location = new System.Drawing.Point(172, 75);
            this.btn_allProduk.Name = "btn_allProduk";
            this.btn_allProduk.Size = new System.Drawing.Size(153, 44);
            this.btn_allProduk.TabIndex = 3;
            this.btn_allProduk.Text = "All Produk";
            this.btn_allProduk.UseVisualStyleBackColor = true;
            this.btn_allProduk.Click += new System.EventHandler(this.btn_allProduk_Click);
            // 
            // ProdukPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1707, 869);
            this.Controls.Add(this.btn_allProduk);
            this.Controls.Add(this.lbl_produk);
            this.Controls.Add(this.dgv_produk);
            this.Controls.Add(this.cb_kategoriProduk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProdukPage";
            this.Text = "ProdukPage";
            this.Load += new System.EventHandler(this.ProdukPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_produk)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_produk;
        private System.Windows.Forms.ComboBox cb_kategoriProduk;
        private System.Windows.Forms.Label lbl_produk;
        private System.Windows.Forms.Button btn_allProduk;
    }
}