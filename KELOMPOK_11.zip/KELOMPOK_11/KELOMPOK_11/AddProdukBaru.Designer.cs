﻿namespace KELOMPOK_11
{
    partial class AddProdukBaru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_save_addprodukbaru = new System.Windows.Forms.Button();
            this.numericUpDown_jumlahstok = new System.Windows.Forms.NumericUpDown();
            this.cb_kategoriID = new System.Windows.Forms.ComboBox();
            this.tb_hargaproduk = new System.Windows.Forms.TextBox();
            this.tb_idproduk = new System.Windows.Forms.TextBox();
            this.tb_namaprodukbaru = new System.Windows.Forms.TextBox();
            this.lbl_kategoriID = new System.Windows.Forms.Label();
            this.lbl_jumlahstokbaru = new System.Windows.Forms.Label();
            this.lbl_hargaprodukbaru = new System.Windows.Forms.Label();
            this.lbl_idprodukbaru = new System.Windows.Forms.Label();
            this.lbl_namaprodukbaru = new System.Windows.Forms.Label();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_jumlahstok)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_save_addprodukbaru
            // 
            this.btn_save_addprodukbaru.Location = new System.Drawing.Point(357, 421);
            this.btn_save_addprodukbaru.Name = "btn_save_addprodukbaru";
            this.btn_save_addprodukbaru.Size = new System.Drawing.Size(99, 39);
            this.btn_save_addprodukbaru.TabIndex = 13;
            this.btn_save_addprodukbaru.Text = "save";
            this.btn_save_addprodukbaru.UseVisualStyleBackColor = true;
            this.btn_save_addprodukbaru.Click += new System.EventHandler(this.btn_save_addprodukbaru_Click);
            // 
            // numericUpDown_jumlahstok
            // 
            this.numericUpDown_jumlahstok.Location = new System.Drawing.Point(357, 358);
            this.numericUpDown_jumlahstok.Name = "numericUpDown_jumlahstok";
            this.numericUpDown_jumlahstok.Size = new System.Drawing.Size(120, 26);
            this.numericUpDown_jumlahstok.TabIndex = 10;
            // 
            // cb_kategoriID
            // 
            this.cb_kategoriID.FormattingEnabled = true;
            this.cb_kategoriID.Location = new System.Drawing.Point(357, 286);
            this.cb_kategoriID.Name = "cb_kategoriID";
            this.cb_kategoriID.Size = new System.Drawing.Size(252, 28);
            this.cb_kategoriID.TabIndex = 9;
            // 
            // tb_hargaproduk
            // 
            this.tb_hargaproduk.Location = new System.Drawing.Point(357, 226);
            this.tb_hargaproduk.Name = "tb_hargaproduk";
            this.tb_hargaproduk.Size = new System.Drawing.Size(252, 26);
            this.tb_hargaproduk.TabIndex = 8;
            this.tb_hargaproduk.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_hargaproduk_KeyPress);
            // 
            // tb_idproduk
            // 
            this.tb_idproduk.Location = new System.Drawing.Point(357, 167);
            this.tb_idproduk.Name = "tb_idproduk";
            this.tb_idproduk.Size = new System.Drawing.Size(252, 26);
            this.tb_idproduk.TabIndex = 7;
            // 
            // tb_namaprodukbaru
            // 
            this.tb_namaprodukbaru.Location = new System.Drawing.Point(357, 104);
            this.tb_namaprodukbaru.Name = "tb_namaprodukbaru";
            this.tb_namaprodukbaru.Size = new System.Drawing.Size(252, 26);
            this.tb_namaprodukbaru.TabIndex = 6;
            // 
            // lbl_kategoriID
            // 
            this.lbl_kategoriID.AutoSize = true;
            this.lbl_kategoriID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_kategoriID.Location = new System.Drawing.Point(88, 286);
            this.lbl_kategoriID.Name = "lbl_kategoriID";
            this.lbl_kategoriID.Size = new System.Drawing.Size(115, 25);
            this.lbl_kategoriID.TabIndex = 5;
            this.lbl_kategoriID.Text = "Kategori ID:";
            // 
            // lbl_jumlahstokbaru
            // 
            this.lbl_jumlahstokbaru.AutoSize = true;
            this.lbl_jumlahstokbaru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_jumlahstokbaru.Location = new System.Drawing.Point(88, 349);
            this.lbl_jumlahstokbaru.Name = "lbl_jumlahstokbaru";
            this.lbl_jumlahstokbaru.Size = new System.Drawing.Size(127, 25);
            this.lbl_jumlahstokbaru.TabIndex = 3;
            this.lbl_jumlahstokbaru.Text = "Jumlah Stok:";
            // 
            // lbl_hargaprodukbaru
            // 
            this.lbl_hargaprodukbaru.AutoSize = true;
            this.lbl_hargaprodukbaru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hargaprodukbaru.Location = new System.Drawing.Point(87, 227);
            this.lbl_hargaprodukbaru.Name = "lbl_hargaprodukbaru";
            this.lbl_hargaprodukbaru.Size = new System.Drawing.Size(184, 25);
            this.lbl_hargaprodukbaru.TabIndex = 2;
            this.lbl_hargaprodukbaru.Text = "Harga Produk Baru:";
            // 
            // lbl_idprodukbaru
            // 
            this.lbl_idprodukbaru.AutoSize = true;
            this.lbl_idprodukbaru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idprodukbaru.Location = new System.Drawing.Point(88, 165);
            this.lbl_idprodukbaru.Name = "lbl_idprodukbaru";
            this.lbl_idprodukbaru.Size = new System.Drawing.Size(150, 25);
            this.lbl_idprodukbaru.TabIndex = 1;
            this.lbl_idprodukbaru.Text = "ID Produk Baru:";
            // 
            // lbl_namaprodukbaru
            // 
            this.lbl_namaprodukbaru.AutoSize = true;
            this.lbl_namaprodukbaru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_namaprodukbaru.Location = new System.Drawing.Point(88, 104);
            this.lbl_namaprodukbaru.Name = "lbl_namaprodukbaru";
            this.lbl_namaprodukbaru.Size = new System.Drawing.Size(183, 25);
            this.lbl_namaprodukbaru.TabIndex = 0;
            this.lbl_namaprodukbaru.Text = "Nama Produk Baru:";
            // 
            // dgv_data
            // 
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(751, 75);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 62;
            this.dgv_data.RowTemplate.Height = 28;
            this.dgv_data.Size = new System.Drawing.Size(843, 680);
            this.dgv_data.TabIndex = 5;
            // 
            // AddProdukBaru
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1683, 849);
            this.Controls.Add(this.btn_save_addprodukbaru);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.numericUpDown_jumlahstok);
            this.Controls.Add(this.cb_kategoriID);
            this.Controls.Add(this.tb_hargaproduk);
            this.Controls.Add(this.lbl_namaprodukbaru);
            this.Controls.Add(this.tb_idproduk);
            this.Controls.Add(this.lbl_idprodukbaru);
            this.Controls.Add(this.tb_namaprodukbaru);
            this.Controls.Add(this.lbl_hargaprodukbaru);
            this.Controls.Add(this.lbl_kategoriID);
            this.Controls.Add(this.lbl_jumlahstokbaru);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddProdukBaru";
            this.Text = "AddProdukBaru";
            this.Load += new System.EventHandler(this.AddProdukBaru_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_jumlahstok)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_save_addprodukbaru;
        private System.Windows.Forms.NumericUpDown numericUpDown_jumlahstok;
        private System.Windows.Forms.ComboBox cb_kategoriID;
        private System.Windows.Forms.TextBox tb_hargaproduk;
        private System.Windows.Forms.TextBox tb_idproduk;
        private System.Windows.Forms.TextBox tb_namaprodukbaru;
        private System.Windows.Forms.Label lbl_kategoriID;
        private System.Windows.Forms.Label lbl_jumlahstokbaru;
        private System.Windows.Forms.Label lbl_hargaprodukbaru;
        private System.Windows.Forms.Label lbl_idprodukbaru;
        private System.Windows.Forms.Label lbl_namaprodukbaru;
        private System.Windows.Forms.DataGridView dgv_data;
    }
}