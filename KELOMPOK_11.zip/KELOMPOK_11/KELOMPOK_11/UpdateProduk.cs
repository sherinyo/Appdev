﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KELOMPOK_11
{
    public partial class UpdateProduk : Form
    {
        MainPage mainPage;

        public UpdateProduk(Form _sender)
        {
            InitializeComponent();
            mainPage = (MainPage)_sender;
            //panel_addKategoriBaru.Visible = true;

            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = kelompok11");

        }

        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        public string query;

        DataTable dataKategoriBaru = new DataTable();
        DataTable dtProduk;

        private void ProdukDropDownPage_Load(object sender, EventArgs e)
        {


        }


        // UPDATE PRODUK
        public void panelUpdateProduk()
        {

            try
            {
                connection.Open();
                dtProduk = new DataTable();
                query = " select p.PRODUK_ID, p.KATEGORI_ID, p.PRODUK_NAMA, concat('Rp. ', format(sum(p.PRODUK_HARGA), 0)) as PRODUK_HARGA, p.PRODUK_STOK\r\n\t\tfrom produk p\r\n        where status_del = '0'\r\n        group by p.PRODUK_ID, p.KATEGORI_ID, p.PRODUK_NAMA, p.PRODUK_STOK; ";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtProduk);
                dgv_data.DataSource = dtProduk;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }

        }
        
        private void dgv_data_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
            tb_namaproduk.Enabled = false;
            tb_updateIDproduk.Enabled = false;
            tb_hargaprodukUpdate.Enabled = false;
            cb_updateKategoriID.Enabled = false;

            tb_namaproduk.Clear();
            tb_updateIDproduk.Clear();
            tb_hargaprodukUpdate.Clear();
            numericUpDown_updateJumlahStok.Value = 0;
            cb_updateKategoriID.SelectedIndex = -1;


            if (dgv_data.CurrentRow != null)
            {
                DataGridViewRow dtProduk = dgv_data.CurrentRow;
                tb_updateIDproduk.Text = dtProduk.Cells[0].Value?.ToString();
                cb_updateKategoriID.Text = dtProduk.Cells[1].Value?.ToString();
                tb_namaproduk.Text = dtProduk.Cells[2].Value?.ToString();
                tb_hargaprodukUpdate.Text = dtProduk.Cells[3].Value?.ToString();
                numericUpDown_updateJumlahStok.Value = Convert.ToInt32(dtProduk.Cells[4].Value.ToString());
            }
        }

        DataTable JumlahStokUpdate;
        private void btn_save_updateproduk_Click(object sender, EventArgs e)
        {
            tb_namaproduk.Enabled = false;
            tb_updateIDproduk.Enabled = false;
            tb_hargaprodukUpdate.Enabled = false;
            cb_updateKategoriID.Enabled = false;

            JumlahStokUpdate = new DataTable();
            int updateStok = Convert.ToInt32(numericUpDown_updateJumlahStok.Value);
            string IDProduk = tb_updateIDproduk.Text.ToUpper();

            try
            {
                connection.Open();
                query = $"update PRODUK set PRODUK_STOK = '{updateStok}' where PRODUK_ID = '{IDProduk}';";
                command = new MySqlCommand(query, connection);
                command.ExecuteNonQuery();
                refreshDGV();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }

            tb_namaproduk.Clear();
            tb_updateIDproduk.Clear();
            tb_hargaprodukUpdate.Clear();
            numericUpDown_updateJumlahStok.Value = 0;
            cb_updateKategoriID.SelectedIndex = -1;
        }

        private void refreshDGV()
        {
            try
            {
                dtProduk = new DataTable();
                query = "select * from PRODUK where STATUS_DEL = 0;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtProduk);
                dgv_data.DataSource = dtProduk;
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"Refresh Error: {ex.Message}");
            }
           
        }

    }
}
