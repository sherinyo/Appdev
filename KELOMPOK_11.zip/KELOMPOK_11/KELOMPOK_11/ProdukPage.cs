﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace KELOMPOK_11
{
    public partial class ProdukPage : Form
    {
        MainPage mainPage;

        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        public ProdukPage(Form _sender)
        {
            InitializeComponent();
            mainPage = (MainPage)_sender;
        }

        DataTable dtProduk;
        DataTable dtkategori;
        public string query;
        private void ProdukPage_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = kelompok11");
            try
            {
                connection.Open();
                refreshDataProduk();

                dtkategori = new DataTable();
                query = "select KATEGORI_NAMA from KATEGORI where STATUS_DEL = '0';";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtkategori);

                foreach (DataRow dr in dtkategori.Rows)
                {
                    cb_kategoriProduk.Items.Add(dr["KATEGORI_NAMA"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
           
        }

        private void refreshDataProduk(string pilihkategori = null)
        {
            dtProduk = new DataTable();

            if (pilihkategori == null)
            {
                query = "select * from PRODUK where STATUS_DEL = '0';";
            }
            else
            {
                query = $"select p.PRODUK_ID as 'ID Produk', p.KATEGORI_ID as 'ID Kategori', p.PRODUK_NAMA as 'Nama Produk', p.PRODUK_HARGA as 'Harga Produk', p.PRODUK_STOK as 'Stok Produk'\r\n\tfrom produk p\r\n    left join kategori k\r\n    on p.KATEGORI_ID = k.KATEGORI_ID\r\n    where k.KATEGORI_NAMA = '{pilihkategori}';";
                command = new MySqlCommand(query, connection);
            }
            

            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtProduk);
            dgv_produk.DataSource = dtProduk;
        }

        private void cb_kategoriProduk_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_kategoriProduk.SelectedItem != null)
            {
                string pilihan = cb_kategoriProduk.SelectedItem.ToString();
                refreshDataProduk(pilihan);
            }
        }

        
        private void btn_allProduk_Click(object sender, EventArgs e)
        {
           
            try
            {
                connection.Open();
                dtProduk = new DataTable();
                query = "select p.PRODUK_ID as 'ID Produk', p.KATEGORI_ID as 'ID Kategori', p.PRODUK_NAMA as 'Nama Produk', p.PRODUK_HARGA as 'Harga Produk', p.PRODUK_STOK as 'Stok Produk' from PRODUK p where STATUS_DEL = '0';";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtProduk);
                dgv_produk.DataSource = dtProduk;
                cb_kategoriProduk.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }

        private void dgv_produk_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
