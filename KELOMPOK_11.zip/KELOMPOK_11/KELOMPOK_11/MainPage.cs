﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KELOMPOK_11
{
    public partial class MainPage : Form
    {
        LoginStaff formLoginStaff;
        public string staffName;    


        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        public MainPage(LoginStaff _formLoginStaff, string _staffName)
        {
            InitializeComponent();
            formLoginStaff = _formLoginStaff;
            this.formLoginStaff = formLoginStaff;

            staffName = _staffName;
            //query = $"select s.staff_nama from staff s where s.staff_id = '{staffName}'; ";
            toolStripStatusLabel_staff.Text = staffName;
            string date = DateTime.Now.ToString();
            toolStripStatusLabel_date.Text = date;
        }

        DialogResult dialogResult;
        public string query;
        public DataTable dataMainInvoicePeminjaman;
        public DataTable dataMainInvoicePengembalian;

        private void MainPage_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = kelompok11");
            try
            {
                connection.Open();
                // MessageBox.Show("database has opened");
                connection.Close();

                // PANEL MAIN (TAMPILAN AWAL)
                dataMainInvoicePeminjaman = new DataTable();
                query = "select ip.INVPEM_ID as ID_Peminjaman, \r\n\t\tip.STAFF_ID as ID_Staff, \r\n        c.CUSTOMER_NAMA as Nama_Customer, \r\n        ip.INVPEM_TANGGALPINJAM as Tanggal_Pinjam, \r\n        ip.INVPEM_TANGGALTENGGATKEMBALI as Tanggal_Kembali,\r\n\t\tipd.PRODUK_ID ID_Produk, \r\n        ipd.JUMLAH_PRODUK_PINJAM as Jumlah_Produk_Pinjam, \r\n        concat('Rp. ', format(sum(p.produk_harga), 0)) as Harga_Satuan, \r\n        concat('Rp. ', format((sum(ipd.JUMLAH_PRODUK_PINJAM ) * P.PRODUK_HARGA), 0)) as TOTAL, \r\n        (\r\n        select concat('Rp. ', format(sum(ipd2.HARGA_PRODUK_PINJAM), 0)) \r\n\t\t\tfrom INVOICE_PEMINJAMAN_DETAIL ipd2\r\n            where ip.INVPEM_ID = ipd2.INVPEM_ID\r\n        ) as TOTAL_AKUMULASI\r\n\t\tfrom INVOICE_PEMINJAMAN ip\r\n        left join INVOICE_PEMINJAMAN_DETAIL ipd\r\n        on ip.INVPEM_ID = ipd.INVPEM_ID\r\n        left join CUSTOMER c\r\n        on ip.CUSTOMER_NIK = c.CUSTOMER_NIK\r\n        left join INVOICE_PENGEMBALIAN ipg\r\n\t\ton ip.INVPEM_ID = ipg.INVPEM_ID\r\n        left join PRODUK p\r\n\t\ton ipd.PRODUK_ID = p.PRODUK_ID\r\n        where ipg.INVPEM_ID is null\r\n        GROUP BY ip.INVPEM_ID, ip.STAFF_ID, c.CUSTOMER_NAMA, ip.INVPEM_TANGGALPINJAM, \r\n\t\t\t\tip.INVPEM_TANGGALTENGGATKEMBALI, ipd.PRODUK_ID, ipd.JUMLAH_PRODUK_PINJAM, ipd.HARGA_PRODUK_PINJAM, ip.INVPEM_TOTALBAYAR;";
                // menunjukkan data invoice peminjaman yang masih aktif (belum ada ID_Pengembalian)
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dataMainInvoicePeminjaman);
                dgv_main_invPeminjaman.DataSource = dataMainInvoicePeminjaman;


                dataMainInvoicePengembalian = new DataTable();
                query = "select ipg.INVPENG_ID as ID_Pengembalian,\r\n\t\tipg.INVPEM_ID as ID_Peminjaman,\r\n        s.STAFF_NAMA as Nama_Staff,\r\n        ipg.INVPENG_TANGGALKEMBALI as Waktu_Kembali,\r\n        c.CUSTOMER_NAMA as Nama_Customer,\r\n        p.PRODUK_ID as ID_Produk,\r\n        ipgd.JUMLAH_PRODUK_KEMBALI as Jumlah_Produk_Kembali,\r\n        ipgd.KONDISI_PRODUK_KEMBALI as Kondisi_Produk_Kembali,\r\n        d.DENDA_ID as ID_Denda,\r\n        d.DENDA_TANGGAL as Tanggal_Denda,\r\n        d.DENDA_JENIS as Jenis_Denda,\r\n        d.DENDA_STATUS as Status_Denda,\r\n\t\tconcat('Rp. ', format(sum(d.DENDA_NOMINAL), 0)) as TOTAL\r\n\t\t\r\n\t\tfrom invoice_pengembalian ipg\r\n        left join invoice_peminjaman ip\r\n\t\t\ton ipg.INVPEM_ID = ip.INVPEM_ID\r\n\t\tleft join customer c\r\n\t\t\ton ipg.CUSTOMER_NIK = c.CUSTOMER_NIK\r\n\t\tleft join staff s \r\n\t\t\ton ipg.STAFF_ID = s.STAFF_ID\r\n\t\tleft join invoice_pengembalian_detail ipgd\r\n\t\t\ton ipg.INVPENG_ID = ipgd.INVPENG_ID\r\n\t\tleft join produk p\r\n\t\t\ton ipgd.PRODUK_ID = p.PRODUK_ID\r\n\t\tleft join denda d\r\n\t\t\ton ipg.INVPENG_ID = d.INVPENG_ID\r\n\t\twhere d.DENDA_STATUS = 'B'\r\n        group by ipg.INVPENG_ID, ipg.INVPEM_ID, s.STAFF_NAMA, ipg.INVPENG_TANGGALKEMBALI, c.CUSTOMER_NAMA, p.PRODUK_ID, ipgd.JUMLAH_PRODUK_KEMBALI,\r\n\t\t\tipgd.KONDISI_PRODUK_KEMBALI, d.DENDA_ID, d.DENDA_TANGGAL, d.DENDA_JENIS, d.DENDA_STATUS\r\n            ;";
                // menunjukkan data invoice pengembalian yang masih aktif (masih ada denda -> belum lunas)
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dataMainInvoicePengembalian);
                dgv_main_invoicePengembalian.DataSource = dataMainInvoicePengembalian;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dialogResult = MessageBox.Show("Are you sure want to logout?", "Logout", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    this.Hide();
                    if (formLoginStaff != null)
                    {
                        formLoginStaff.Show();
                    }
                    else
                    {
                        MessageBox.Show("error");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"error: {ex.Message}");
                }
                
            }
            else
            {
                // tidak akan terjadi apa" akan tetap di Main Page
            }
        }

        AddKategoriBaru addKategoriBaru;
        private void addKategoriBaruToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hide();
            mainHide();
            if (addKategoriBaru == null)
            {
                addKategoriBaru = new AddKategoriBaru(this);
                addKategoriBaru.MdiParent = this;
            }
            addKategoriBaru.Show();
        }
        AddProdukBaru addProdukBaru;
        private void addProdukBaruToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hide();
            mainHide();
            if (addProdukBaru == null)
            {
                addProdukBaru = new AddProdukBaru(this);
                addProdukBaru.MdiParent = this;
            }
            addProdukBaru.Show();
        }

        UpdateProduk updateProduk;
        private void updateProdukToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hide();
            mainHide();
            if (updateProduk == null)
            {
                updateProduk = new UpdateProduk(this);
                updateProduk.MdiParent = this;
            }
            updateProduk.Show();
        }
        ProdukPage produkPage;
        private void produkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hide();
            mainHide();
            if (produkPage == null)
            {
                produkPage = new ProdukPage(this);
                produkPage.MdiParent = this;
            }
            produkPage.Show();

        }

        private void mainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childform in this.MdiChildren)
            {
                childform.Hide();
            }
            this.Show();
            panelMain.Visible = true;
        }
        
        private void hide()
        {
            foreach (Form childForm in this.MdiChildren)
            {
                childForm.Hide();
            }
        }

        private void mainHide()
        {
            panelMain.Visible = false;
        }

        
    }
}
