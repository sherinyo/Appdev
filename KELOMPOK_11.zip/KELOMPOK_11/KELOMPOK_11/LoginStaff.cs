﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace KELOMPOK_11
{
    public partial class LoginStaff : Form
    {
        MainPage openMainPage;
        public LoginStaff()
        {
            InitializeComponent();
        }

        // CONNECT TO DATABASE
        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        private void btn_login_Click(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = kelompok11");
            try
            {
                connection.Open();
                
                string staffID = tb_staffID.Text;
                string password = "12345678";
                string queryLogin = "select count(*) from STAFF where STAFF_ID = @staffID";
                DataTable dtStaff = new DataTable();

                command = new MySqlCommand(queryLogin, connection);
                command.Parameters.AddWithValue("@staffID", staffID);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtStaff);

                int cnt = 0;

                for (int i = 0; i < dtStaff.Rows.Count; i++)
                {
                    cnt = Convert.ToInt32(dtStaff.Rows[0][i]);
                }

                if (staffID == "" || tb_password.Text == "")
                {
                    MessageBox.Show("Isi yang lengkap");
                }
                else if (tb_password.Text != password)
                {
                    MessageBox.Show("Password salah");
                }
                else if (cnt == 0)
                {
                    MessageBox.Show("Staff ID not found");
                }
                else
                {
                    MessageBox.Show("Login Successful");

                    // go to Main Page
                    openMainPage = new MainPage(this, staffID);
                    openMainPage.Show();
                    this.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
            
            tb_password.Clear();
            tb_staffID.Clear();

            
            
        }

        
    }
    
}
