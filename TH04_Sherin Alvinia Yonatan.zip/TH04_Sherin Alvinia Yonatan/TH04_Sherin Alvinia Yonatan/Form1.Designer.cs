﻿namespace TH04_Sherin_Alvinia_Yonatan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_soccerteamlist = new System.Windows.Forms.Label();
            this.lbl_choosecountry = new System.Windows.Forms.Label();
            this.lbl_chooseteam = new System.Windows.Forms.Label();
            this.cb_choosecountry = new System.Windows.Forms.ComboBox();
            this.cb_chooseteam = new System.Windows.Forms.ComboBox();
            this.lb_anggotaTeam = new System.Windows.Forms.ListBox();
            this.btn_removePlayer = new System.Windows.Forms.Button();
            this.label_teamname = new System.Windows.Forms.Label();
            this.lbl_teamcountry = new System.Windows.Forms.Label();
            this.lbl_teamcity = new System.Windows.Forms.Label();
            this.tb_teamName = new System.Windows.Forms.TextBox();
            this.tb_teamCountry = new System.Windows.Forms.TextBox();
            this.tb_teamCity = new System.Windows.Forms.TextBox();
            this.btn_addTeam = new System.Windows.Forms.Button();
            this.lbl_addingTeam = new System.Windows.Forms.Label();
            this.lbl_addingplayer = new System.Windows.Forms.Label();
            this.btn_addPlayer = new System.Windows.Forms.Button();
            this.tb_playerNumber = new System.Windows.Forms.TextBox();
            this.tb_playerName = new System.Windows.Forms.TextBox();
            this.lbl_playerPosition = new System.Windows.Forms.Label();
            this.lbl_playerNumber = new System.Windows.Forms.Label();
            this.lbl_playerName = new System.Windows.Forms.Label();
            this.cb_playerPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lbl_soccerteamlist
            // 
            this.lbl_soccerteamlist.AutoSize = true;
            this.lbl_soccerteamlist.Location = new System.Drawing.Point(57, 76);
            this.lbl_soccerteamlist.Name = "lbl_soccerteamlist";
            this.lbl_soccerteamlist.Size = new System.Drawing.Size(132, 20);
            this.lbl_soccerteamlist.TabIndex = 0;
            this.lbl_soccerteamlist.Text = "Soccer Team List";
            // 
            // lbl_choosecountry
            // 
            this.lbl_choosecountry.AutoSize = true;
            this.lbl_choosecountry.Location = new System.Drawing.Point(57, 131);
            this.lbl_choosecountry.Name = "lbl_choosecountry";
            this.lbl_choosecountry.Size = new System.Drawing.Size(127, 20);
            this.lbl_choosecountry.TabIndex = 1;
            this.lbl_choosecountry.Text = "Choose Country:";
            // 
            // lbl_chooseteam
            // 
            this.lbl_chooseteam.AutoSize = true;
            this.lbl_chooseteam.Location = new System.Drawing.Point(57, 179);
            this.lbl_chooseteam.Name = "lbl_chooseteam";
            this.lbl_chooseteam.Size = new System.Drawing.Size(112, 20);
            this.lbl_chooseteam.TabIndex = 2;
            this.lbl_chooseteam.Text = "Choose Team:";
            // 
            // cb_choosecountry
            // 
            this.cb_choosecountry.FormattingEnabled = true;
            this.cb_choosecountry.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.cb_choosecountry.Location = new System.Drawing.Point(225, 126);
            this.cb_choosecountry.Name = "cb_choosecountry";
            this.cb_choosecountry.Size = new System.Drawing.Size(161, 28);
            this.cb_choosecountry.TabIndex = 3;
            this.cb_choosecountry.SelectedIndexChanged += new System.EventHandler(this.cb_choosecountry_SelectedIndexChanged);
            // 
            // cb_chooseteam
            // 
            this.cb_chooseteam.FormattingEnabled = true;
            this.cb_chooseteam.Location = new System.Drawing.Point(225, 174);
            this.cb_chooseteam.Name = "cb_chooseteam";
            this.cb_chooseteam.Size = new System.Drawing.Size(161, 28);
            this.cb_chooseteam.TabIndex = 4;
            this.cb_chooseteam.SelectedIndexChanged += new System.EventHandler(this.cb_chooseteam_SelectedIndexChanged);
            // 
            // lb_anggotaTeam
            // 
            this.lb_anggotaTeam.FormattingEnabled = true;
            this.lb_anggotaTeam.ItemHeight = 20;
            this.lb_anggotaTeam.Location = new System.Drawing.Point(61, 226);
            this.lb_anggotaTeam.Name = "lb_anggotaTeam";
            this.lb_anggotaTeam.Size = new System.Drawing.Size(325, 164);
            this.lb_anggotaTeam.TabIndex = 5;
            // 
            // btn_removePlayer
            // 
            this.btn_removePlayer.Location = new System.Drawing.Point(61, 409);
            this.btn_removePlayer.Name = "btn_removePlayer";
            this.btn_removePlayer.Size = new System.Drawing.Size(108, 39);
            this.btn_removePlayer.TabIndex = 6;
            this.btn_removePlayer.Text = "Remove";
            this.btn_removePlayer.UseVisualStyleBackColor = true;
            this.btn_removePlayer.Click += new System.EventHandler(this.btn_removePlayer_Click);
            // 
            // label_teamname
            // 
            this.label_teamname.AutoSize = true;
            this.label_teamname.Location = new System.Drawing.Point(489, 132);
            this.label_teamname.Name = "label_teamname";
            this.label_teamname.Size = new System.Drawing.Size(99, 20);
            this.label_teamname.TabIndex = 7;
            this.label_teamname.Text = "Team Name:";
            // 
            // lbl_teamcountry
            // 
            this.lbl_teamcountry.AutoSize = true;
            this.lbl_teamcountry.Location = new System.Drawing.Point(489, 171);
            this.lbl_teamcountry.Name = "lbl_teamcountry";
            this.lbl_teamcountry.Size = new System.Drawing.Size(112, 20);
            this.lbl_teamcountry.TabIndex = 8;
            this.lbl_teamcountry.Text = "Team Country:";
            // 
            // lbl_teamcity
            // 
            this.lbl_teamcity.AutoSize = true;
            this.lbl_teamcity.Location = new System.Drawing.Point(489, 215);
            this.lbl_teamcity.Name = "lbl_teamcity";
            this.lbl_teamcity.Size = new System.Drawing.Size(83, 20);
            this.lbl_teamcity.TabIndex = 9;
            this.lbl_teamcity.Text = "Team City:";
            // 
            // tb_teamName
            // 
            this.tb_teamName.Location = new System.Drawing.Point(614, 130);
            this.tb_teamName.Name = "tb_teamName";
            this.tb_teamName.Size = new System.Drawing.Size(169, 26);
            this.tb_teamName.TabIndex = 10;
            // 
            // tb_teamCountry
            // 
            this.tb_teamCountry.Location = new System.Drawing.Point(614, 171);
            this.tb_teamCountry.Name = "tb_teamCountry";
            this.tb_teamCountry.Size = new System.Drawing.Size(169, 26);
            this.tb_teamCountry.TabIndex = 11;
            // 
            // tb_teamCity
            // 
            this.tb_teamCity.Location = new System.Drawing.Point(614, 212);
            this.tb_teamCity.Name = "tb_teamCity";
            this.tb_teamCity.Size = new System.Drawing.Size(169, 26);
            this.tb_teamCity.TabIndex = 12;
            // 
            // btn_addTeam
            // 
            this.btn_addTeam.Location = new System.Drawing.Point(614, 258);
            this.btn_addTeam.Name = "btn_addTeam";
            this.btn_addTeam.Size = new System.Drawing.Size(68, 39);
            this.btn_addTeam.TabIndex = 13;
            this.btn_addTeam.Text = "Add";
            this.btn_addTeam.UseVisualStyleBackColor = true;
            this.btn_addTeam.Click += new System.EventHandler(this.btn_addTeam_Click);
            // 
            // lbl_addingTeam
            // 
            this.lbl_addingTeam.AutoSize = true;
            this.lbl_addingTeam.Location = new System.Drawing.Point(610, 76);
            this.lbl_addingTeam.Name = "lbl_addingTeam";
            this.lbl_addingTeam.Size = new System.Drawing.Size(103, 20);
            this.lbl_addingTeam.TabIndex = 14;
            this.lbl_addingTeam.Text = "Adding Team";
            // 
            // lbl_addingplayer
            // 
            this.lbl_addingplayer.AutoSize = true;
            this.lbl_addingplayer.Location = new System.Drawing.Point(975, 71);
            this.lbl_addingplayer.Name = "lbl_addingplayer";
            this.lbl_addingplayer.Size = new System.Drawing.Size(106, 20);
            this.lbl_addingplayer.TabIndex = 22;
            this.lbl_addingplayer.Text = "Adding Player";
            // 
            // btn_addPlayer
            // 
            this.btn_addPlayer.Location = new System.Drawing.Point(979, 253);
            this.btn_addPlayer.Name = "btn_addPlayer";
            this.btn_addPlayer.Size = new System.Drawing.Size(68, 39);
            this.btn_addPlayer.TabIndex = 21;
            this.btn_addPlayer.Text = "Add";
            this.btn_addPlayer.UseVisualStyleBackColor = true;
            this.btn_addPlayer.Click += new System.EventHandler(this.btn_addPlayer_Click);
            // 
            // tb_playerNumber
            // 
            this.tb_playerNumber.Location = new System.Drawing.Point(979, 166);
            this.tb_playerNumber.Name = "tb_playerNumber";
            this.tb_playerNumber.Size = new System.Drawing.Size(169, 26);
            this.tb_playerNumber.TabIndex = 19;
            // 
            // tb_playerName
            // 
            this.tb_playerName.Location = new System.Drawing.Point(979, 125);
            this.tb_playerName.Name = "tb_playerName";
            this.tb_playerName.Size = new System.Drawing.Size(169, 26);
            this.tb_playerName.TabIndex = 18;
            // 
            // lbl_playerPosition
            // 
            this.lbl_playerPosition.AutoSize = true;
            this.lbl_playerPosition.Location = new System.Drawing.Point(854, 210);
            this.lbl_playerPosition.Name = "lbl_playerPosition";
            this.lbl_playerPosition.Size = new System.Drawing.Size(116, 20);
            this.lbl_playerPosition.TabIndex = 17;
            this.lbl_playerPosition.Text = "Player Position:";
            // 
            // lbl_playerNumber
            // 
            this.lbl_playerNumber.AutoSize = true;
            this.lbl_playerNumber.Location = new System.Drawing.Point(854, 166);
            this.lbl_playerNumber.Name = "lbl_playerNumber";
            this.lbl_playerNumber.Size = new System.Drawing.Size(116, 20);
            this.lbl_playerNumber.TabIndex = 16;
            this.lbl_playerNumber.Text = "Player Number:";
            // 
            // lbl_playerName
            // 
            this.lbl_playerName.AutoSize = true;
            this.lbl_playerName.Location = new System.Drawing.Point(854, 127);
            this.lbl_playerName.Name = "lbl_playerName";
            this.lbl_playerName.Size = new System.Drawing.Size(102, 20);
            this.lbl_playerName.TabIndex = 15;
            this.lbl_playerName.Text = "Player Name:";
            // 
            // cb_playerPosition
            // 
            this.cb_playerPosition.FormattingEnabled = true;
            this.cb_playerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_playerPosition.Location = new System.Drawing.Point(979, 206);
            this.cb_playerPosition.Name = "cb_playerPosition";
            this.cb_playerPosition.Size = new System.Drawing.Size(169, 28);
            this.cb_playerPosition.TabIndex = 23;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1303, 734);
            this.Controls.Add(this.cb_playerPosition);
            this.Controls.Add(this.lbl_addingplayer);
            this.Controls.Add(this.btn_addPlayer);
            this.Controls.Add(this.tb_playerNumber);
            this.Controls.Add(this.tb_playerName);
            this.Controls.Add(this.lbl_playerPosition);
            this.Controls.Add(this.lbl_playerNumber);
            this.Controls.Add(this.lbl_playerName);
            this.Controls.Add(this.lbl_addingTeam);
            this.Controls.Add(this.btn_addTeam);
            this.Controls.Add(this.tb_teamCity);
            this.Controls.Add(this.tb_teamCountry);
            this.Controls.Add(this.tb_teamName);
            this.Controls.Add(this.lbl_teamcity);
            this.Controls.Add(this.lbl_teamcountry);
            this.Controls.Add(this.label_teamname);
            this.Controls.Add(this.btn_removePlayer);
            this.Controls.Add(this.lb_anggotaTeam);
            this.Controls.Add(this.cb_chooseteam);
            this.Controls.Add(this.cb_choosecountry);
            this.Controls.Add(this.lbl_chooseteam);
            this.Controls.Add(this.lbl_choosecountry);
            this.Controls.Add(this.lbl_soccerteamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_soccerteamlist;
        private System.Windows.Forms.Label lbl_choosecountry;
        private System.Windows.Forms.Label lbl_chooseteam;
        private System.Windows.Forms.ComboBox cb_choosecountry;
        private System.Windows.Forms.ComboBox cb_chooseteam;
        private System.Windows.Forms.ListBox lb_anggotaTeam;
        private System.Windows.Forms.Button btn_removePlayer;
        private System.Windows.Forms.Label label_teamname;
        private System.Windows.Forms.Label lbl_teamcountry;
        private System.Windows.Forms.Label lbl_teamcity;
        private System.Windows.Forms.TextBox tb_teamName;
        private System.Windows.Forms.TextBox tb_teamCountry;
        private System.Windows.Forms.TextBox tb_teamCity;
        private System.Windows.Forms.Button btn_addTeam;
        private System.Windows.Forms.Label lbl_addingTeam;
        private System.Windows.Forms.Label lbl_addingplayer;
        private System.Windows.Forms.Button btn_addPlayer;
        private System.Windows.Forms.TextBox tb_playerNumber;
        private System.Windows.Forms.TextBox tb_playerName;
        private System.Windows.Forms.Label lbl_playerPosition;
        private System.Windows.Forms.Label lbl_playerNumber;
        private System.Windows.Forms.Label lbl_playerName;
        private System.Windows.Forms.ComboBox cb_playerPosition;
    }
}

