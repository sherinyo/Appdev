﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace TH04_Sherin_Alvinia_Yonatan
{
    public partial class Form1 : Form
    {
        private DataTable dataTeam;
        public string chooseTeam;
        public DataRow[] Players;
        public Form1()
        {
            InitializeComponent();
            MasukkanDataTeam();
        }

        private void MasukkanDataTeam()
        {
            dataTeam = new DataTable();
            dataTeam.Columns.Add("Team Name", typeof(string));
            dataTeam.Columns.Add("Team Country", typeof(string));
            dataTeam.Columns.Add("Team City", typeof(string));
            dataTeam.Columns.Add("Player Name", typeof(string));
            dataTeam.Columns.Add("Player Number", typeof(string));
            dataTeam.Columns.Add("Player Position", typeof(string));

            // Manchester United
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "David De Gea", "01", "GK");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Victor Lindelof", "02", "DF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Phil Jones", "04", "DF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Harry Maguire", "05", "DF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Lisandro Martinez", "06", "DF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Bruno Fernandez", "08", "MF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Anthony Martial", "09", "FW");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Marcus Rashford", "10", "FW");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Tyrell Malacia", "12", "DF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Christian Eriksen", "14", "MF");
            dataTeam.Rows.Add("Manchester United", "England", "Manchester", "Casemiro", "18", "MF");

            // Chelsea
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Kepa Arrizabalaga", "01", "GK");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Benoit Badaiashile", "04", "DF");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Enzo Fernandez", "05", "MF");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Thiago Silva", "61", "DF");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "N'Golo Kante", "07", "MF");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Pierre-Emerick Aubameyang", "09", "FW");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Christian Pulisic", "10", "MF");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Joao Felix", "11", "FW");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Ruben Loftus-Cheek", "12", "MF");
            dataTeam.Rows.Add("Chelsea", "England", "Fulham", "Raheem Sterling", "17", "MF");

            // Bayern Munich
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Manuel Neuer", "01", "GK");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Dayot Upamecano", "02", "DF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Matthijis de Ligt", "04", "DF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Benjamin Pavard", "05", "DF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Joshua Kimmich", "06", "MF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Serge Gnabry", "07", "FW");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Leon Goretzka", "08", "MF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Leroy Sane", "10", "FW");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Paul Wanner", "14", "MF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Lucas Hernandez", "21", "DF");
            dataTeam.Rows.Add("Bayern Munich", "Germany", "Munich", "Thomas Muller", "25", "FW");

        }


        private void cb_choosecountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> doubleTeamName = new List<string>();
            string chooseCountry = cb_choosecountry.SelectedItem.ToString();
            cb_chooseteam.Items.Clear();
            

            foreach (DataRow row in dataTeam.Rows)
            {
                if (row["Team Country"].ToString() == chooseCountry)
                {
                    string opsiTeam = row["Team Name"].ToString();
                    if (!doubleTeamName.Contains(opsiTeam))
                    {
                        cb_chooseteam.Items.Add(opsiTeam);
                        doubleTeamName.Add(opsiTeam);
                    }
                }
            }
            lb_anggotaTeam.Items.Clear();
            cb_chooseteam.Text = "";
        }

        private void cb_chooseteam_SelectedIndexChanged(object sender, EventArgs e)
        {
            string chooseTeam = cb_chooseteam.SelectedItem.ToString();
            Players = dataTeam.Select($"[Team Name] = '{chooseTeam}'");
            lb_anggotaTeam.Items.Clear();

            foreach (DataRow player in Players)
            { 
                if (player["Player Number"].ToString() != "00")
                {
                    lb_anggotaTeam.Items.Add($"({player["Player Number"]}) {player["Player Name"]}, {player["Player Position"]}");
                }
                
            }
        }


        private void btn_addTeam_Click(object sender, EventArgs e)
        {
            string TeamName = tb_teamName.Text;
            string TeamCountry = tb_teamCountry.Text;
            string TeamCity = tb_teamCity.Text;


            if (tb_teamName.Text != "" || tb_teamCountry.Text != "" || tb_teamCity.Text != "")
            {
                bool cekKembar = false;
                foreach (DataRow row in dataTeam.Rows)
                {
                    if (row["Team Name"].ToString() == TeamName && row["Team Country"].ToString() == TeamCountry)
                    {
                        cekKembar = true;
                        break;
                    }
                }
                if (cekKembar)
                {
                    MessageBox.Show("Team name already exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {

                    dataTeam.Rows.Add(TeamName, TeamCountry, TeamCity, "", "00", "");
                    cb_chooseteam.Items.Add(TeamName);

                    if (!cb_choosecountry.Items.Contains(TeamCountry))
                    {
                        cb_choosecountry.Items.Add(TeamCountry);
                    }
                    
                    tb_teamName.Clear();
                    tb_teamCountry.Clear();
                    tb_teamCity.Clear();
                }
            }   
            else
            {
                MessageBox.Show("All fields need to be field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            cb_chooseteam.Items.Clear();
        }

        private void btn_addPlayer_Click(object sender, EventArgs e)
        {
            string playerName = tb_playerName.Text;
            string playerNumber = tb_playerNumber.Text;
            string playerPosition = cb_playerPosition.SelectedItem?.ToString();

            if (tb_playerName.Text != "" || tb_playerNumber.Text != "" || cb_playerPosition.SelectedItem.ToString() != "")
            {
                DataRow[] teamPilih = dataTeam.Select($"[Team name] = '{cb_chooseteam.SelectedItem.ToString()}' AND [Team Country] = '{cb_choosecountry.SelectedItem.ToString()}'");
                
                if (teamPilih.Length > 0)
                {
                    bool cekAngka = false;
                    foreach (DataRow row in teamPilih)
                    {
                        if (row["Player Number"].ToString() == playerNumber)
                        {
                            cekAngka = true;
                            break;
                        }
                    }

                    if (cekAngka)
                    {
                        MessageBox.Show("Player with the same number already exists in the selected team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        DataRow addPlayer = dataTeam.NewRow();
                        addPlayer["Team Name"] = teamPilih[0]["Team Name"];
                        addPlayer["Team Country"] = teamPilih[0]["Team Country"];
                        addPlayer["Team City"] = teamPilih[0]["Team City"];
                        addPlayer["Player Name"] = playerName;
                        addPlayer["Player Number"] = playerNumber;
                        addPlayer["Player Position"] = playerPosition;
                        dataTeam.Rows.Add(addPlayer);
                        lb_anggotaTeam.Items.Add($"({playerNumber}) {playerName}, {playerPosition}");
                    }
                }
                else
                {
                    MessageBox.Show("Please choose a country and team name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            else
            {
                MessageBox.Show("All fields need to be field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            tb_playerName.Clear();
            tb_playerNumber.Clear();
            cb_playerPosition.SelectedItem = null;
        }


        private void btn_removePlayer_Click(object sender, EventArgs e)
        {
            string selectedPlayer = lb_anggotaTeam.SelectedItem?.ToString();
            if (lb_anggotaTeam.Items.Count < 12)
            {
                MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else if (selectedPlayer != null && lb_anggotaTeam.Items.Count > 11)
            {
                string playerNumber = selectedPlayer.Substring(selectedPlayer.IndexOf("(") + 1, selectedPlayer.IndexOf(")") - selectedPlayer.IndexOf("(") - 1);
                DataRow[] playerToRemove = dataTeam.Select($"[Player Number] = '{playerNumber}'");
                if (playerToRemove.Length > 0)
                {
                    dataTeam.Rows.Remove(playerToRemove[0]);
                }
                lb_anggotaTeam.Items.Remove(selectedPlayer);
            }


            if (selectedPlayer == null)
            {
                MessageBox.Show("Please select a player to remove", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
