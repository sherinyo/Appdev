﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02_Sherin_Alvinia_Yonatan
{
    public partial class Form1 : Form
    {
        // SHERIN ALVINIA YONATAN - 0706022310013
        public Form1()
        {
            InitializeComponent();
            panel_menu.Visible = true;
            panel_menuGame.Visible = false;
        }

        static bool angka_simbol(string inputan) // mengecek apakah ada angka atau simbol
        {
            foreach (char num_simbol in inputan)
            {
                if (!char.IsLetter(num_simbol))
                {
                    return true;
                }
            }
            return false;
        }

        char[] tebakHuruf = { '_', '_', '_', '_', '_' };
        List<char> simpanHuruf = new List<char>();
        
        private void btn_play_Click(object sender, EventArgs e) // menu awal
        {

            // seandainya ada yang kosong
            if (tb_word1.Text == "" || tb_word2.Text == "" || tb_word3.Text == "" || tb_word4.Text == "" || tb_word5.Text == "")
            {
                MessageBox.Show("Error");
            }
            // seandainya bukan 5 huruf
            else if (tb_word1.TextLength != 5 || tb_word2.TextLength != 5 || tb_word3.TextLength != 5 || tb_word4.TextLength != 5 || tb_word5.TextLength != 5)
            {
                MessageBox.Show("Error");
            }
            // seandainya ada word yang sama
            else if (tb_word1.Text == tb_word2.Text || tb_word1.Text == tb_word3.Text || tb_word1.Text == tb_word4.Text || tb_word1.Text == tb_word5.Text || tb_word2.Text == tb_word3.Text || tb_word2.Text == tb_word4.Text || tb_word2.Text == tb_word5.Text || tb_word3.Text == tb_word4.Text || tb_word3.Text == tb_word5.Text || tb_word4.Text == tb_word5.Text)
            {
                MessageBox.Show("Error");
            }
            else if (angka_simbol(tb_word1.Text) || angka_simbol(tb_word2.Text) || angka_simbol(tb_word3.Text) || angka_simbol(tb_word4.Text) || angka_simbol(tb_word5.Text))
            {
                MessageBox.Show("Error");
            }
            else
            {
                panel_menu.Visible = false;
                panel_menuGame.Visible = true;
            }

            // Menu Game
            if (panel_menu.Visible == false && panel_menuGame.Visible == true)
            {
                panel_menuGame.Visible = true;
                string[] InputanWord = { tb_word1.Text.ToLower(), tb_word2.Text.ToLower(), tb_word3.Text.ToLower(), tb_word4.Text.ToLower(), tb_word5.Text.ToLower() };
                string tebakWord = InputanWord[new Random().Next(0, InputanWord.Length)];
                lbl_randomWord.Text = tebakWord.ToUpper();
                foreach (char huruf in tebakWord) // word yang akan ditebak, akan menyimpan huruf apa saja di dalam list
                {
                    simpanHuruf.Add(huruf);
                }             
            }
        }
        
        private void panel_menuGame_Paint(object sender, PaintEventArgs e) // menu game tebak
        {
            lbl_strip1.Text = tebakHuruf[0].ToString().ToUpper();
            lbl_strip2.Text = tebakHuruf[1].ToString().ToUpper();
            lbl_strip3.Text = tebakHuruf[2].ToString().ToUpper();
            lbl_strip4.Text = tebakHuruf[3].ToString().ToUpper();
            lbl_strip5.Text = tebakHuruf[4].ToString().ToUpper();
        }

        private void tebakKata(char hurufTebakan)
        {
            if (simpanHuruf.Contains(hurufTebakan))
            {
                for (int i = 0; i < simpanHuruf.Count; i++)
                {
                    if (simpanHuruf[i] == hurufTebakan)
                    {
                        tebakHuruf[i] = hurufTebakan;
                    }
                }
                panel_menuGame.Refresh();
            }
            
            if(!tebakHuruf.Contains('_'))
            {
                MessageBox.Show("Berhasil!");
            }
        }

        private void btn_l_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'l';
            tebakKata(tebakHuruf);
        }

        private void btn_k_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'k';
            tebakKata(tebakHuruf);
        }

        private void btn_j_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'j';
            tebakKata(tebakHuruf);
        }

        private void btn_h_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'h';
            tebakKata(tebakHuruf);
        }

        private void btn_g_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'q';
            tebakKata(tebakHuruf);
        }

        private void btn_f_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'f';
            tebakKata(tebakHuruf);
        }

        private void btn_d_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'd';
            tebakKata(tebakHuruf);
        }

        private void btn_z_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'z';
            tebakKata(tebakHuruf);
        }

        private void btn_m_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'm';
            tebakKata(tebakHuruf);
        }

        private void btn_n_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'n';
            tebakKata(tebakHuruf);
        }

        private void btn_b_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'b';
            tebakKata(tebakHuruf);
        }

        private void btn_v_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'v';
            tebakKata(tebakHuruf);
        }

        private void btn_c_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'c';
            tebakKata(tebakHuruf);
        }

        private void btn_x_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'x';
            tebakKata(tebakHuruf);
        }

        private void btn_s_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 's';
            tebakKata(tebakHuruf);
        }

        private void btn_a_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'a';
            tebakKata(tebakHuruf);
        }

        private void btn_p_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'p';
            tebakKata(tebakHuruf);
        }

        private void btn_o_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'o';
            tebakKata(tebakHuruf);
        }

        private void btn_i_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'i';
            tebakKata(tebakHuruf);
        }

        private void btn_u_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'u';
            tebakKata(tebakHuruf);
        }

        private void btn_y_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'y';
            tebakKata(tebakHuruf);
        }

        private void btn_t_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 't';
            tebakKata(tebakHuruf);
        }

        private void btn_r_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'r';
            tebakKata(tebakHuruf);
        }

        private void btn_e_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'e';
            tebakKata(tebakHuruf);
        }

        private void btn_w_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'w';
            tebakKata(tebakHuruf);
        }

        private void btn_q_Click(object sender, EventArgs e)
        {
            char tebakHuruf = 'q';
            tebakKata(tebakHuruf);
        }
    }
}
