﻿namespace TH02_Sherin_Alvinia_Yonatan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_word1 = new System.Windows.Forms.Label();
            this.label_word2 = new System.Windows.Forms.Label();
            this.label_word5 = new System.Windows.Forms.Label();
            this.label_word4 = new System.Windows.Forms.Label();
            this.label_word3 = new System.Windows.Forms.Label();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.btn_play = new System.Windows.Forms.Button();
            this.panel_menu = new System.Windows.Forms.Panel();
            this.lbl_strip1 = new System.Windows.Forms.Label();
            this.lbl_strip2 = new System.Windows.Forms.Label();
            this.lbl_strip3 = new System.Windows.Forms.Label();
            this.lbl_strip4 = new System.Windows.Forms.Label();
            this.lbl_strip5 = new System.Windows.Forms.Label();
            this.lbl_randomWord = new System.Windows.Forms.Label();
            this.panel_menuGame = new System.Windows.Forms.Panel();
            this.btn_x = new System.Windows.Forms.Button();
            this.btn_c = new System.Windows.Forms.Button();
            this.btn_v = new System.Windows.Forms.Button();
            this.btn_b = new System.Windows.Forms.Button();
            this.btn_n = new System.Windows.Forms.Button();
            this.btn_m = new System.Windows.Forms.Button();
            this.btn_z = new System.Windows.Forms.Button();
            this.btn_s = new System.Windows.Forms.Button();
            this.btn_d = new System.Windows.Forms.Button();
            this.btn_f = new System.Windows.Forms.Button();
            this.btn_g = new System.Windows.Forms.Button();
            this.btn_h = new System.Windows.Forms.Button();
            this.btn_j = new System.Windows.Forms.Button();
            this.btn_k = new System.Windows.Forms.Button();
            this.btn_l = new System.Windows.Forms.Button();
            this.btn_a = new System.Windows.Forms.Button();
            this.btn_p = new System.Windows.Forms.Button();
            this.btn_w = new System.Windows.Forms.Button();
            this.btn_e = new System.Windows.Forms.Button();
            this.btn_r = new System.Windows.Forms.Button();
            this.btn_t = new System.Windows.Forms.Button();
            this.btn_y = new System.Windows.Forms.Button();
            this.btn_u = new System.Windows.Forms.Button();
            this.btn_i = new System.Windows.Forms.Button();
            this.btn_o = new System.Windows.Forms.Button();
            this.btn_q = new System.Windows.Forms.Button();
            this.panel_menu.SuspendLayout();
            this.panel_menuGame.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_word1
            // 
            this.label_word1.AutoSize = true;
            this.label_word1.Location = new System.Drawing.Point(43, 17);
            this.label_word1.Name = "label_word1";
            this.label_word1.Size = new System.Drawing.Size(60, 20);
            this.label_word1.TabIndex = 0;
            this.label_word1.Text = "Word 1";
            // 
            // label_word2
            // 
            this.label_word2.AutoSize = true;
            this.label_word2.Location = new System.Drawing.Point(43, 56);
            this.label_word2.Name = "label_word2";
            this.label_word2.Size = new System.Drawing.Size(60, 20);
            this.label_word2.TabIndex = 1;
            this.label_word2.Text = "Word 2";
            // 
            // label_word5
            // 
            this.label_word5.AutoSize = true;
            this.label_word5.Location = new System.Drawing.Point(43, 164);
            this.label_word5.Name = "label_word5";
            this.label_word5.Size = new System.Drawing.Size(60, 20);
            this.label_word5.TabIndex = 2;
            this.label_word5.Text = "Word 5";
            // 
            // label_word4
            // 
            this.label_word4.AutoSize = true;
            this.label_word4.Location = new System.Drawing.Point(43, 131);
            this.label_word4.Name = "label_word4";
            this.label_word4.Size = new System.Drawing.Size(60, 20);
            this.label_word4.TabIndex = 3;
            this.label_word4.Text = "Word 4";
            // 
            // label_word3
            // 
            this.label_word3.AutoSize = true;
            this.label_word3.Location = new System.Drawing.Point(43, 93);
            this.label_word3.Name = "label_word3";
            this.label_word3.Size = new System.Drawing.Size(60, 20);
            this.label_word3.TabIndex = 4;
            this.label_word3.Text = "Word 3";
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(123, 14);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(147, 26);
            this.tb_word1.TabIndex = 5;
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(123, 161);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(147, 26);
            this.tb_word5.TabIndex = 6;
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(123, 126);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(147, 26);
            this.tb_word4.TabIndex = 7;
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(123, 90);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(147, 26);
            this.tb_word3.TabIndex = 8;
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(123, 52);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(147, 26);
            this.tb_word2.TabIndex = 9;
            // 
            // btn_play
            // 
            this.btn_play.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_play.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_play.Location = new System.Drawing.Point(195, 203);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(75, 35);
            this.btn_play.TabIndex = 10;
            this.btn_play.Text = "PLAY";
            this.btn_play.UseVisualStyleBackColor = false;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // panel_menu
            // 
            this.panel_menu.Controls.Add(this.tb_word3);
            this.panel_menu.Controls.Add(this.btn_play);
            this.panel_menu.Controls.Add(this.label_word1);
            this.panel_menu.Controls.Add(this.tb_word2);
            this.panel_menu.Controls.Add(this.label_word2);
            this.panel_menu.Controls.Add(this.label_word5);
            this.panel_menu.Controls.Add(this.tb_word4);
            this.panel_menu.Controls.Add(this.label_word4);
            this.panel_menu.Controls.Add(this.tb_word5);
            this.panel_menu.Controls.Add(this.label_word3);
            this.panel_menu.Controls.Add(this.tb_word1);
            this.panel_menu.Location = new System.Drawing.Point(12, 12);
            this.panel_menu.Name = "panel_menu";
            this.panel_menu.Size = new System.Drawing.Size(302, 253);
            this.panel_menu.TabIndex = 11;
            // 
            // lbl_strip1
            // 
            this.lbl_strip1.AutoSize = true;
            this.lbl_strip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_strip1.Location = new System.Drawing.Point(291, 34);
            this.lbl_strip1.Name = "lbl_strip1";
            this.lbl_strip1.Size = new System.Drawing.Size(43, 46);
            this.lbl_strip1.TabIndex = 12;
            this.lbl_strip1.Text = "_";
            // 
            // lbl_strip2
            // 
            this.lbl_strip2.AutoSize = true;
            this.lbl_strip2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_strip2.Location = new System.Drawing.Point(340, 34);
            this.lbl_strip2.Name = "lbl_strip2";
            this.lbl_strip2.Size = new System.Drawing.Size(43, 46);
            this.lbl_strip2.TabIndex = 13;
            this.lbl_strip2.Text = "_";
            // 
            // lbl_strip3
            // 
            this.lbl_strip3.AutoSize = true;
            this.lbl_strip3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_strip3.Location = new System.Drawing.Point(389, 34);
            this.lbl_strip3.Name = "lbl_strip3";
            this.lbl_strip3.Size = new System.Drawing.Size(43, 46);
            this.lbl_strip3.TabIndex = 14;
            this.lbl_strip3.Text = "_";
            // 
            // lbl_strip4
            // 
            this.lbl_strip4.AutoSize = true;
            this.lbl_strip4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_strip4.Location = new System.Drawing.Point(438, 34);
            this.lbl_strip4.Name = "lbl_strip4";
            this.lbl_strip4.Size = new System.Drawing.Size(43, 46);
            this.lbl_strip4.TabIndex = 15;
            this.lbl_strip4.Text = "_";
            // 
            // lbl_strip5
            // 
            this.lbl_strip5.AutoSize = true;
            this.lbl_strip5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_strip5.Location = new System.Drawing.Point(487, 34);
            this.lbl_strip5.Name = "lbl_strip5";
            this.lbl_strip5.Size = new System.Drawing.Size(43, 46);
            this.lbl_strip5.TabIndex = 16;
            this.lbl_strip5.Text = "_";
            // 
            // lbl_randomWord
            // 
            this.lbl_randomWord.AutoSize = true;
            this.lbl_randomWord.Location = new System.Drawing.Point(589, 59);
            this.lbl_randomWord.Name = "lbl_randomWord";
            this.lbl_randomWord.Size = new System.Drawing.Size(14, 20);
            this.lbl_randomWord.TabIndex = 17;
            this.lbl_randomWord.Text = "-";
            // 
            // panel_menuGame
            // 
            this.panel_menuGame.Controls.Add(this.btn_x);
            this.panel_menuGame.Controls.Add(this.btn_c);
            this.panel_menuGame.Controls.Add(this.btn_v);
            this.panel_menuGame.Controls.Add(this.btn_b);
            this.panel_menuGame.Controls.Add(this.btn_n);
            this.panel_menuGame.Controls.Add(this.btn_m);
            this.panel_menuGame.Controls.Add(this.btn_z);
            this.panel_menuGame.Controls.Add(this.btn_s);
            this.panel_menuGame.Controls.Add(this.btn_d);
            this.panel_menuGame.Controls.Add(this.btn_f);
            this.panel_menuGame.Controls.Add(this.btn_g);
            this.panel_menuGame.Controls.Add(this.btn_h);
            this.panel_menuGame.Controls.Add(this.btn_j);
            this.panel_menuGame.Controls.Add(this.btn_k);
            this.panel_menuGame.Controls.Add(this.btn_l);
            this.panel_menuGame.Controls.Add(this.btn_a);
            this.panel_menuGame.Controls.Add(this.btn_p);
            this.panel_menuGame.Controls.Add(this.btn_w);
            this.panel_menuGame.Controls.Add(this.btn_e);
            this.panel_menuGame.Controls.Add(this.btn_r);
            this.panel_menuGame.Controls.Add(this.btn_t);
            this.panel_menuGame.Controls.Add(this.btn_y);
            this.panel_menuGame.Controls.Add(this.btn_u);
            this.panel_menuGame.Controls.Add(this.btn_i);
            this.panel_menuGame.Controls.Add(this.btn_o);
            this.panel_menuGame.Controls.Add(this.btn_q);
            this.panel_menuGame.Controls.Add(this.lbl_randomWord);
            this.panel_menuGame.Controls.Add(this.lbl_strip5);
            this.panel_menuGame.Controls.Add(this.lbl_strip2);
            this.panel_menuGame.Controls.Add(this.lbl_strip1);
            this.panel_menuGame.Controls.Add(this.lbl_strip4);
            this.panel_menuGame.Controls.Add(this.lbl_strip3);
            this.panel_menuGame.Location = new System.Drawing.Point(347, 68);
            this.panel_menuGame.Name = "panel_menuGame";
            this.panel_menuGame.Size = new System.Drawing.Size(803, 379);
            this.panel_menuGame.TabIndex = 18;
            this.panel_menuGame.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_menuGame_Paint);
            // 
            // btn_x
            // 
            this.btn_x.BackColor = System.Drawing.Color.DimGray;
            this.btn_x.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_x.Location = new System.Drawing.Point(270, 268);
            this.btn_x.Name = "btn_x";
            this.btn_x.Size = new System.Drawing.Size(53, 49);
            this.btn_x.TabIndex = 45;
            this.btn_x.Text = "X";
            this.btn_x.UseVisualStyleBackColor = false;
            this.btn_x.Click += new System.EventHandler(this.btn_x_Click);
            // 
            // btn_c
            // 
            this.btn_c.BackColor = System.Drawing.Color.DimGray;
            this.btn_c.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_c.Location = new System.Drawing.Point(329, 268);
            this.btn_c.Name = "btn_c";
            this.btn_c.Size = new System.Drawing.Size(53, 49);
            this.btn_c.TabIndex = 44;
            this.btn_c.Text = "C";
            this.btn_c.UseVisualStyleBackColor = false;
            this.btn_c.Click += new System.EventHandler(this.btn_c_Click);
            // 
            // btn_v
            // 
            this.btn_v.BackColor = System.Drawing.Color.DimGray;
            this.btn_v.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_v.Location = new System.Drawing.Point(388, 268);
            this.btn_v.Name = "btn_v";
            this.btn_v.Size = new System.Drawing.Size(53, 49);
            this.btn_v.TabIndex = 43;
            this.btn_v.Text = "V";
            this.btn_v.UseVisualStyleBackColor = false;
            this.btn_v.Click += new System.EventHandler(this.btn_v_Click);
            // 
            // btn_b
            // 
            this.btn_b.BackColor = System.Drawing.Color.DimGray;
            this.btn_b.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_b.Location = new System.Drawing.Point(447, 268);
            this.btn_b.Name = "btn_b";
            this.btn_b.Size = new System.Drawing.Size(53, 49);
            this.btn_b.TabIndex = 42;
            this.btn_b.Text = "B";
            this.btn_b.UseVisualStyleBackColor = false;
            this.btn_b.Click += new System.EventHandler(this.btn_b_Click);
            // 
            // btn_n
            // 
            this.btn_n.BackColor = System.Drawing.Color.DimGray;
            this.btn_n.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_n.Location = new System.Drawing.Point(506, 268);
            this.btn_n.Name = "btn_n";
            this.btn_n.Size = new System.Drawing.Size(53, 49);
            this.btn_n.TabIndex = 41;
            this.btn_n.Text = "N";
            this.btn_n.UseVisualStyleBackColor = false;
            this.btn_n.Click += new System.EventHandler(this.btn_n_Click);
            // 
            // btn_m
            // 
            this.btn_m.BackColor = System.Drawing.Color.DimGray;
            this.btn_m.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_m.Location = new System.Drawing.Point(565, 268);
            this.btn_m.Name = "btn_m";
            this.btn_m.Size = new System.Drawing.Size(53, 49);
            this.btn_m.TabIndex = 40;
            this.btn_m.Text = "M";
            this.btn_m.UseVisualStyleBackColor = false;
            this.btn_m.Click += new System.EventHandler(this.btn_m_Click);
            // 
            // btn_z
            // 
            this.btn_z.BackColor = System.Drawing.Color.DimGray;
            this.btn_z.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_z.Location = new System.Drawing.Point(211, 268);
            this.btn_z.Name = "btn_z";
            this.btn_z.Size = new System.Drawing.Size(53, 49);
            this.btn_z.TabIndex = 37;
            this.btn_z.Text = "Z";
            this.btn_z.UseVisualStyleBackColor = false;
            this.btn_z.Click += new System.EventHandler(this.btn_z_Click);
            // 
            // btn_s
            // 
            this.btn_s.BackColor = System.Drawing.Color.DimGray;
            this.btn_s.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_s.Location = new System.Drawing.Point(211, 213);
            this.btn_s.Name = "btn_s";
            this.btn_s.Size = new System.Drawing.Size(53, 49);
            this.btn_s.TabIndex = 36;
            this.btn_s.Text = "S";
            this.btn_s.UseVisualStyleBackColor = false;
            this.btn_s.Click += new System.EventHandler(this.btn_s_Click);
            // 
            // btn_d
            // 
            this.btn_d.BackColor = System.Drawing.Color.DimGray;
            this.btn_d.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_d.Location = new System.Drawing.Point(270, 213);
            this.btn_d.Name = "btn_d";
            this.btn_d.Size = new System.Drawing.Size(53, 49);
            this.btn_d.TabIndex = 35;
            this.btn_d.Text = "D";
            this.btn_d.UseVisualStyleBackColor = false;
            this.btn_d.Click += new System.EventHandler(this.btn_d_Click);
            // 
            // btn_f
            // 
            this.btn_f.BackColor = System.Drawing.Color.DimGray;
            this.btn_f.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_f.Location = new System.Drawing.Point(329, 213);
            this.btn_f.Name = "btn_f";
            this.btn_f.Size = new System.Drawing.Size(53, 49);
            this.btn_f.TabIndex = 34;
            this.btn_f.Text = "F";
            this.btn_f.UseVisualStyleBackColor = false;
            this.btn_f.Click += new System.EventHandler(this.btn_f_Click);
            // 
            // btn_g
            // 
            this.btn_g.BackColor = System.Drawing.Color.DimGray;
            this.btn_g.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_g.Location = new System.Drawing.Point(388, 213);
            this.btn_g.Name = "btn_g";
            this.btn_g.Size = new System.Drawing.Size(53, 49);
            this.btn_g.TabIndex = 33;
            this.btn_g.Text = "G";
            this.btn_g.UseVisualStyleBackColor = false;
            this.btn_g.Click += new System.EventHandler(this.btn_g_Click);
            // 
            // btn_h
            // 
            this.btn_h.BackColor = System.Drawing.Color.DimGray;
            this.btn_h.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_h.Location = new System.Drawing.Point(447, 213);
            this.btn_h.Name = "btn_h";
            this.btn_h.Size = new System.Drawing.Size(53, 49);
            this.btn_h.TabIndex = 32;
            this.btn_h.Text = "H";
            this.btn_h.UseVisualStyleBackColor = false;
            this.btn_h.Click += new System.EventHandler(this.btn_h_Click);
            // 
            // btn_j
            // 
            this.btn_j.BackColor = System.Drawing.Color.DimGray;
            this.btn_j.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_j.Location = new System.Drawing.Point(506, 213);
            this.btn_j.Name = "btn_j";
            this.btn_j.Size = new System.Drawing.Size(53, 49);
            this.btn_j.TabIndex = 31;
            this.btn_j.Text = "J";
            this.btn_j.UseVisualStyleBackColor = false;
            this.btn_j.Click += new System.EventHandler(this.btn_j_Click);
            // 
            // btn_k
            // 
            this.btn_k.BackColor = System.Drawing.Color.DimGray;
            this.btn_k.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_k.Location = new System.Drawing.Point(565, 213);
            this.btn_k.Name = "btn_k";
            this.btn_k.Size = new System.Drawing.Size(53, 49);
            this.btn_k.TabIndex = 30;
            this.btn_k.Text = "K";
            this.btn_k.UseVisualStyleBackColor = false;
            this.btn_k.Click += new System.EventHandler(this.btn_k_Click);
            // 
            // btn_l
            // 
            this.btn_l.BackColor = System.Drawing.Color.DimGray;
            this.btn_l.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_l.Location = new System.Drawing.Point(624, 213);
            this.btn_l.Name = "btn_l";
            this.btn_l.Size = new System.Drawing.Size(53, 49);
            this.btn_l.TabIndex = 29;
            this.btn_l.Text = "L";
            this.btn_l.UseVisualStyleBackColor = false;
            this.btn_l.Click += new System.EventHandler(this.btn_l_Click);
            // 
            // btn_a
            // 
            this.btn_a.BackColor = System.Drawing.Color.DimGray;
            this.btn_a.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_a.Location = new System.Drawing.Point(152, 213);
            this.btn_a.Name = "btn_a";
            this.btn_a.Size = new System.Drawing.Size(53, 49);
            this.btn_a.TabIndex = 28;
            this.btn_a.Text = "A";
            this.btn_a.UseVisualStyleBackColor = false;
            this.btn_a.Click += new System.EventHandler(this.btn_a_Click);
            // 
            // btn_p
            // 
            this.btn_p.BackColor = System.Drawing.Color.DimGray;
            this.btn_p.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_p.Location = new System.Drawing.Point(655, 158);
            this.btn_p.Name = "btn_p";
            this.btn_p.Size = new System.Drawing.Size(53, 49);
            this.btn_p.TabIndex = 27;
            this.btn_p.Text = "P";
            this.btn_p.UseVisualStyleBackColor = false;
            this.btn_p.Click += new System.EventHandler(this.btn_p_Click);
            // 
            // btn_w
            // 
            this.btn_w.BackColor = System.Drawing.Color.DimGray;
            this.btn_w.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_w.Location = new System.Drawing.Point(183, 158);
            this.btn_w.Name = "btn_w";
            this.btn_w.Size = new System.Drawing.Size(53, 49);
            this.btn_w.TabIndex = 26;
            this.btn_w.Text = "W";
            this.btn_w.UseVisualStyleBackColor = false;
            this.btn_w.Click += new System.EventHandler(this.btn_w_Click);
            // 
            // btn_e
            // 
            this.btn_e.BackColor = System.Drawing.Color.DimGray;
            this.btn_e.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_e.Location = new System.Drawing.Point(242, 158);
            this.btn_e.Name = "btn_e";
            this.btn_e.Size = new System.Drawing.Size(53, 49);
            this.btn_e.TabIndex = 25;
            this.btn_e.Text = "E";
            this.btn_e.UseVisualStyleBackColor = false;
            this.btn_e.Click += new System.EventHandler(this.btn_e_Click);
            // 
            // btn_r
            // 
            this.btn_r.BackColor = System.Drawing.Color.DimGray;
            this.btn_r.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_r.Location = new System.Drawing.Point(301, 158);
            this.btn_r.Name = "btn_r";
            this.btn_r.Size = new System.Drawing.Size(53, 49);
            this.btn_r.TabIndex = 24;
            this.btn_r.Text = "R";
            this.btn_r.UseVisualStyleBackColor = false;
            this.btn_r.Click += new System.EventHandler(this.btn_r_Click);
            // 
            // btn_t
            // 
            this.btn_t.BackColor = System.Drawing.Color.DimGray;
            this.btn_t.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_t.Location = new System.Drawing.Point(360, 158);
            this.btn_t.Name = "btn_t";
            this.btn_t.Size = new System.Drawing.Size(53, 49);
            this.btn_t.TabIndex = 23;
            this.btn_t.Text = "T";
            this.btn_t.UseVisualStyleBackColor = false;
            this.btn_t.Click += new System.EventHandler(this.btn_t_Click);
            // 
            // btn_y
            // 
            this.btn_y.BackColor = System.Drawing.Color.DimGray;
            this.btn_y.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_y.Location = new System.Drawing.Point(419, 158);
            this.btn_y.Name = "btn_y";
            this.btn_y.Size = new System.Drawing.Size(53, 49);
            this.btn_y.TabIndex = 22;
            this.btn_y.Text = "Y";
            this.btn_y.UseVisualStyleBackColor = false;
            this.btn_y.Click += new System.EventHandler(this.btn_y_Click);
            // 
            // btn_u
            // 
            this.btn_u.BackColor = System.Drawing.Color.DimGray;
            this.btn_u.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_u.Location = new System.Drawing.Point(478, 158);
            this.btn_u.Name = "btn_u";
            this.btn_u.Size = new System.Drawing.Size(53, 49);
            this.btn_u.TabIndex = 21;
            this.btn_u.Text = "U";
            this.btn_u.UseVisualStyleBackColor = false;
            this.btn_u.Click += new System.EventHandler(this.btn_u_Click);
            // 
            // btn_i
            // 
            this.btn_i.BackColor = System.Drawing.Color.DimGray;
            this.btn_i.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_i.Location = new System.Drawing.Point(537, 158);
            this.btn_i.Name = "btn_i";
            this.btn_i.Size = new System.Drawing.Size(53, 49);
            this.btn_i.TabIndex = 20;
            this.btn_i.Text = "I";
            this.btn_i.UseVisualStyleBackColor = false;
            this.btn_i.Click += new System.EventHandler(this.btn_i_Click);
            // 
            // btn_o
            // 
            this.btn_o.BackColor = System.Drawing.Color.DimGray;
            this.btn_o.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_o.Location = new System.Drawing.Point(596, 158);
            this.btn_o.Name = "btn_o";
            this.btn_o.Size = new System.Drawing.Size(53, 49);
            this.btn_o.TabIndex = 19;
            this.btn_o.Text = "O";
            this.btn_o.UseVisualStyleBackColor = false;
            this.btn_o.Click += new System.EventHandler(this.btn_o_Click);
            // 
            // btn_q
            // 
            this.btn_q.BackColor = System.Drawing.Color.DimGray;
            this.btn_q.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_q.Location = new System.Drawing.Point(124, 158);
            this.btn_q.Name = "btn_q";
            this.btn_q.Size = new System.Drawing.Size(53, 49);
            this.btn_q.TabIndex = 18;
            this.btn_q.Text = "Q";
            this.btn_q.UseVisualStyleBackColor = false;
            this.btn_q.Click += new System.EventHandler(this.btn_q_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1235, 537);
            this.Controls.Add(this.panel_menuGame);
            this.Controls.Add(this.panel_menu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_menu.ResumeLayout(false);
            this.panel_menu.PerformLayout();
            this.panel_menuGame.ResumeLayout(false);
            this.panel_menuGame.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_word1;
        private System.Windows.Forms.Label label_word2;
        private System.Windows.Forms.Label label_word5;
        private System.Windows.Forms.Label label_word4;
        private System.Windows.Forms.Label label_word3;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.TextBox tb_word5;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Panel panel_menu;
        private System.Windows.Forms.Label lbl_strip1;
        private System.Windows.Forms.Label lbl_strip2;
        private System.Windows.Forms.Label lbl_strip3;
        private System.Windows.Forms.Label lbl_strip4;
        private System.Windows.Forms.Label lbl_strip5;
        private System.Windows.Forms.Label lbl_randomWord;
        private System.Windows.Forms.Panel panel_menuGame;
        private System.Windows.Forms.Button btn_x;
        private System.Windows.Forms.Button btn_c;
        private System.Windows.Forms.Button btn_v;
        private System.Windows.Forms.Button btn_b;
        private System.Windows.Forms.Button btn_n;
        private System.Windows.Forms.Button btn_m;
        private System.Windows.Forms.Button btn_z;
        private System.Windows.Forms.Button btn_s;
        private System.Windows.Forms.Button btn_d;
        private System.Windows.Forms.Button btn_f;
        private System.Windows.Forms.Button btn_g;
        private System.Windows.Forms.Button btn_h;
        private System.Windows.Forms.Button btn_j;
        private System.Windows.Forms.Button btn_k;
        private System.Windows.Forms.Button btn_l;
        private System.Windows.Forms.Button btn_a;
        private System.Windows.Forms.Button btn_p;
        private System.Windows.Forms.Button btn_w;
        private System.Windows.Forms.Button btn_e;
        private System.Windows.Forms.Button btn_r;
        private System.Windows.Forms.Button btn_t;
        private System.Windows.Forms.Button btn_y;
        private System.Windows.Forms.Button btn_u;
        private System.Windows.Forms.Button btn_i;
        private System.Windows.Forms.Button btn_o;
        private System.Windows.Forms.Button btn_q;
    }
}

