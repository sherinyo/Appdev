﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH14_Sherin_Alvinia_Yonatan
{
    public partial class TH14 : Form
    {
        public MySqlConnection connection;
        public MySqlCommand command;
        public MySqlDataAdapter adapter;

        public string query;

        public DataTable dtTeamName; // combobox team
        public DataTable dtTeamHome = new DataTable(); // cb Teamhome
        public DataTable dtTeamAway = new DataTable(); // cb teamAway
        public DataTable dtType = new DataTable(); // membuat dgv type
        public DataTable dtAdd = new DataTable();  // add ke dgv
        public DataTable dtMatch = new DataTable(); // untuk MATCH
        public DataTable dtDMatch = new DataTable(); // untuk dmatch
        
        public TH14()
        {
            InitializeComponent();
            
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server = localhost; uid = root; pwd = Benangwol01; database = premier_league");

            try
            {
                connection.Open();

                // ComboBox Team Home
                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtTeamHome);

                cb_teamHome.DataSource = dtTeamHome;
                cb_teamHome.ValueMember = "team_id";
                cb_teamHome.DisplayMember = "team_name";
                cb_teamHome.SelectedIndex = -1;

                // ComboBox Team Away
                query = "select team_name, team_id from team;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtTeamAway);

                cb_teamAway.DataSource = dtTeamAway;
                cb_teamAway.ValueMember = "team_id";
                cb_teamAway.DisplayMember = "team_name";
                cb_teamAway.SelectedIndex = -1;

                // ComboBox Type
                dtType.Columns.Add("type_id");
                dtType.Rows.Add("CY");
                dtType.Rows.Add("CR");
                dtType.Rows.Add("GP");
                dtType.Rows.Add("GW");
                dtType.Rows.Add("GO");
                dtType.Rows.Add("PM");
                cb_type.DataSource = dtType;
                cb_type.ValueMember = "type_id";
                cb_type.DisplayMember = "type_id";
                cb_type.SelectedIndex = -1;

                // (ADD) to DGV
                dtAdd.Columns.Add("Minute");
                dtAdd.Columns.Add("Team");
                dtAdd.Columns.Add("Player");
                dtAdd.Columns.Add("Type");
                dgv_data.DataSource = dtAdd;

                // dmatch
                dtDMatch.Columns.Add("Minute");
                dtDMatch.Columns.Add("Team ID");
                dtDMatch.Columns.Add("Player ID");
                dtDMatch.Columns.Add("Type");

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable dtDuaTeam;
        public void DuaTimSaja()
        {
            dtDuaTeam = new DataTable();

            if (cb_teamHome.SelectedValue == null || cb_teamAway.SelectedValue == null)
            {
                return;
            }

            query = $"select team_id, team_name from team where team_id = '{cb_teamAway.SelectedValue}' or team_id = '{cb_teamHome.SelectedValue}';";
            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dtDuaTeam);

            if (dtDuaTeam.Rows.Count < 2)
            {
                MessageBox.Show("Tidak boleh sama");
            }

            cb_team.DataSource = dtDuaTeam;
            cb_team.ValueMember = "team_id";
            cb_team.DisplayMember = "team_name";
            cb_team.SelectedIndex = -1;
        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
           DuaTimSaja();
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
          DuaTimSaja();
        }

        
        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtTeamName = new DataTable();
            
            try
            {
                query = $"select player.player_name, player.team_id from player, team where player.team_id = team.team_id and player.team_id = '{cb_team.SelectedValue}';";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtTeamName);

                cb_player.DataSource = dtTeamName;
                cb_player.ValueMember = "team_id";
                cb_player.DisplayMember = "player_name";
                cb_player.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            
        }

        int skorGoalHome = 0;
        int skorGoalAway = 0;   
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_matchid.Text == "" || tb_minute.Text == "" || cb_team.Text == "" || cb_player.Text == "" || cb_type.Text == "")
            {
                MessageBox.Show("Add: Ada yang kosong");
            }
            else
            {


                dtAdd.Rows.Add(tb_minute.Text, cb_team.Text, cb_player.Text, cb_type.Text);

                if (cb_type.Text == "GW")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        skorGoalHome++;
                    }
                    else
                    {
                        skorGoalAway++;
                    }
                }
                else if (cb_type.Text == "GP" || cb_type.Text == "GO")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        skorGoalAway++;
                    }
                    else
                    {
                        skorGoalHome++;
                    }
                }

                dtDMatch.Rows.Add(tb_minute.Text, cb_team.SelectedValue, cb_player.SelectedValue, cb_type.SelectedValue);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dgv_data.CurrentRow;
            int remove = 0;

            if (dgv_data.Rows.Count > 0)
            {
                for (int i = 0; i < dtAdd.Rows.Count; i++)
                {
                    if (dtAdd.Rows[i][0].ToString().Contains(selectedRow.Cells[0].Value.ToString()))
                    {
                        remove = i;
                    }
                }

                if (selectedRow.Cells[3].Value.ToString() == "GP" || selectedRow.Cells[3].Value.ToString() == "GO")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        skorGoalAway--;
                    }
                    else
                    {
                        skorGoalHome--;
                    }
                }
                else if (selectedRow.Cells[3].Value.ToString() == "GW")
                {
                    if (cb_teamAway.Text == cb_team.Text)
                    {
                        skorGoalHome--;
                    }
                    else
                    {
                        skorGoalAway--;
                    }
                }
                dtAdd.Rows.RemoveAt(remove);
                dtDMatch.Rows.RemoveAt(remove);
            }
            else
            {
                MessageBox.Show("Belum diselect bang");
            }

            dgv_data.Refresh();
            dgv_data.DataSource = dtAdd;
        }

        public DataTable dtDateMax;
        public string dd;
        public string mm;
        public string yyyy;
        public DataTable dtTanggalPilihan;

        private void dtp_matchdate_ValueChanged(object sender, EventArgs e)
        {
            dtDateMax =  new DataTable();
            dtTanggalPilihan = new DataTable();
            try
            {
                query = "select concat(date_format(m.match_date, '%Y'), date_format(m.match_date, '%m'), date_format(m.match_date, '%d')) as matchDate from `match` m order by 1 desc LIMIT 1;";
                command = new MySqlCommand(query, connection);
                adapter = new MySqlDataAdapter(command);
                adapter.Fill(dtDateMax);

                dd = dtp_matchdate.Value.Day.ToString();
                if (Convert.ToInt32(dd) < 10)
                {
                    dd = $"0{dd}";
                }

                mm = dtp_matchdate.Value.Month.ToString();
                if (Convert.ToInt32(mm) <10)
                {
                    mm = $"0{mm}";
                }

                yyyy = dtp_matchdate.Value.Year.ToString();

                int pilihanDate = Convert.ToInt32($"{yyyy}{mm}{dd}");
                int maxDate = Convert.ToInt32(dtDateMax.Rows[0][0]);
                
                if (pilihanDate >= maxDate)
                {
                    query = $"select match_id from `match` where match_id like '{yyyy}%' order by 1 desc LIMIT 1";
                    command = new MySqlCommand(query, connection);
                    adapter = new MySqlDataAdapter(command);
                    adapter.Fill(dtTanggalPilihan);

                    if (dtTanggalPilihan.Rows.Count == 0)
                    {
                        tb_matchid.Text = $"{yyyy}001";
                    }
                    else if (dtTanggalPilihan.Rows.Count == 1)
                    {
                        int cnt = 1;
                        int cntMatch = Convert.ToInt32(dtTanggalPilihan.Rows[0][0]) + cnt;
                        tb_matchid.Text = cntMatch.ToString();
                    }
                }
                else
                {
                    MessageBox.Show("Maks tanggal terakhir kamu input");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"matchdate value changed error: {ex.Message}");
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_matchid.Text == "")
                {
                    MessageBox.Show("ya harus ada isinya dulu hhh");
                }
                else
                {
                    connection.Open();
                    for (int i = 0; i < dgv_data.Rows.Count; i++)
                    {
                        // dmatch -> matchid, minute, teamid, playerid, type, delete
                        query = $"insert into dmatch values ('{tb_matchid.Text}', '{dtDMatch.Rows[i][0]}', '{dtDMatch.Rows[i][1]}', '{dtDMatch.Rows[i][2]}', '{dtDMatch.Rows[i][3]}', 0)";
                        command = new MySqlCommand(query, connection);
                        command.ExecuteNonQuery();
                    }

                    // match -> matchid, match_date, team_home, team_away, goal_home, goal_away, referee_id, delete
                    query = $"insert into `match` values ('{tb_matchid.Text}', '{yyyy}-{mm}-{dd}', '{cb_teamHome.SelectedValue}', '{cb_teamAway.SelectedValue}', '{skorGoalHome}', '{skorGoalAway}', 'M002', 0);";
                    command = new MySqlCommand(query, connection);
                    command.ExecuteNonQuery();
                    connection.Close();

                    cb_teamHome.Text = "";
                    cb_teamAway.Text = "";
                    tb_matchid.Text = "";
                    tb_minute.Text = "";
                    cb_type.Text = "";
                    cb_team.Text = "";
                    cb_player.Text = "";
                    dtAdd.Rows.Clear();
                    skorGoalHome = 0;
                    skorGoalAway = 0;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"insert error: {ex.Message}");
            }
        }
    }
}
