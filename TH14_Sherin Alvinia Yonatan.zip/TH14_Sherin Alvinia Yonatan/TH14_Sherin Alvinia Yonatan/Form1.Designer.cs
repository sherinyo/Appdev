﻿namespace TH14_Sherin_Alvinia_Yonatan
{
    partial class TH14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_insert = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.label_type = new System.Windows.Forms.Label();
            this.label_player = new System.Windows.Forms.Label();
            this.label_team = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label_minute = new System.Windows.Forms.Label();
            this.dgv_data = new System.Windows.Forms.DataGridView();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.dtp_matchdate = new System.Windows.Forms.DateTimePicker();
            this.label_teamaway = new System.Windows.Forms.Label();
            this.label_matchdate = new System.Windows.Forms.Label();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.label_teamhome = new System.Windows.Forms.Label();
            this.label_matchid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(730, 609);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(2);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(134, 33);
            this.btn_insert.TabIndex = 41;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1058, 458);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(2);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(88, 34);
            this.btn_delete.TabIndex = 40;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(927, 458);
            this.btn_add.Margin = new System.Windows.Forms.Padding(2);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(88, 34);
            this.btn_add.TabIndex = 39;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(981, 395);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(166, 28);
            this.cb_type.TabIndex = 38;
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(981, 330);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(166, 28);
            this.cb_player.TabIndex = 37;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(981, 266);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(166, 28);
            this.cb_team.TabIndex = 36;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(981, 209);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(166, 26);
            this.tb_minute.TabIndex = 35;
            // 
            // label_type
            // 
            this.label_type.AutoSize = true;
            this.label_type.Location = new System.Drawing.Point(893, 395);
            this.label_type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_type.Name = "label_type";
            this.label_type.Size = new System.Drawing.Size(43, 20);
            this.label_type.TabIndex = 34;
            this.label_type.Text = "Type";
            // 
            // label_player
            // 
            this.label_player.AutoSize = true;
            this.label_player.Location = new System.Drawing.Point(893, 336);
            this.label_player.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_player.Name = "label_player";
            this.label_player.Size = new System.Drawing.Size(52, 20);
            this.label_player.TabIndex = 33;
            this.label_player.Text = "Player";
            // 
            // label_team
            // 
            this.label_team.AutoSize = true;
            this.label_team.Location = new System.Drawing.Point(893, 273);
            this.label_team.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_team.Name = "label_team";
            this.label_team.Size = new System.Drawing.Size(49, 20);
            this.label_team.TabIndex = 32;
            this.label_team.Text = "Team";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(890, 273);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = " ";
            // 
            // label_minute
            // 
            this.label_minute.AutoSize = true;
            this.label_minute.Location = new System.Drawing.Point(890, 214);
            this.label_minute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_minute.Name = "label_minute";
            this.label_minute.Size = new System.Drawing.Size(57, 20);
            this.label_minute.TabIndex = 30;
            this.label_minute.Text = "Minute";
            // 
            // dgv_data
            // 
            this.dgv_data.AllowUserToAddRows = false;
            this.dgv_data.AllowUserToDeleteRows = false;
            this.dgv_data.AllowUserToResizeColumns = false;
            this.dgv_data.AllowUserToResizeRows = false;
            this.dgv_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_data.Location = new System.Drawing.Point(34, 189);
            this.dgv_data.Margin = new System.Windows.Forms.Padding(2);
            this.dgv_data.Name = "dgv_data";
            this.dgv_data.RowHeadersWidth = 82;
            this.dgv_data.RowTemplate.Height = 33;
            this.dgv_data.Size = new System.Drawing.Size(830, 393);
            this.dgv_data.TabIndex = 29;
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(550, 89);
            this.cb_teamAway.Margin = new System.Windows.Forms.Padding(2);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(198, 28);
            this.cb_teamAway.TabIndex = 28;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // dtp_matchdate
            // 
            this.dtp_matchdate.Location = new System.Drawing.Point(550, 43);
            this.dtp_matchdate.Margin = new System.Windows.Forms.Padding(2);
            this.dtp_matchdate.Name = "dtp_matchdate";
            this.dtp_matchdate.Size = new System.Drawing.Size(315, 26);
            this.dtp_matchdate.TabIndex = 27;
            this.dtp_matchdate.ValueChanged += new System.EventHandler(this.dtp_matchdate_ValueChanged);
            // 
            // label_teamaway
            // 
            this.label_teamaway.AutoSize = true;
            this.label_teamaway.Location = new System.Drawing.Point(419, 97);
            this.label_teamaway.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_teamaway.Name = "label_teamaway";
            this.label_teamaway.Size = new System.Drawing.Size(91, 20);
            this.label_teamaway.TabIndex = 26;
            this.label_teamaway.Text = "Team Away";
            // 
            // label_matchdate
            // 
            this.label_matchdate.AutoSize = true;
            this.label_matchdate.Location = new System.Drawing.Point(419, 47);
            this.label_matchdate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_matchdate.Name = "label_matchdate";
            this.label_matchdate.Size = new System.Drawing.Size(92, 20);
            this.label_matchdate.TabIndex = 25;
            this.label_matchdate.Text = "Match Date";
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(165, 96);
            this.cb_teamHome.Margin = new System.Windows.Forms.Padding(2);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(146, 28);
            this.cb_teamHome.TabIndex = 24;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // tb_matchid
            // 
            this.tb_matchid.Enabled = false;
            this.tb_matchid.Location = new System.Drawing.Point(165, 44);
            this.tb_matchid.Margin = new System.Windows.Forms.Padding(2);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(146, 26);
            this.tb_matchid.TabIndex = 23;
            // 
            // label_teamhome
            // 
            this.label_teamhome.AutoSize = true;
            this.label_teamhome.Location = new System.Drawing.Point(30, 96);
            this.label_teamhome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_teamhome.Name = "label_teamhome";
            this.label_teamhome.Size = new System.Drawing.Size(96, 20);
            this.label_teamhome.TabIndex = 22;
            this.label_teamhome.Text = "Team Home";
            // 
            // label_matchid
            // 
            this.label_matchid.AutoSize = true;
            this.label_matchid.Location = new System.Drawing.Point(30, 46);
            this.label_matchid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_matchid.Name = "label_matchid";
            this.label_matchid.Size = new System.Drawing.Size(74, 20);
            this.label_matchid.TabIndex = 21;
            this.label_matchid.Text = "Match ID";
            // 
            // TH14
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 692);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.label_type);
            this.Controls.Add(this.label_player);
            this.Controls.Add(this.label_team);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label_minute);
            this.Controls.Add(this.dgv_data);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.dtp_matchdate);
            this.Controls.Add(this.label_teamaway);
            this.Controls.Add(this.label_matchdate);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.label_teamhome);
            this.Controls.Add(this.label_matchid);
            this.Name = "TH14";
            this.Text = "TH14";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Label label_type;
        private System.Windows.Forms.Label label_player;
        private System.Windows.Forms.Label label_team;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label_minute;
        private System.Windows.Forms.DataGridView dgv_data;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.DateTimePicker dtp_matchdate;
        private System.Windows.Forms.Label label_teamaway;
        private System.Windows.Forms.Label label_matchdate;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.Label label_teamhome;
        private System.Windows.Forms.Label label_matchid;
    }
}

