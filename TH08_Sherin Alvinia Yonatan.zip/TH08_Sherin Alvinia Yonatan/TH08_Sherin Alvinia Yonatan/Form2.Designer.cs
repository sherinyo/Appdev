﻿namespace TH08_Sherin_Alvinia_Yonatan
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_others = new System.Windows.Forms.Panel();
            this.btn_addToCart1 = new System.Windows.Forms.Button();
            this.lbl_itemName = new System.Windows.Forms.Label();
            this.lbl_uploadImage = new System.Windows.Forms.Label();
            this.pb_uploadImage = new System.Windows.Forms.PictureBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.tb_itemName = new System.Windows.Forms.TextBox();
            this.tb_itemPrice = new System.Windows.Forms.TextBox();
            this.lbl_itemPrice = new System.Windows.Forms.Label();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_uploadImage)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.tb_itemPrice);
            this.panel_others.Controls.Add(this.lbl_itemPrice);
            this.panel_others.Controls.Add(this.tb_itemName);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.btn_addToCart1);
            this.panel_others.Controls.Add(this.lbl_itemName);
            this.panel_others.Controls.Add(this.lbl_uploadImage);
            this.panel_others.Controls.Add(this.pb_uploadImage);
            this.panel_others.Location = new System.Drawing.Point(45, 48);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(532, 479);
            this.panel_others.TabIndex = 7;
            // 
            // btn_addToCart1
            // 
            this.btn_addToCart1.Location = new System.Drawing.Point(315, 372);
            this.btn_addToCart1.Name = "btn_addToCart1";
            this.btn_addToCart1.Size = new System.Drawing.Size(120, 30);
            this.btn_addToCart1.TabIndex = 9;
            this.btn_addToCart1.Text = "Add to Cart";
            this.btn_addToCart1.UseVisualStyleBackColor = true;
            // 
            // lbl_itemName
            // 
            this.lbl_itemName.AutoSize = true;
            this.lbl_itemName.Location = new System.Drawing.Point(311, 90);
            this.lbl_itemName.Name = "lbl_itemName";
            this.lbl_itemName.Size = new System.Drawing.Size(91, 20);
            this.lbl_itemName.TabIndex = 6;
            this.lbl_itemName.Text = "Item Name:";
            // 
            // lbl_uploadImage
            // 
            this.lbl_uploadImage.AutoSize = true;
            this.lbl_uploadImage.Location = new System.Drawing.Point(24, 28);
            this.lbl_uploadImage.Name = "lbl_uploadImage";
            this.lbl_uploadImage.Size = new System.Drawing.Size(109, 20);
            this.lbl_uploadImage.TabIndex = 3;
            this.lbl_uploadImage.Text = "Upload Image";
            // 
            // pb_uploadImage
            // 
            this.pb_uploadImage.Location = new System.Drawing.Point(28, 90);
            this.pb_uploadImage.Name = "pb_uploadImage";
            this.pb_uploadImage.Size = new System.Drawing.Size(241, 312);
            this.pb_uploadImage.TabIndex = 0;
            this.pb_uploadImage.TabStop = false;
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(181, 23);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(120, 30);
            this.btn_upload.TabIndex = 10;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            // 
            // tb_itemName
            // 
            this.tb_itemName.Location = new System.Drawing.Point(315, 126);
            this.tb_itemName.Name = "tb_itemName";
            this.tb_itemName.Size = new System.Drawing.Size(162, 26);
            this.tb_itemName.TabIndex = 11;
            // 
            // tb_itemPrice
            // 
            this.tb_itemPrice.Location = new System.Drawing.Point(315, 206);
            this.tb_itemPrice.Name = "tb_itemPrice";
            this.tb_itemPrice.Size = new System.Drawing.Size(162, 26);
            this.tb_itemPrice.TabIndex = 13;
            // 
            // lbl_itemPrice
            // 
            this.lbl_itemPrice.AutoSize = true;
            this.lbl_itemPrice.Location = new System.Drawing.Point(311, 170);
            this.lbl_itemPrice.Name = "lbl_itemPrice";
            this.lbl_itemPrice.Size = new System.Drawing.Size(84, 20);
            this.lbl_itemPrice.TabIndex = 12;
            this.lbl_itemPrice.Text = "Item Price:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1602, 992);
            this.Controls.Add(this.panel_others);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_uploadImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_addToCart1;
        private System.Windows.Forms.Label lbl_itemName;
        private System.Windows.Forms.Label lbl_uploadImage;
        private System.Windows.Forms.PictureBox pb_uploadImage;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.TextBox tb_itemName;
        private System.Windows.Forms.TextBox tb_itemPrice;
        private System.Windows.Forms.Label lbl_itemPrice;
    }
}