﻿namespace TH08_Sherin_Alvinia_Yonatan
{
    partial class uniqme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(uniqme));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewerlliesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_keranjang = new System.Windows.Forms.DataGridView();
            this.lbl_subtotal = new System.Windows.Forms.Label();
            this.lbl_total = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.btn_addToCart3 = new System.Windows.Forms.Button();
            this.btn_addToCart2 = new System.Windows.Forms.Button();
            this.btn_addToCart1 = new System.Windows.Forms.Button();
            this.lbl_hargatshirt3 = new System.Windows.Forms.Label();
            this.lbl_hargatshirt2 = new System.Windows.Forms.Label();
            this.lbl_hargatshirt1 = new System.Windows.Forms.Label();
            this.lbl_tshirt3 = new System.Windows.Forms.Label();
            this.lbl_tshirt2 = new System.Windows.Forms.Label();
            this.lbl_tshirt1 = new System.Windows.Forms.Label();
            this.pb_tshirt3 = new System.Windows.Forms.PictureBox();
            this.pb_tshirt2 = new System.Windows.Forms.PictureBox();
            this.pb_tshirt1 = new System.Windows.Forms.PictureBox();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_addShirt3 = new System.Windows.Forms.Button();
            this.btn_addShirt2 = new System.Windows.Forms.Button();
            this.btn_addShirt1 = new System.Windows.Forms.Button();
            this.lbl_hargashirt3 = new System.Windows.Forms.Label();
            this.lbl_hargaShirt2 = new System.Windows.Forms.Label();
            this.lbl_hargashirt1 = new System.Windows.Forms.Label();
            this.lbl_shirt3 = new System.Windows.Forms.Label();
            this.lbl_shirt2 = new System.Windows.Forms.Label();
            this.lbl_shirt1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_addPants3 = new System.Windows.Forms.Button();
            this.btn_addPants2 = new System.Windows.Forms.Button();
            this.btn_addPants1 = new System.Windows.Forms.Button();
            this.lbl_hargapants3 = new System.Windows.Forms.Label();
            this.lbl_hargaPants2 = new System.Windows.Forms.Label();
            this.lbl_hargaPants1 = new System.Windows.Forms.Label();
            this.lbl_pants3 = new System.Windows.Forms.Label();
            this.lbl_pants2 = new System.Windows.Forms.Label();
            this.lbl_pants1 = new System.Windows.Forms.Label();
            this.pb_pants3 = new System.Windows.Forms.PictureBox();
            this.pb_pants2 = new System.Windows.Forms.PictureBox();
            this.pb_pants1 = new System.Windows.Forms.PictureBox();
            this.panel_longPants = new System.Windows.Forms.Panel();
            this.btn_longpants3 = new System.Windows.Forms.Button();
            this.btn_longpants2 = new System.Windows.Forms.Button();
            this.btn_longpants1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_hargalongpants2 = new System.Windows.Forms.Label();
            this.lbl_hargalongpants1 = new System.Windows.Forms.Label();
            this.lbl_longpants3 = new System.Windows.Forms.Label();
            this.lbl_longpants2 = new System.Windows.Forms.Label();
            this.lbl_longpants1 = new System.Windows.Forms.Label();
            this.pb_longpants3 = new System.Windows.Forms.PictureBox();
            this.pb_longpants2 = new System.Windows.Forms.PictureBox();
            this.pb_longpants1 = new System.Windows.Forms.PictureBox();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_shoes3 = new System.Windows.Forms.Button();
            this.btn_shoes2 = new System.Windows.Forms.Button();
            this.btn_shoes1 = new System.Windows.Forms.Button();
            this.lbl_hargashoes3 = new System.Windows.Forms.Label();
            this.lbl_hargashoes2 = new System.Windows.Forms.Label();
            this.lbl_hargashoes1 = new System.Windows.Forms.Label();
            this.lbl_shoes3 = new System.Windows.Forms.Label();
            this.lbl_shoes2 = new System.Windows.Forms.Label();
            this.lbl_shoes1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel_jwl = new System.Windows.Forms.Panel();
            this.btn_jwl3 = new System.Windows.Forms.Button();
            this.btn_jwl2 = new System.Windows.Forms.Button();
            this.btn_jwl1 = new System.Windows.Forms.Button();
            this.lbl_hargajwl3 = new System.Windows.Forms.Label();
            this.lbl_hargajwl2 = new System.Windows.Forms.Label();
            this.lbl_hargajwl1 = new System.Windows.Forms.Label();
            this.lbl_jwl3 = new System.Windows.Forms.Label();
            this.lbl_jwl2 = new System.Windows.Forms.Label();
            this.lbl_jwl1 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel_others = new System.Windows.Forms.Panel();
            this.tb_itemPrice = new System.Windows.Forms.TextBox();
            this.lbl_itemPrice = new System.Windows.Forms.Label();
            this.tb_itemName = new System.Windows.Forms.TextBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.btn_addOther = new System.Windows.Forms.Button();
            this.lbl_itemName = new System.Windows.Forms.Label();
            this.lbl_uploadImage = new System.Windows.Forms.Label();
            this.pb_uploadImage = new System.Windows.Forms.PictureBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_keranjang)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt1)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants1)).BeginInit();
            this.panel_longPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants1)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel_jwl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_uploadImage)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.acceToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1712, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // acceToolStripMenuItem
            // 
            this.acceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewerlliesToolStripMenuItem});
            this.acceToolStripMenuItem.Name = "acceToolStripMenuItem";
            this.acceToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.acceToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(193, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewerlliesToolStripMenuItem
            // 
            this.jewerlliesToolStripMenuItem.Name = "jewerlliesToolStripMenuItem";
            this.jewerlliesToolStripMenuItem.Size = new System.Drawing.Size(193, 34);
            this.jewerlliesToolStripMenuItem.Text = "jewelleries";
            this.jewerlliesToolStripMenuItem.Click += new System.EventHandler(this.jewerlliesToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.otherToolStripMenuItem.Text = "Others";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // dgv_keranjang
            // 
            this.dgv_keranjang.AllowUserToAddRows = false;
            this.dgv_keranjang.AllowUserToDeleteRows = false;
            this.dgv_keranjang.AllowUserToResizeColumns = false;
            this.dgv_keranjang.AllowUserToResizeRows = false;
            this.dgv_keranjang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_keranjang.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_keranjang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_keranjang.Location = new System.Drawing.Point(1130, 87);
            this.dgv_keranjang.Name = "dgv_keranjang";
            this.dgv_keranjang.ReadOnly = true;
            this.dgv_keranjang.RowHeadersVisible = false;
            this.dgv_keranjang.RowHeadersWidth = 62;
            this.dgv_keranjang.RowTemplate.Height = 28;
            this.dgv_keranjang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_keranjang.Size = new System.Drawing.Size(544, 501);
            this.dgv_keranjang.TabIndex = 1;
            // 
            // lbl_subtotal
            // 
            this.lbl_subtotal.AutoSize = true;
            this.lbl_subtotal.Location = new System.Drawing.Point(1130, 618);
            this.lbl_subtotal.Name = "lbl_subtotal";
            this.lbl_subtotal.Size = new System.Drawing.Size(82, 20);
            this.lbl_subtotal.TabIndex = 2;
            this.lbl_subtotal.Text = "Sub-Total:";
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(1130, 656);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(48, 20);
            this.lbl_total.TabIndex = 3;
            this.lbl_total.Text = "Total:";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(1236, 616);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(208, 26);
            this.tb_subtotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(1236, 653);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(208, 26);
            this.tb_total.TabIndex = 5;
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.btn_addToCart3);
            this.panel_tshirt.Controls.Add(this.btn_addToCart2);
            this.panel_tshirt.Controls.Add(this.btn_addToCart1);
            this.panel_tshirt.Controls.Add(this.lbl_hargatshirt3);
            this.panel_tshirt.Controls.Add(this.lbl_hargatshirt2);
            this.panel_tshirt.Controls.Add(this.lbl_hargatshirt1);
            this.panel_tshirt.Controls.Add(this.lbl_tshirt3);
            this.panel_tshirt.Controls.Add(this.lbl_tshirt2);
            this.panel_tshirt.Controls.Add(this.lbl_tshirt1);
            this.panel_tshirt.Controls.Add(this.pb_tshirt3);
            this.panel_tshirt.Controls.Add(this.pb_tshirt2);
            this.panel_tshirt.Controls.Add(this.pb_tshirt1);
            this.panel_tshirt.Location = new System.Drawing.Point(22, 71);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(1060, 473);
            this.panel_tshirt.TabIndex = 6;
            // 
            // btn_addToCart3
            // 
            this.btn_addToCart3.Location = new System.Drawing.Point(686, 417);
            this.btn_addToCart3.Name = "btn_addToCart3";
            this.btn_addToCart3.Size = new System.Drawing.Size(120, 30);
            this.btn_addToCart3.TabIndex = 11;
            this.btn_addToCart3.Text = "Add to Cart";
            this.btn_addToCart3.UseVisualStyleBackColor = true;
            this.btn_addToCart3.Click += new System.EventHandler(this.btn_addToCart3_Click);
            // 
            // btn_addToCart2
            // 
            this.btn_addToCart2.Location = new System.Drawing.Point(361, 417);
            this.btn_addToCart2.Name = "btn_addToCart2";
            this.btn_addToCart2.Size = new System.Drawing.Size(120, 30);
            this.btn_addToCart2.TabIndex = 10;
            this.btn_addToCart2.Text = "Add to Cart";
            this.btn_addToCart2.UseVisualStyleBackColor = true;
            this.btn_addToCart2.Click += new System.EventHandler(this.btn_addToCart2_Click);
            // 
            // btn_addToCart1
            // 
            this.btn_addToCart1.Location = new System.Drawing.Point(26, 417);
            this.btn_addToCart1.Name = "btn_addToCart1";
            this.btn_addToCart1.Size = new System.Drawing.Size(120, 30);
            this.btn_addToCart1.TabIndex = 9;
            this.btn_addToCart1.Text = "Add to Cart";
            this.btn_addToCart1.UseVisualStyleBackColor = true;
            this.btn_addToCart1.Click += new System.EventHandler(this.btn_addToCart1_Click);
            // 
            // lbl_hargatshirt3
            // 
            this.lbl_hargatshirt3.AutoSize = true;
            this.lbl_hargatshirt3.Location = new System.Drawing.Point(684, 377);
            this.lbl_hargatshirt3.Name = "lbl_hargatshirt3";
            this.lbl_hargatshirt3.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargatshirt3.TabIndex = 8;
            this.lbl_hargatshirt3.Text = "Rp. 149.000,-";
            // 
            // lbl_hargatshirt2
            // 
            this.lbl_hargatshirt2.AutoSize = true;
            this.lbl_hargatshirt2.Location = new System.Drawing.Point(359, 377);
            this.lbl_hargatshirt2.Name = "lbl_hargatshirt2";
            this.lbl_hargatshirt2.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargatshirt2.TabIndex = 7;
            this.lbl_hargatshirt2.Text = "Rp. 199.000,-";
            // 
            // lbl_hargatshirt1
            // 
            this.lbl_hargatshirt1.AutoSize = true;
            this.lbl_hargatshirt1.Location = new System.Drawing.Point(24, 377);
            this.lbl_hargatshirt1.Name = "lbl_hargatshirt1";
            this.lbl_hargatshirt1.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargatshirt1.TabIndex = 6;
            this.lbl_hargatshirt1.Text = "Rp. 199.000,-";
            // 
            // lbl_tshirt3
            // 
            this.lbl_tshirt3.AutoSize = true;
            this.lbl_tshirt3.Location = new System.Drawing.Point(684, 347);
            this.lbl_tshirt3.Name = "lbl_tshirt3";
            this.lbl_tshirt3.Size = new System.Drawing.Size(197, 20);
            this.lbl_tshirt3.TabIndex = 5;
            this.lbl_tshirt3.Text = "KIDS AIRsm T-Shirt Katun";
            // 
            // lbl_tshirt2
            // 
            this.lbl_tshirt2.AutoSize = true;
            this.lbl_tshirt2.Location = new System.Drawing.Point(359, 347);
            this.lbl_tshirt2.Name = "lbl_tshirt2";
            this.lbl_tshirt2.Size = new System.Drawing.Size(214, 20);
            this.lbl_tshirt2.TabIndex = 4;
            this.lbl_tshirt2.Text = "UT Pop Mart Lengan Pendek";
            // 
            // lbl_tshirt1
            // 
            this.lbl_tshirt1.AutoSize = true;
            this.lbl_tshirt1.Location = new System.Drawing.Point(24, 347);
            this.lbl_tshirt1.Name = "lbl_tshirt1";
            this.lbl_tshirt1.Size = new System.Drawing.Size(201, 20);
            this.lbl_tshirt1.TabIndex = 3;
            this.lbl_tshirt1.Text = "T-Shirt Kerah Bulat Pendek";
            // 
            // pb_tshirt3
            // 
            this.pb_tshirt3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_tshirt3.BackgroundImage")));
            this.pb_tshirt3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_tshirt3.Location = new System.Drawing.Point(686, 16);
            this.pb_tshirt3.Name = "pb_tshirt3";
            this.pb_tshirt3.Size = new System.Drawing.Size(241, 312);
            this.pb_tshirt3.TabIndex = 2;
            this.pb_tshirt3.TabStop = false;
            // 
            // pb_tshirt2
            // 
            this.pb_tshirt2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_tshirt2.BackgroundImage")));
            this.pb_tshirt2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_tshirt2.Location = new System.Drawing.Point(361, 16);
            this.pb_tshirt2.Name = "pb_tshirt2";
            this.pb_tshirt2.Size = new System.Drawing.Size(241, 312);
            this.pb_tshirt2.TabIndex = 1;
            this.pb_tshirt2.TabStop = false;
            // 
            // pb_tshirt1
            // 
            this.pb_tshirt1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_tshirt1.BackgroundImage")));
            this.pb_tshirt1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_tshirt1.Location = new System.Drawing.Point(22, 16);
            this.pb_tshirt1.Name = "pb_tshirt1";
            this.pb_tshirt1.Size = new System.Drawing.Size(241, 312);
            this.pb_tshirt1.TabIndex = 0;
            this.pb_tshirt1.TabStop = false;
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.btn_addShirt3);
            this.panel_shirt.Controls.Add(this.btn_addShirt2);
            this.panel_shirt.Controls.Add(this.btn_addShirt1);
            this.panel_shirt.Controls.Add(this.lbl_hargashirt3);
            this.panel_shirt.Controls.Add(this.lbl_hargaShirt2);
            this.panel_shirt.Controls.Add(this.lbl_hargashirt1);
            this.panel_shirt.Controls.Add(this.lbl_shirt3);
            this.panel_shirt.Controls.Add(this.lbl_shirt2);
            this.panel_shirt.Controls.Add(this.lbl_shirt1);
            this.panel_shirt.Controls.Add(this.pictureBox1);
            this.panel_shirt.Controls.Add(this.pictureBox2);
            this.panel_shirt.Controls.Add(this.pictureBox3);
            this.panel_shirt.Location = new System.Drawing.Point(22, 58);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(1060, 473);
            this.panel_shirt.TabIndex = 12;
            // 
            // btn_addShirt3
            // 
            this.btn_addShirt3.Location = new System.Drawing.Point(686, 417);
            this.btn_addShirt3.Name = "btn_addShirt3";
            this.btn_addShirt3.Size = new System.Drawing.Size(120, 30);
            this.btn_addShirt3.TabIndex = 11;
            this.btn_addShirt3.Text = "Add to Cart";
            this.btn_addShirt3.UseVisualStyleBackColor = true;
            this.btn_addShirt3.Click += new System.EventHandler(this.btn_addShirt3_Click);
            // 
            // btn_addShirt2
            // 
            this.btn_addShirt2.Location = new System.Drawing.Point(361, 417);
            this.btn_addShirt2.Name = "btn_addShirt2";
            this.btn_addShirt2.Size = new System.Drawing.Size(120, 30);
            this.btn_addShirt2.TabIndex = 10;
            this.btn_addShirt2.Text = "Add to Cart";
            this.btn_addShirt2.UseVisualStyleBackColor = true;
            this.btn_addShirt2.Click += new System.EventHandler(this.btn_addShirt2_Click);
            // 
            // btn_addShirt1
            // 
            this.btn_addShirt1.Location = new System.Drawing.Point(26, 417);
            this.btn_addShirt1.Name = "btn_addShirt1";
            this.btn_addShirt1.Size = new System.Drawing.Size(120, 30);
            this.btn_addShirt1.TabIndex = 9;
            this.btn_addShirt1.Text = "Add to Cart";
            this.btn_addShirt1.UseVisualStyleBackColor = true;
            this.btn_addShirt1.Click += new System.EventHandler(this.btn_addShirt1_Click);
            // 
            // lbl_hargashirt3
            // 
            this.lbl_hargashirt3.AutoSize = true;
            this.lbl_hargashirt3.Location = new System.Drawing.Point(684, 377);
            this.lbl_hargashirt3.Name = "lbl_hargashirt3";
            this.lbl_hargashirt3.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargashirt3.TabIndex = 8;
            this.lbl_hargashirt3.Text = "Rp. 299.000,-";
            // 
            // lbl_hargaShirt2
            // 
            this.lbl_hargaShirt2.AutoSize = true;
            this.lbl_hargaShirt2.Location = new System.Drawing.Point(359, 377);
            this.lbl_hargaShirt2.Name = "lbl_hargaShirt2";
            this.lbl_hargaShirt2.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargaShirt2.TabIndex = 7;
            this.lbl_hargaShirt2.Text = "Rp. 399.000,-";
            // 
            // lbl_hargashirt1
            // 
            this.lbl_hargashirt1.AutoSize = true;
            this.lbl_hargashirt1.Location = new System.Drawing.Point(24, 377);
            this.lbl_hargashirt1.Name = "lbl_hargashirt1";
            this.lbl_hargashirt1.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargashirt1.TabIndex = 6;
            this.lbl_hargashirt1.Text = "Rp. 499.000,-";
            // 
            // lbl_shirt3
            // 
            this.lbl_shirt3.AutoSize = true;
            this.lbl_shirt3.Location = new System.Drawing.Point(684, 347);
            this.lbl_shirt3.Name = "lbl_shirt3";
            this.lbl_shirt3.Size = new System.Drawing.Size(257, 20);
            this.lbl_shirt3.TabIndex = 5;
            this.lbl_shirt3.Text = "Flannel Checked Long Sleeve Shirt";
            // 
            // lbl_shirt2
            // 
            this.lbl_shirt2.AutoSize = true;
            this.lbl_shirt2.Location = new System.Drawing.Point(359, 347);
            this.lbl_shirt2.Name = "lbl_shirt2";
            this.lbl_shirt2.Size = new System.Drawing.Size(232, 20);
            this.lbl_shirt2.TabIndex = 4;
            this.lbl_shirt2.Text = "Soft Brushed Long Sleeve Shirt";
            // 
            // lbl_shirt1
            // 
            this.lbl_shirt1.AutoSize = true;
            this.lbl_shirt1.Location = new System.Drawing.Point(24, 347);
            this.lbl_shirt1.Name = "lbl_shirt1";
            this.lbl_shirt1.Size = new System.Drawing.Size(243, 20);
            this.lbl_shirt1.TabIndex = 3;
            this.lbl_shirt1.Text = "Premium Linen Long Sleeve Shirt";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(686, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(241, 312);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(361, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(241, 312);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(22, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(241, 312);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_addPants3);
            this.panel_pants.Controls.Add(this.btn_addPants2);
            this.panel_pants.Controls.Add(this.btn_addPants1);
            this.panel_pants.Controls.Add(this.lbl_hargapants3);
            this.panel_pants.Controls.Add(this.lbl_hargaPants2);
            this.panel_pants.Controls.Add(this.lbl_hargaPants1);
            this.panel_pants.Controls.Add(this.lbl_pants3);
            this.panel_pants.Controls.Add(this.lbl_pants2);
            this.panel_pants.Controls.Add(this.lbl_pants1);
            this.panel_pants.Controls.Add(this.pb_pants3);
            this.panel_pants.Controls.Add(this.pb_pants2);
            this.panel_pants.Controls.Add(this.pb_pants1);
            this.panel_pants.Location = new System.Drawing.Point(25, 45);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(1060, 473);
            this.panel_pants.TabIndex = 13;
            // 
            // btn_addPants3
            // 
            this.btn_addPants3.Location = new System.Drawing.Point(686, 417);
            this.btn_addPants3.Name = "btn_addPants3";
            this.btn_addPants3.Size = new System.Drawing.Size(120, 30);
            this.btn_addPants3.TabIndex = 11;
            this.btn_addPants3.Text = "Add to Cart";
            this.btn_addPants3.UseVisualStyleBackColor = true;
            this.btn_addPants3.Click += new System.EventHandler(this.btn_addPants3_Click);
            // 
            // btn_addPants2
            // 
            this.btn_addPants2.Location = new System.Drawing.Point(361, 417);
            this.btn_addPants2.Name = "btn_addPants2";
            this.btn_addPants2.Size = new System.Drawing.Size(120, 30);
            this.btn_addPants2.TabIndex = 10;
            this.btn_addPants2.Text = "Add to Cart";
            this.btn_addPants2.UseVisualStyleBackColor = true;
            this.btn_addPants2.Click += new System.EventHandler(this.btn_addPants2_Click);
            // 
            // btn_addPants1
            // 
            this.btn_addPants1.Location = new System.Drawing.Point(26, 417);
            this.btn_addPants1.Name = "btn_addPants1";
            this.btn_addPants1.Size = new System.Drawing.Size(120, 30);
            this.btn_addPants1.TabIndex = 9;
            this.btn_addPants1.Text = "Add to Cart";
            this.btn_addPants1.UseVisualStyleBackColor = true;
            this.btn_addPants1.Click += new System.EventHandler(this.btn_addPants1_Click);
            // 
            // lbl_hargapants3
            // 
            this.lbl_hargapants3.AutoSize = true;
            this.lbl_hargapants3.Location = new System.Drawing.Point(684, 377);
            this.lbl_hargapants3.Name = "lbl_hargapants3";
            this.lbl_hargapants3.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargapants3.TabIndex = 8;
            this.lbl_hargapants3.Text = "Rp. 299.000,-";
            // 
            // lbl_hargaPants2
            // 
            this.lbl_hargaPants2.AutoSize = true;
            this.lbl_hargaPants2.Location = new System.Drawing.Point(359, 377);
            this.lbl_hargaPants2.Name = "lbl_hargaPants2";
            this.lbl_hargaPants2.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargaPants2.TabIndex = 7;
            this.lbl_hargaPants2.Text = "Rp. 399.000,-";
            // 
            // lbl_hargaPants1
            // 
            this.lbl_hargaPants1.AutoSize = true;
            this.lbl_hargaPants1.Location = new System.Drawing.Point(24, 377);
            this.lbl_hargaPants1.Name = "lbl_hargaPants1";
            this.lbl_hargaPants1.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargaPants1.TabIndex = 6;
            this.lbl_hargaPants1.Text = "Rp. 149.000,-";
            // 
            // lbl_pants3
            // 
            this.lbl_pants3.AutoSize = true;
            this.lbl_pants3.Location = new System.Drawing.Point(684, 347);
            this.lbl_pants3.Name = "lbl_pants3";
            this.lbl_pants3.Size = new System.Drawing.Size(249, 20);
            this.lbl_pants3.TabIndex = 5;
            this.lbl_pants3.Text = "Celana Pendek Rileks Seersucker";
            // 
            // lbl_pants2
            // 
            this.lbl_pants2.AutoSize = true;
            this.lbl_pants2.Location = new System.Drawing.Point(359, 347);
            this.lbl_pants2.Name = "lbl_pants2";
            this.lbl_pants2.Size = new System.Drawing.Size(220, 20);
            this.lbl_pants2.TabIndex = 4;
            this.lbl_pants2.Text = "Celana Pendek Denim Baggy ";
            // 
            // lbl_pants1
            // 
            this.lbl_pants1.AutoSize = true;
            this.lbl_pants1.Location = new System.Drawing.Point(24, 347);
            this.lbl_pants1.Name = "lbl_pants1";
            this.lbl_pants1.Size = new System.Drawing.Size(220, 20);
            this.lbl_pants1.TabIndex = 3;
            this.lbl_pants1.Text = "AIRism Celana Pendek Rileks";
            // 
            // pb_pants3
            // 
            this.pb_pants3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pants3.BackgroundImage")));
            this.pb_pants3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_pants3.Location = new System.Drawing.Point(686, 16);
            this.pb_pants3.Name = "pb_pants3";
            this.pb_pants3.Size = new System.Drawing.Size(241, 312);
            this.pb_pants3.TabIndex = 2;
            this.pb_pants3.TabStop = false;
            // 
            // pb_pants2
            // 
            this.pb_pants2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pants2.BackgroundImage")));
            this.pb_pants2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_pants2.Location = new System.Drawing.Point(361, 16);
            this.pb_pants2.Name = "pb_pants2";
            this.pb_pants2.Size = new System.Drawing.Size(241, 312);
            this.pb_pants2.TabIndex = 1;
            this.pb_pants2.TabStop = false;
            // 
            // pb_pants1
            // 
            this.pb_pants1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_pants1.BackgroundImage")));
            this.pb_pants1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_pants1.Location = new System.Drawing.Point(22, 16);
            this.pb_pants1.Name = "pb_pants1";
            this.pb_pants1.Size = new System.Drawing.Size(241, 312);
            this.pb_pants1.TabIndex = 0;
            this.pb_pants1.TabStop = false;
            // 
            // panel_longPants
            // 
            this.panel_longPants.Controls.Add(this.btn_longpants3);
            this.panel_longPants.Controls.Add(this.btn_longpants2);
            this.panel_longPants.Controls.Add(this.btn_longpants1);
            this.panel_longPants.Controls.Add(this.label1);
            this.panel_longPants.Controls.Add(this.lbl_hargalongpants2);
            this.panel_longPants.Controls.Add(this.lbl_hargalongpants1);
            this.panel_longPants.Controls.Add(this.lbl_longpants3);
            this.panel_longPants.Controls.Add(this.lbl_longpants2);
            this.panel_longPants.Controls.Add(this.lbl_longpants1);
            this.panel_longPants.Controls.Add(this.pb_longpants3);
            this.panel_longPants.Controls.Add(this.pb_longpants2);
            this.panel_longPants.Controls.Add(this.pb_longpants1);
            this.panel_longPants.Location = new System.Drawing.Point(22, 36);
            this.panel_longPants.Name = "panel_longPants";
            this.panel_longPants.Size = new System.Drawing.Size(1021, 473);
            this.panel_longPants.TabIndex = 14;
            // 
            // btn_longpants3
            // 
            this.btn_longpants3.Location = new System.Drawing.Point(686, 417);
            this.btn_longpants3.Name = "btn_longpants3";
            this.btn_longpants3.Size = new System.Drawing.Size(120, 30);
            this.btn_longpants3.TabIndex = 11;
            this.btn_longpants3.Text = "Add to Cart";
            this.btn_longpants3.UseVisualStyleBackColor = true;
            this.btn_longpants3.Click += new System.EventHandler(this.btn_longpants3_Click);
            // 
            // btn_longpants2
            // 
            this.btn_longpants2.Location = new System.Drawing.Point(361, 417);
            this.btn_longpants2.Name = "btn_longpants2";
            this.btn_longpants2.Size = new System.Drawing.Size(120, 30);
            this.btn_longpants2.TabIndex = 10;
            this.btn_longpants2.Text = "Add to Cart";
            this.btn_longpants2.UseVisualStyleBackColor = true;
            this.btn_longpants2.Click += new System.EventHandler(this.btn_longpants2_Click);
            // 
            // btn_longpants1
            // 
            this.btn_longpants1.Location = new System.Drawing.Point(26, 417);
            this.btn_longpants1.Name = "btn_longpants1";
            this.btn_longpants1.Size = new System.Drawing.Size(120, 30);
            this.btn_longpants1.TabIndex = 9;
            this.btn_longpants1.Text = "Add to Cart";
            this.btn_longpants1.UseVisualStyleBackColor = true;
            this.btn_longpants1.Click += new System.EventHandler(this.btn_longpants1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(684, 377);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Rp. 699.000,-";
            // 
            // lbl_hargalongpants2
            // 
            this.lbl_hargalongpants2.AutoSize = true;
            this.lbl_hargalongpants2.Location = new System.Drawing.Point(359, 377);
            this.lbl_hargalongpants2.Name = "lbl_hargalongpants2";
            this.lbl_hargalongpants2.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargalongpants2.TabIndex = 7;
            this.lbl_hargalongpants2.Text = "Rp. 299.000,-";
            // 
            // lbl_hargalongpants1
            // 
            this.lbl_hargalongpants1.AutoSize = true;
            this.lbl_hargalongpants1.Location = new System.Drawing.Point(24, 377);
            this.lbl_hargalongpants1.Name = "lbl_hargalongpants1";
            this.lbl_hargalongpants1.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargalongpants1.TabIndex = 6;
            this.lbl_hargalongpants1.Text = "Rp. 299.000,-";
            // 
            // lbl_longpants3
            // 
            this.lbl_longpants3.AutoSize = true;
            this.lbl_longpants3.Location = new System.Drawing.Point(684, 347);
            this.lbl_longpants3.Name = "lbl_longpants3";
            this.lbl_longpants3.Size = new System.Drawing.Size(155, 20);
            this.lbl_longpants3.TabIndex = 5;
            this.lbl_longpants3.Text = "Celana Baker Denim";
            // 
            // lbl_longpants2
            // 
            this.lbl_longpants2.AutoSize = true;
            this.lbl_longpants2.Location = new System.Drawing.Point(359, 347);
            this.lbl_longpants2.Name = "lbl_longpants2";
            this.lbl_longpants2.Size = new System.Drawing.Size(204, 20);
            this.lbl_longpants2.TabIndex = 4;
            this.lbl_longpants2.Text = "Celana Rajut Rib Washable";
            // 
            // lbl_longpants1
            // 
            this.lbl_longpants1.AutoSize = true;
            this.lbl_longpants1.Location = new System.Drawing.Point(24, 347);
            this.lbl_longpants1.Name = "lbl_longpants1";
            this.lbl_longpants1.Size = new System.Drawing.Size(196, 20);
            this.lbl_longpants1.TabIndex = 3;
            this.lbl_longpants1.Text = "Celana Katun Ankle Rileks";
            // 
            // pb_longpants3
            // 
            this.pb_longpants3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_longpants3.BackgroundImage")));
            this.pb_longpants3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_longpants3.Location = new System.Drawing.Point(686, 16);
            this.pb_longpants3.Name = "pb_longpants3";
            this.pb_longpants3.Size = new System.Drawing.Size(241, 312);
            this.pb_longpants3.TabIndex = 2;
            this.pb_longpants3.TabStop = false;
            // 
            // pb_longpants2
            // 
            this.pb_longpants2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_longpants2.BackgroundImage")));
            this.pb_longpants2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_longpants2.Location = new System.Drawing.Point(361, 16);
            this.pb_longpants2.Name = "pb_longpants2";
            this.pb_longpants2.Size = new System.Drawing.Size(241, 312);
            this.pb_longpants2.TabIndex = 1;
            this.pb_longpants2.TabStop = false;
            // 
            // pb_longpants1
            // 
            this.pb_longpants1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb_longpants1.BackgroundImage")));
            this.pb_longpants1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_longpants1.Location = new System.Drawing.Point(22, 16);
            this.pb_longpants1.Name = "pb_longpants1";
            this.pb_longpants1.Size = new System.Drawing.Size(241, 312);
            this.pb_longpants1.TabIndex = 0;
            this.pb_longpants1.TabStop = false;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.btn_shoes3);
            this.panel_shoes.Controls.Add(this.btn_shoes2);
            this.panel_shoes.Controls.Add(this.btn_shoes1);
            this.panel_shoes.Controls.Add(this.lbl_hargashoes3);
            this.panel_shoes.Controls.Add(this.lbl_hargashoes2);
            this.panel_shoes.Controls.Add(this.lbl_hargashoes1);
            this.panel_shoes.Controls.Add(this.lbl_shoes3);
            this.panel_shoes.Controls.Add(this.lbl_shoes2);
            this.panel_shoes.Controls.Add(this.lbl_shoes1);
            this.panel_shoes.Controls.Add(this.pictureBox4);
            this.panel_shoes.Controls.Add(this.pictureBox5);
            this.panel_shoes.Controls.Add(this.pictureBox6);
            this.panel_shoes.Location = new System.Drawing.Point(13, 74);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(1026, 460);
            this.panel_shoes.TabIndex = 15;
            // 
            // btn_shoes3
            // 
            this.btn_shoes3.Location = new System.Drawing.Point(686, 417);
            this.btn_shoes3.Name = "btn_shoes3";
            this.btn_shoes3.Size = new System.Drawing.Size(120, 30);
            this.btn_shoes3.TabIndex = 11;
            this.btn_shoes3.Text = "Add to Cart";
            this.btn_shoes3.UseVisualStyleBackColor = true;
            this.btn_shoes3.Click += new System.EventHandler(this.btn_shoes3_Click);
            // 
            // btn_shoes2
            // 
            this.btn_shoes2.Location = new System.Drawing.Point(361, 417);
            this.btn_shoes2.Name = "btn_shoes2";
            this.btn_shoes2.Size = new System.Drawing.Size(120, 30);
            this.btn_shoes2.TabIndex = 10;
            this.btn_shoes2.Text = "Add to Cart";
            this.btn_shoes2.UseVisualStyleBackColor = true;
            this.btn_shoes2.Click += new System.EventHandler(this.btn_shoes2_Click);
            // 
            // btn_shoes1
            // 
            this.btn_shoes1.Location = new System.Drawing.Point(26, 417);
            this.btn_shoes1.Name = "btn_shoes1";
            this.btn_shoes1.Size = new System.Drawing.Size(120, 30);
            this.btn_shoes1.TabIndex = 9;
            this.btn_shoes1.Text = "Add to Cart";
            this.btn_shoes1.UseVisualStyleBackColor = true;
            this.btn_shoes1.Click += new System.EventHandler(this.btn_shoes1_Click);
            // 
            // lbl_hargashoes3
            // 
            this.lbl_hargashoes3.AutoSize = true;
            this.lbl_hargashoes3.Location = new System.Drawing.Point(684, 377);
            this.lbl_hargashoes3.Name = "lbl_hargashoes3";
            this.lbl_hargashoes3.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargashoes3.TabIndex = 8;
            this.lbl_hargashoes3.Text = "Rp. 599.000,-";
            // 
            // lbl_hargashoes2
            // 
            this.lbl_hargashoes2.AutoSize = true;
            this.lbl_hargashoes2.Location = new System.Drawing.Point(359, 377);
            this.lbl_hargashoes2.Name = "lbl_hargashoes2";
            this.lbl_hargashoes2.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargashoes2.TabIndex = 7;
            this.lbl_hargashoes2.Text = "Rp. 999.000,-";
            // 
            // lbl_hargashoes1
            // 
            this.lbl_hargashoes1.AutoSize = true;
            this.lbl_hargashoes1.Location = new System.Drawing.Point(24, 377);
            this.lbl_hargashoes1.Name = "lbl_hargashoes1";
            this.lbl_hargashoes1.Size = new System.Drawing.Size(118, 20);
            this.lbl_hargashoes1.TabIndex = 6;
            this.lbl_hargashoes1.Text = "Rp. 1.549.000,-";
            // 
            // lbl_shoes3
            // 
            this.lbl_shoes3.AutoSize = true;
            this.lbl_shoes3.Location = new System.Drawing.Point(684, 347);
            this.lbl_shoes3.Name = "lbl_shoes3";
            this.lbl_shoes3.Size = new System.Drawing.Size(118, 20);
            this.lbl_shoes3.TabIndex = 5;
            this.lbl_shoes3.Text = "Vans Old Skool";
            // 
            // lbl_shoes2
            // 
            this.lbl_shoes2.AutoSize = true;
            this.lbl_shoes2.Location = new System.Drawing.Point(359, 347);
            this.lbl_shoes2.Name = "lbl_shoes2";
            this.lbl_shoes2.Size = new System.Drawing.Size(147, 20);
            this.lbl_shoes2.TabIndex = 4;
            this.lbl_shoes2.Text = "Converse Chuck 70";
            // 
            // lbl_shoes1
            // 
            this.lbl_shoes1.AutoSize = true;
            this.lbl_shoes1.Location = new System.Drawing.Point(24, 347);
            this.lbl_shoes1.Name = "lbl_shoes1";
            this.lbl_shoes1.Size = new System.Drawing.Size(108, 20);
            this.lbl_shoes1.TabIndex = 3;
            this.lbl_shoes1.Text = "Nike Air Force";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(686, 16);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(241, 312);
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(361, 16);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(241, 312);
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(22, 16);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(241, 312);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // panel_jwl
            // 
            this.panel_jwl.Controls.Add(this.btn_jwl3);
            this.panel_jwl.Controls.Add(this.btn_jwl2);
            this.panel_jwl.Controls.Add(this.btn_jwl1);
            this.panel_jwl.Controls.Add(this.lbl_hargajwl3);
            this.panel_jwl.Controls.Add(this.lbl_hargajwl2);
            this.panel_jwl.Controls.Add(this.lbl_hargajwl1);
            this.panel_jwl.Controls.Add(this.lbl_jwl3);
            this.panel_jwl.Controls.Add(this.lbl_jwl2);
            this.panel_jwl.Controls.Add(this.lbl_jwl1);
            this.panel_jwl.Controls.Add(this.pictureBox7);
            this.panel_jwl.Controls.Add(this.pictureBox8);
            this.panel_jwl.Controls.Add(this.pictureBox9);
            this.panel_jwl.Location = new System.Drawing.Point(8, 61);
            this.panel_jwl.Name = "panel_jwl";
            this.panel_jwl.Size = new System.Drawing.Size(1074, 493);
            this.panel_jwl.TabIndex = 15;
            // 
            // btn_jwl3
            // 
            this.btn_jwl3.Location = new System.Drawing.Point(686, 417);
            this.btn_jwl3.Name = "btn_jwl3";
            this.btn_jwl3.Size = new System.Drawing.Size(120, 30);
            this.btn_jwl3.TabIndex = 11;
            this.btn_jwl3.Text = "Add to Cart";
            this.btn_jwl3.UseVisualStyleBackColor = true;
            this.btn_jwl3.Click += new System.EventHandler(this.btn_jwl3_Click);
            // 
            // btn_jwl2
            // 
            this.btn_jwl2.Location = new System.Drawing.Point(361, 417);
            this.btn_jwl2.Name = "btn_jwl2";
            this.btn_jwl2.Size = new System.Drawing.Size(120, 30);
            this.btn_jwl2.TabIndex = 10;
            this.btn_jwl2.Text = "Add to Cart";
            this.btn_jwl2.UseVisualStyleBackColor = true;
            this.btn_jwl2.Click += new System.EventHandler(this.btn_jwl2_Click);
            // 
            // btn_jwl1
            // 
            this.btn_jwl1.Location = new System.Drawing.Point(26, 417);
            this.btn_jwl1.Name = "btn_jwl1";
            this.btn_jwl1.Size = new System.Drawing.Size(120, 30);
            this.btn_jwl1.TabIndex = 9;
            this.btn_jwl1.Text = "Add to Cart";
            this.btn_jwl1.UseVisualStyleBackColor = true;
            this.btn_jwl1.Click += new System.EventHandler(this.btn_jwl1_Click);
            // 
            // lbl_hargajwl3
            // 
            this.lbl_hargajwl3.AutoSize = true;
            this.lbl_hargajwl3.Location = new System.Drawing.Point(684, 377);
            this.lbl_hargajwl3.Name = "lbl_hargajwl3";
            this.lbl_hargajwl3.Size = new System.Drawing.Size(118, 20);
            this.lbl_hargajwl3.TabIndex = 8;
            this.lbl_hargajwl3.Text = "Rp. 1.315.000,-";
            // 
            // lbl_hargajwl2
            // 
            this.lbl_hargajwl2.AutoSize = true;
            this.lbl_hargajwl2.Location = new System.Drawing.Point(359, 377);
            this.lbl_hargajwl2.Name = "lbl_hargajwl2";
            this.lbl_hargajwl2.Size = new System.Drawing.Size(118, 20);
            this.lbl_hargajwl2.TabIndex = 7;
            this.lbl_hargajwl2.Text = "Rp. 2.975.000,-";
            // 
            // lbl_hargajwl1
            // 
            this.lbl_hargajwl1.AutoSize = true;
            this.lbl_hargajwl1.Location = new System.Drawing.Point(24, 377);
            this.lbl_hargajwl1.Name = "lbl_hargajwl1";
            this.lbl_hargajwl1.Size = new System.Drawing.Size(118, 20);
            this.lbl_hargajwl1.TabIndex = 6;
            this.lbl_hargajwl1.Text = "Rp. 2.975.000,-";
            // 
            // lbl_jwl3
            // 
            this.lbl_jwl3.AutoSize = true;
            this.lbl_jwl3.Location = new System.Drawing.Point(684, 347);
            this.lbl_jwl3.Name = "lbl_jwl3";
            this.lbl_jwl3.Size = new System.Drawing.Size(264, 20);
            this.lbl_jwl3.TabIndex = 5;
            this.lbl_jwl3.Text = "Pandora Sterling Silver Snake Chain";
            // 
            // lbl_jwl2
            // 
            this.lbl_jwl2.AutoSize = true;
            this.lbl_jwl2.Location = new System.Drawing.Point(359, 347);
            this.lbl_jwl2.Name = "lbl_jwl2";
            this.lbl_jwl2.Size = new System.Drawing.Size(285, 20);
            this.lbl_jwl2.TabIndex = 4;
            this.lbl_jwl2.Text = "SWAROVSKI Dazzling Swan Necklace";
            // 
            // lbl_jwl1
            // 
            this.lbl_jwl1.AutoSize = true;
            this.lbl_jwl1.Location = new System.Drawing.Point(24, 347);
            this.lbl_jwl1.Name = "lbl_jwl1";
            this.lbl_jwl1.Size = new System.Drawing.Size(201, 20);
            this.lbl_jwl1.TabIndex = 3;
            this.lbl_jwl1.Text = "Kalung Swan Dancing Blue";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(686, 16);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(241, 312);
            this.pictureBox7.TabIndex = 2;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Location = new System.Drawing.Point(361, 16);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(241, 312);
            this.pictureBox8.TabIndex = 1;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
            this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox9.Location = new System.Drawing.Point(22, 16);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(241, 312);
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.tb_itemPrice);
            this.panel_others.Controls.Add(this.lbl_itemPrice);
            this.panel_others.Controls.Add(this.tb_itemName);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.btn_addOther);
            this.panel_others.Controls.Add(this.lbl_itemName);
            this.panel_others.Controls.Add(this.lbl_uploadImage);
            this.panel_others.Controls.Add(this.pb_uploadImage);
            this.panel_others.Location = new System.Drawing.Point(11, 34);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(540, 451);
            this.panel_others.TabIndex = 16;
            // 
            // tb_itemPrice
            // 
            this.tb_itemPrice.Location = new System.Drawing.Point(315, 206);
            this.tb_itemPrice.Name = "tb_itemPrice";
            this.tb_itemPrice.Size = new System.Drawing.Size(162, 26);
            this.tb_itemPrice.TabIndex = 13;
            this.tb_itemPrice.TextChanged += new System.EventHandler(this.tb_itemPrice_TextChanged);
            this.tb_itemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemPrice_KeyPress);
            // 
            // lbl_itemPrice
            // 
            this.lbl_itemPrice.AutoSize = true;
            this.lbl_itemPrice.Location = new System.Drawing.Point(311, 170);
            this.lbl_itemPrice.Name = "lbl_itemPrice";
            this.lbl_itemPrice.Size = new System.Drawing.Size(84, 20);
            this.lbl_itemPrice.TabIndex = 12;
            this.lbl_itemPrice.Text = "Item Price:";
            // 
            // tb_itemName
            // 
            this.tb_itemName.Location = new System.Drawing.Point(315, 126);
            this.tb_itemName.Name = "tb_itemName";
            this.tb_itemName.Size = new System.Drawing.Size(162, 26);
            this.tb_itemName.TabIndex = 11;
            this.tb_itemName.TextChanged += new System.EventHandler(this.tb_itemName_TextChanged);
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(181, 23);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(120, 30);
            this.btn_upload.TabIndex = 10;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // btn_addOther
            // 
            this.btn_addOther.Location = new System.Drawing.Point(315, 372);
            this.btn_addOther.Name = "btn_addOther";
            this.btn_addOther.Size = new System.Drawing.Size(120, 30);
            this.btn_addOther.TabIndex = 9;
            this.btn_addOther.Text = "Add to Cart";
            this.btn_addOther.UseVisualStyleBackColor = true;
            this.btn_addOther.Click += new System.EventHandler(this.btn_addOther_Click);
            // 
            // lbl_itemName
            // 
            this.lbl_itemName.AutoSize = true;
            this.lbl_itemName.Location = new System.Drawing.Point(311, 90);
            this.lbl_itemName.Name = "lbl_itemName";
            this.lbl_itemName.Size = new System.Drawing.Size(91, 20);
            this.lbl_itemName.TabIndex = 6;
            this.lbl_itemName.Text = "Item Name:";
            // 
            // lbl_uploadImage
            // 
            this.lbl_uploadImage.AutoSize = true;
            this.lbl_uploadImage.Location = new System.Drawing.Point(24, 28);
            this.lbl_uploadImage.Name = "lbl_uploadImage";
            this.lbl_uploadImage.Size = new System.Drawing.Size(109, 20);
            this.lbl_uploadImage.TabIndex = 3;
            this.lbl_uploadImage.Text = "Upload Image";
            // 
            // pb_uploadImage
            // 
            this.pb_uploadImage.Location = new System.Drawing.Point(28, 90);
            this.pb_uploadImage.Name = "pb_uploadImage";
            this.pb_uploadImage.Size = new System.Drawing.Size(241, 312);
            this.pb_uploadImage.TabIndex = 0;
            this.pb_uploadImage.TabStop = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1551, 618);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(90, 49);
            this.btn_delete.TabIndex = 16;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // uniqme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1712, 931);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_jwl);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_longPants);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.lbl_subtotal);
            this.Controls.Add(this.dgv_keranjang);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "uniqme";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.uniqme_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_keranjang)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tshirt1)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_pants1)).EndInit();
            this.panel_longPants.ResumeLayout(false);
            this.panel_longPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_longpants1)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel_jwl.ResumeLayout(false);
            this.panel_jwl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_uploadImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_keranjang;
        private System.Windows.Forms.Label lbl_subtotal;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewerlliesToolStripMenuItem;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.PictureBox pb_tshirt3;
        private System.Windows.Forms.PictureBox pb_tshirt2;
        private System.Windows.Forms.PictureBox pb_tshirt1;
        private System.Windows.Forms.Label lbl_hargatshirt3;
        private System.Windows.Forms.Label lbl_hargatshirt2;
        private System.Windows.Forms.Label lbl_hargatshirt1;
        private System.Windows.Forms.Label lbl_tshirt3;
        private System.Windows.Forms.Label lbl_tshirt2;
        private System.Windows.Forms.Label lbl_tshirt1;
        private System.Windows.Forms.Button btn_addToCart3;
        private System.Windows.Forms.Button btn_addToCart2;
        private System.Windows.Forms.Button btn_addToCart1;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_addShirt3;
        private System.Windows.Forms.Button btn_addShirt2;
        private System.Windows.Forms.Button btn_addShirt1;
        private System.Windows.Forms.Label lbl_hargashirt3;
        private System.Windows.Forms.Label lbl_hargaShirt2;
        private System.Windows.Forms.Label lbl_hargashirt1;
        private System.Windows.Forms.Label lbl_shirt3;
        private System.Windows.Forms.Label lbl_shirt2;
        private System.Windows.Forms.Label lbl_shirt1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_addPants3;
        private System.Windows.Forms.Button btn_addPants2;
        private System.Windows.Forms.Button btn_addPants1;
        private System.Windows.Forms.Label lbl_hargapants3;
        private System.Windows.Forms.Label lbl_hargaPants2;
        private System.Windows.Forms.Label lbl_hargaPants1;
        private System.Windows.Forms.Label lbl_pants3;
        private System.Windows.Forms.Label lbl_pants2;
        private System.Windows.Forms.Label lbl_pants1;
        private System.Windows.Forms.PictureBox pb_pants3;
        private System.Windows.Forms.PictureBox pb_pants2;
        private System.Windows.Forms.PictureBox pb_pants1;
        private System.Windows.Forms.Panel panel_longPants;
        private System.Windows.Forms.Button btn_longpants3;
        private System.Windows.Forms.Button btn_longpants2;
        private System.Windows.Forms.Button btn_longpants1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_hargalongpants2;
        private System.Windows.Forms.Label lbl_hargalongpants1;
        private System.Windows.Forms.Label lbl_longpants3;
        private System.Windows.Forms.Label lbl_longpants2;
        private System.Windows.Forms.Label lbl_longpants1;
        private System.Windows.Forms.PictureBox pb_longpants3;
        private System.Windows.Forms.PictureBox pb_longpants2;
        private System.Windows.Forms.PictureBox pb_longpants1;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_shoes3;
        private System.Windows.Forms.Button btn_shoes2;
        private System.Windows.Forms.Button btn_shoes1;
        private System.Windows.Forms.Label lbl_hargashoes3;
        private System.Windows.Forms.Label lbl_hargashoes2;
        private System.Windows.Forms.Label lbl_hargashoes1;
        private System.Windows.Forms.Label lbl_shoes3;
        private System.Windows.Forms.Label lbl_shoes2;
        private System.Windows.Forms.Label lbl_shoes1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel_jwl;
        private System.Windows.Forms.Button btn_jwl3;
        private System.Windows.Forms.Button btn_jwl2;
        private System.Windows.Forms.Button btn_jwl1;
        private System.Windows.Forms.Label lbl_hargajwl3;
        private System.Windows.Forms.Label lbl_hargajwl2;
        private System.Windows.Forms.Label lbl_hargajwl1;
        private System.Windows.Forms.Label lbl_jwl3;
        private System.Windows.Forms.Label lbl_jwl2;
        private System.Windows.Forms.Label lbl_jwl1;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.TextBox tb_itemPrice;
        private System.Windows.Forms.Label lbl_itemPrice;
        private System.Windows.Forms.TextBox tb_itemName;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Button btn_addOther;
        private System.Windows.Forms.Label lbl_itemName;
        private System.Windows.Forms.Label lbl_uploadImage;
        private System.Windows.Forms.PictureBox pb_uploadImage;
        private System.Windows.Forms.Button btn_delete;
    }
}

