﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH08_Sherin_Alvinia_Yonatan
{
    
    public partial class uniqme : Form
    {
        DataTable dtKeranjang = new DataTable();

        // T-Shirt
        public int qtyTshirt1 = 0;
        public int qtyTshirt2 = 0;
        public int qtyTshirt3 = 0;

        // SHIRT
        public int qtyShirt1 = 0;
        public int qtyShirt2 = 0;
        public int qtyShirt3 = 0;

        // PANTS
        public int qtyPants1 = 0;
        public int qtyPants2 = 0;
        public int qtyPants3 = 0;

        // LONG PANTS
        public int qtyLongPants1 = 0;
        public int qtyLongPants2 = 0;
        public int qtyLongPants3 = 0;

        // SHOES
        public int qtyshoes1 = 0;
        public int qtyshoes2 = 0;
        public int qtyshoes3 = 0;

        // JEWELLERIES
        public int qtyJwl1 = 0;
        public int qtyJwl2 = 0;
        public int qtyJwl3 = 0;

        public int qtyOther = 0;
        public double total = 0;
        public uniqme()
        {
            InitializeComponent();
            dtKeranjang.Columns.Add("Item Name");
            dtKeranjang.Columns.Add("Quantity");
            dtKeranjang.Columns.Add("Price");
            dtKeranjang.Columns.Add("Total");
            

        }

        private void uniqme_Load(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jwl.Visible = false;
            panel_others.Visible = false;
            dgv_keranjang.DataSource = dtKeranjang;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = true;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jwl.Visible = false;
            panel_others.Visible = false;
        }

        // T-SHIRT
        private void btn_addToCart1_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;
            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_tshirt1.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyTshirt1++;
                    dtKeranjang.Rows.Add(lbl_tshirt1.Text, qtyTshirt1, 199000, 199000 * qtyTshirt1);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyTshirt1 = 0;
                qtyTshirt1++;
                dtKeranjang.Rows.Add(lbl_tshirt1.Text, qtyTshirt1, 199000, 199000 * qtyTshirt1);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();

        }

        private void btn_addToCart2_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_tshirt2.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyTshirt2++;
                    dtKeranjang.Rows.Add(lbl_tshirt2.Text, qtyTshirt2, 199000, 199000 * qtyTshirt2);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyTshirt2 = 0;
                qtyTshirt2++;
                dtKeranjang.Rows.Add(lbl_tshirt2.Text, qtyTshirt2, 199000, 199000 * qtyTshirt2);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_addToCart3_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_tshirt3.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyTshirt3++;
                    dtKeranjang.Rows.Add(lbl_tshirt3.Text, qtyTshirt3, 149000, 149000 * qtyTshirt3);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
                
            }
            if (cek == false)
            {
                qtyTshirt3 = 0;
                qtyTshirt3++;
                dtKeranjang.Rows.Add(lbl_tshirt3.Text, qtyTshirt3, 149000, 149000 * qtyTshirt3);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        // SHIRT
        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = true;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jwl.Visible = false;
            panel_others.Visible = false;
        }

        private void btn_addShirt1_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_shirt1.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyShirt1++;
                    dtKeranjang.Rows.Add(lbl_shirt1.Text, qtyShirt1, 499000, 499000 * qtyShirt1);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyShirt1 = 0;
                qtyShirt1++;
                dtKeranjang.Rows.Add(lbl_shirt1.Text, qtyShirt1, 499000, 499000 * qtyShirt1);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_addShirt2_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_shirt2.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyShirt2++;
                    dtKeranjang.Rows.Add(lbl_shirt2.Text, qtyShirt2, 399000, 399000 * qtyShirt2);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            
            if (cek == false)
            {
                qtyShirt2 = 0;
                qtyShirt2++;
                dtKeranjang.Rows.Add(lbl_shirt2.Text, qtyShirt2, 399000, 399000 * qtyShirt2);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_addShirt3_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_shirt3.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyShirt3++;
                    dtKeranjang.Rows.Add(lbl_shirt3.Text, qtyShirt3, 299000, 299000 * qtyShirt3);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyShirt3 = 0;
                qtyShirt3++;
                dtKeranjang.Rows.Add(lbl_shirt3.Text, qtyShirt3, 299000, 299000 * qtyShirt3);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();

        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = true;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jwl.Visible = false;
            panel_others.Visible = false;
        }

        // pants
        private void btn_addPants1_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_pants1.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyPants1++;
                    dtKeranjang.Rows.Add(lbl_pants1.Text, qtyPants1, 149000, 149000 * qtyPants1);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyPants1 = 0;
                qtyPants1++;
                dtKeranjang.Rows.Add(lbl_pants1.Text, qtyPants1, 149000, 149000 * qtyPants1);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_addPants2_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_pants2.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyPants2++;
                    dtKeranjang.Rows.Add(lbl_pants2.Text, qtyPants2, 399000, 399000 * qtyPants2);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyPants2 = 0;
                qtyPants2++;
                dtKeranjang.Rows.Add(lbl_pants2.Text, qtyPants2, 399000, 399000 * qtyPants2);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_addPants3_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_pants3.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyPants3++;
                    dtKeranjang.Rows.Add(lbl_pants3.Text, qtyPants3, 299000, 299000 * qtyPants3);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyPants3 = 0;
                qtyPants3++;
                dtKeranjang.Rows.Add(lbl_pants3.Text, qtyPants3, 299000, 299000 * qtyPants3);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_longpants1_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_longpants1.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyLongPants1++;
                    dtKeranjang.Rows.Add(lbl_longpants1.Text, qtyLongPants1, 299000, 299000 * qtyLongPants1);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyLongPants1 = 0;
                qtyLongPants1++;
                dtKeranjang.Rows.Add(lbl_longpants1.Text, qtyLongPants1, 299000, 299000 * qtyLongPants1);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_longpants2_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_longpants2.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyLongPants2++;
                    dtKeranjang.Rows.Add(lbl_longpants2.Text, qtyLongPants2, 299000, 299000 * qtyLongPants2);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyLongPants2 = 0;
                qtyLongPants2++;
                dtKeranjang.Rows.Add(lbl_longpants2.Text, qtyLongPants2, 299000, 299000 * qtyLongPants2);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_longpants3_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_longpants3.Text))
                {
                    cek = true;
                    dtKeranjang.Rows.Remove(row);
                    qtyLongPants3++;
                    dtKeranjang.Rows.Add(lbl_longpants3.Text, qtyLongPants3, 699000, 699000 * qtyLongPants3);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }

            if (cek == false)
            {
                qtyLongPants3 = 0;
                qtyLongPants3++;
                dtKeranjang.Rows.Add(lbl_longpants3.Text, qtyLongPants3, 699000, 699000 * qtyLongPants3);

                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = true;
            panel_shoes.Visible = false;
            panel_jwl.Visible = false;
            panel_others.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = true;
            panel_jwl.Visible = false;
            panel_others.Visible = false;
        }

        private void btn_shoes1_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_shoes1.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyshoes1++;
                    dtKeranjang.Rows.Add(lbl_shoes1.Text, qtyshoes1, 1549000, 1549000 * qtyshoes1);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyshoes1 = 0;
                qtyshoes1++;
                dtKeranjang.Rows.Add(lbl_shoes1.Text, qtyshoes1, 1549000, 1549000 * qtyshoes1);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_shoes2_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_shoes2.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyshoes2++;
                    dtKeranjang.Rows.Add(lbl_shoes2.Text, qtyshoes2, 999000, 999000 * qtyshoes2);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyshoes2 = 0;
                qtyshoes2++;
                dtKeranjang.Rows.Add(lbl_shoes2.Text, qtyshoes2, 999000, 999000 * qtyshoes2);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_shoes3_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_shoes3.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyshoes3++;
                    dtKeranjang.Rows.Add(lbl_shoes3.Text, qtyshoes3, 599000, 599000 * qtyshoes3);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyshoes3 = 0;
                qtyshoes3++;
                dtKeranjang.Rows.Add(lbl_shoes3.Text, qtyshoes3, 599000, 599000 * qtyshoes3);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void jewerlliesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jwl.Visible = true;
            panel_others.Visible = false;
        }

        private void btn_jwl1_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            { 
                if (row[0].ToString().Contains(lbl_jwl1.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyJwl1++;
                    dtKeranjang.Rows.Add(lbl_jwl1.Text, qtyJwl1, 2975000, 2975000 * qtyJwl1);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyJwl1 = 0;
                qtyJwl1++;
                dtKeranjang.Rows.Add(lbl_jwl1.Text, qtyJwl1, 2975000, 2975000 * qtyJwl1);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_jwl2_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_jwl2.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyJwl2++;
                    dtKeranjang.Rows.Add(lbl_jwl2.Text, qtyJwl2, 2975000, 2975000 * qtyJwl2);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyJwl2 = 0;
                qtyJwl2++;
                dtKeranjang.Rows.Add(lbl_jwl2.Text, qtyJwl2, 2975000, 2975000 * qtyJwl2);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void btn_jwl3_Click(object sender, EventArgs e)
        {
            int subtotal = 0;
            bool cek = false;

            foreach (DataRow row in dtKeranjang.Rows)
            {
                if (row[0].ToString().Contains(lbl_jwl3.Text))
                {
                    dtKeranjang.Rows.Remove(row);
                    cek = true;
                    qtyJwl3++;
                    dtKeranjang.Rows.Add(lbl_jwl3.Text, qtyJwl3, 1315000, 1315000 * qtyJwl3);

                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subtotal * 0.10) + subtotal;
                    tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                    tb_total.Text = "Rp. " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (cek == false)
            {
                qtyJwl3 = 0;
                qtyJwl3++;
                dtKeranjang.Rows.Add(lbl_jwl3.Text, qtyJwl1, 1315000, 1315000 * qtyJwl3);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subtotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subtotal * 0.10) + subtotal;
                tb_subtotal.Text = "Rp. " + subtotal.ToString("N");
                tb_total.Text = "Rp. " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_shoes.Visible = false;
            panel_jwl.Visible = false;
            panel_others.Visible = true;

            btn_addOther.Enabled = false;
            tb_itemName.Enabled = false;
            tb_itemPrice.Enabled = false;
        }

        // OTHER
        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.jpeg, *.png)|*.jpg; *.jpeg; *.png";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pb_uploadImage.Image = Image.FromFile(ofd.FileName);
                pb_uploadImage.SizeMode = PictureBoxSizeMode.StretchImage;
                tb_itemName.Enabled = true;
                tb_itemPrice.Enabled = true;
            }
            dgv_keranjang.ClearSelection();
        }

        private void tb_itemName_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemName.Text.Length > 0 && tb_itemPrice.Text.Length > 0)
            {
                btn_addOther.Enabled = true;
            }
            else
            {
                btn_addOther.Enabled = false;
            }
        }

        private void tb_itemPrice_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemName.Text.Length > 0 && tb_itemPrice.Text.Length > 0)
            {
                btn_addOther.Enabled = true;
            }
            else
            {
                btn_addOther.Enabled = false;
            }
        }

        private void tb_itemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btn_addOther_Click(object sender, EventArgs e)
        {
            int subTotal = 0;
            int price = Convert.ToInt32(tb_itemPrice.Text);
            bool cek = false;
            foreach (DataRow rows in dtKeranjang.Rows)
            {
                if (rows[0].ToString().Contains(tb_itemName.Text))
                {
                    dtKeranjang.Rows.Remove(rows);
                    cek = true;
                    qtyOther += 1;
                    dtKeranjang.Rows.Add(tb_itemName.Text, qtyOther, price, price * qtyOther);
                    for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                    {
                        subTotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                    }
                    total = (subTotal * 0.10) + (subTotal);
                    tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                    tb_total.Text = "Rp " + total.ToString("N");
                    break;
                }
                else
                {
                    cek = false;
                }
            }
            if (!cek)
            {
                qtyOther = 0;
                qtyOther += 1;
                dtKeranjang.Rows.Add(tb_itemName.Text, qtyOther, price, price * qtyOther);
                for (int i = 0; i < dtKeranjang.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dtKeranjang.Rows[i][3]);
                }
                total = (subTotal * 0.10) + (subTotal);
                tb_subtotal.Text = "Rp " + subTotal.ToString("N");
                tb_total.Text = "Rp " + total.ToString("N");
            }
            dgv_keranjang.ClearSelection();
            pb_uploadImage.Image = null;
            tb_itemName.Clear();
            tb_itemPrice.Clear();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_keranjang.SelectedRows.Count == 0)
            {
                MessageBox.Show("belum diselect");
            }
            else
            {
                int indexPilih = dgv_keranjang.CurrentCell.RowIndex;
                int itemPrice = Convert.ToInt32(dtKeranjang.Rows[indexPilih][3]);
                string subtotal = tb_subtotal.Text;
                string subtotal_ = subtotal.Substring(3).Replace(",", "").Replace(".", "").Split('.')[0];
                subtotal_ = subtotal_.Substring(0, subtotal_.Length - 2);
                tb_subtotal.Text = "Rp " + (Convert.ToInt32(subtotal_) - itemPrice).ToString("N");

                int sub = Convert.ToInt32(subtotal_) - itemPrice;
                tb_total.Text = "Rp " + ((sub * 0.10) + sub).ToString("N");
                dtKeranjang.Rows.RemoveAt(indexPilih);
            }
        }
    }
}
