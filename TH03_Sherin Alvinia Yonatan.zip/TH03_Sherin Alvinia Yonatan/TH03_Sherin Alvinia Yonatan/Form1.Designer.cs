﻿namespace TH03_Sherin_Alvinia_Yonatan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_ucbank = new System.Windows.Forms.Label();
            this.lbl_loginViewUser = new System.Windows.Forms.Label();
            this.lbl_password = new System.Windows.Forms.Label();
            this.tb_loginViewUsername = new System.Windows.Forms.TextBox();
            this.tb_loginViewPassword = new System.Windows.Forms.TextBox();
            this.btn_loginviewLogin = new System.Windows.Forms.Button();
            this.btn_loginviewRegister = new System.Windows.Forms.Button();
            this.panel_loginview = new System.Windows.Forms.Panel();
            this.panel_regisView = new System.Windows.Forms.Panel();
            this.tb_regisUser = new System.Windows.Forms.TextBox();
            this.btn_registermenu = new System.Windows.Forms.Button();
            this.lbl_regisUser = new System.Windows.Forms.Label();
            this.lbl_regisPassword = new System.Windows.Forms.Label();
            this.tb_regisPassword = new System.Windows.Forms.TextBox();
            this.panel_depositview = new System.Windows.Forms.Panel();
            this.tb_depositviewInputDeposit = new System.Windows.Forms.TextBox();
            this.btn_DepositLogout = new System.Windows.Forms.Button();
            this.btn_depositviewDeposit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel_mainview = new System.Windows.Forms.Panel();
            this.btn_mainviewLogout = new System.Windows.Forms.Button();
            this.btn_mainviewWithdraw = new System.Windows.Forms.Button();
            this.lbl_mainviewBalance = new System.Windows.Forms.Label();
            this.btn_mainviewDeposit = new System.Windows.Forms.Button();
            this.lbl_jumlahUang = new System.Windows.Forms.Label();
            this.panel_withdrawView = new System.Windows.Forms.Panel();
            this.lbl_withdrawViewbalance = new System.Windows.Forms.Label();
            this.lbl_withdrawviewJumlahUang = new System.Windows.Forms.Label();
            this.tb_withdrawViewInput = new System.Windows.Forms.TextBox();
            this.btn_withdrawviewLogout = new System.Windows.Forms.Button();
            this.btn_withdrawViewWD = new System.Windows.Forms.Button();
            this.lbl_withdrawViewInput = new System.Windows.Forms.Label();
            this.panel_loginview.SuspendLayout();
            this.panel_regisView.SuspendLayout();
            this.panel_depositview.SuspendLayout();
            this.panel_mainview.SuspendLayout();
            this.panel_withdrawView.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_ucbank
            // 
            this.lbl_ucbank.AutoSize = true;
            this.lbl_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ucbank.Location = new System.Drawing.Point(105, 73);
            this.lbl_ucbank.Name = "lbl_ucbank";
            this.lbl_ucbank.Size = new System.Drawing.Size(361, 82);
            this.lbl_ucbank.TabIndex = 0;
            this.lbl_ucbank.Text = "UC BANK";
            // 
            // lbl_loginViewUser
            // 
            this.lbl_loginViewUser.AutoSize = true;
            this.lbl_loginViewUser.Location = new System.Drawing.Point(18, 26);
            this.lbl_loginViewUser.Name = "lbl_loginViewUser";
            this.lbl_loginViewUser.Size = new System.Drawing.Size(83, 20);
            this.lbl_loginViewUser.TabIndex = 1;
            this.lbl_loginViewUser.Text = "Username";
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(18, 58);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(78, 20);
            this.lbl_password.TabIndex = 2;
            this.lbl_password.Text = "Password";
            // 
            // tb_loginViewUsername
            // 
            this.tb_loginViewUsername.Location = new System.Drawing.Point(117, 23);
            this.tb_loginViewUsername.Name = "tb_loginViewUsername";
            this.tb_loginViewUsername.Size = new System.Drawing.Size(183, 26);
            this.tb_loginViewUsername.TabIndex = 3;
            // 
            // tb_loginViewPassword
            // 
            this.tb_loginViewPassword.Location = new System.Drawing.Point(117, 55);
            this.tb_loginViewPassword.Name = "tb_loginViewPassword";
            this.tb_loginViewPassword.Size = new System.Drawing.Size(183, 26);
            this.tb_loginViewPassword.TabIndex = 4;
            // 
            // btn_loginviewLogin
            // 
            this.btn_loginviewLogin.Location = new System.Drawing.Point(191, 98);
            this.btn_loginviewLogin.Name = "btn_loginviewLogin";
            this.btn_loginviewLogin.Size = new System.Drawing.Size(109, 35);
            this.btn_loginviewLogin.TabIndex = 5;
            this.btn_loginviewLogin.Text = "Login";
            this.btn_loginviewLogin.UseVisualStyleBackColor = true;
            this.btn_loginviewLogin.Click += new System.EventHandler(this.btn_loginviewLogin_Click);
            // 
            // btn_loginviewRegister
            // 
            this.btn_loginviewRegister.Location = new System.Drawing.Point(191, 139);
            this.btn_loginviewRegister.Name = "btn_loginviewRegister";
            this.btn_loginviewRegister.Size = new System.Drawing.Size(109, 39);
            this.btn_loginviewRegister.TabIndex = 6;
            this.btn_loginviewRegister.Text = "Register";
            this.btn_loginviewRegister.UseVisualStyleBackColor = true;
            this.btn_loginviewRegister.Click += new System.EventHandler(this.btn_loginviewRegister_Click);
            // 
            // panel_loginview
            // 
            this.panel_loginview.Controls.Add(this.tb_loginViewUsername);
            this.panel_loginview.Controls.Add(this.btn_loginviewRegister);
            this.panel_loginview.Controls.Add(this.lbl_loginViewUser);
            this.panel_loginview.Controls.Add(this.btn_loginviewLogin);
            this.panel_loginview.Controls.Add(this.lbl_password);
            this.panel_loginview.Controls.Add(this.tb_loginViewPassword);
            this.panel_loginview.Location = new System.Drawing.Point(119, 178);
            this.panel_loginview.Name = "panel_loginview";
            this.panel_loginview.Size = new System.Drawing.Size(331, 199);
            this.panel_loginview.TabIndex = 7;
            // 
            // panel_regisView
            // 
            this.panel_regisView.Controls.Add(this.tb_regisUser);
            this.panel_regisView.Controls.Add(this.btn_registermenu);
            this.panel_regisView.Controls.Add(this.lbl_regisUser);
            this.panel_regisView.Controls.Add(this.lbl_regisPassword);
            this.panel_regisView.Controls.Add(this.tb_regisPassword);
            this.panel_regisView.Location = new System.Drawing.Point(135, 158);
            this.panel_regisView.Name = "panel_regisView";
            this.panel_regisView.Size = new System.Drawing.Size(331, 199);
            this.panel_regisView.TabIndex = 8;
            // 
            // tb_regisUser
            // 
            this.tb_regisUser.Location = new System.Drawing.Point(117, 23);
            this.tb_regisUser.Name = "tb_regisUser";
            this.tb_regisUser.Size = new System.Drawing.Size(183, 26);
            this.tb_regisUser.TabIndex = 3;
            // 
            // btn_registermenu
            // 
            this.btn_registermenu.Location = new System.Drawing.Point(191, 98);
            this.btn_registermenu.Name = "btn_registermenu";
            this.btn_registermenu.Size = new System.Drawing.Size(109, 39);
            this.btn_registermenu.TabIndex = 6;
            this.btn_registermenu.Text = "Register";
            this.btn_registermenu.UseVisualStyleBackColor = true;
            this.btn_registermenu.Click += new System.EventHandler(this.btn_registermenu_Click);
            // 
            // lbl_regisUser
            // 
            this.lbl_regisUser.AutoSize = true;
            this.lbl_regisUser.Location = new System.Drawing.Point(18, 26);
            this.lbl_regisUser.Name = "lbl_regisUser";
            this.lbl_regisUser.Size = new System.Drawing.Size(83, 20);
            this.lbl_regisUser.TabIndex = 1;
            this.lbl_regisUser.Text = "Username";
            // 
            // lbl_regisPassword
            // 
            this.lbl_regisPassword.AutoSize = true;
            this.lbl_regisPassword.Location = new System.Drawing.Point(18, 58);
            this.lbl_regisPassword.Name = "lbl_regisPassword";
            this.lbl_regisPassword.Size = new System.Drawing.Size(78, 20);
            this.lbl_regisPassword.TabIndex = 2;
            this.lbl_regisPassword.Text = "Password";
            // 
            // tb_regisPassword
            // 
            this.tb_regisPassword.Location = new System.Drawing.Point(117, 55);
            this.tb_regisPassword.Name = "tb_regisPassword";
            this.tb_regisPassword.Size = new System.Drawing.Size(183, 26);
            this.tb_regisPassword.TabIndex = 4;
            // 
            // panel_depositview
            // 
            this.panel_depositview.Controls.Add(this.tb_depositviewInputDeposit);
            this.panel_depositview.Controls.Add(this.btn_DepositLogout);
            this.panel_depositview.Controls.Add(this.btn_depositviewDeposit);
            this.panel_depositview.Controls.Add(this.label1);
            this.panel_depositview.Location = new System.Drawing.Point(107, 170);
            this.panel_depositview.Name = "panel_depositview";
            this.panel_depositview.Size = new System.Drawing.Size(340, 204);
            this.panel_depositview.TabIndex = 9;
            // 
            // tb_depositviewInputDeposit
            // 
            this.tb_depositviewInputDeposit.Location = new System.Drawing.Point(64, 109);
            this.tb_depositviewInputDeposit.Name = "tb_depositviewInputDeposit";
            this.tb_depositviewInputDeposit.Size = new System.Drawing.Size(183, 26);
            this.tb_depositviewInputDeposit.TabIndex = 7;
            // 
            // btn_DepositLogout
            // 
            this.btn_DepositLogout.Location = new System.Drawing.Point(191, 18);
            this.btn_DepositLogout.Name = "btn_DepositLogout";
            this.btn_DepositLogout.Size = new System.Drawing.Size(109, 39);
            this.btn_DepositLogout.TabIndex = 8;
            this.btn_DepositLogout.Text = "Logout";
            this.btn_DepositLogout.UseVisualStyleBackColor = true;
            this.btn_DepositLogout.Click += new System.EventHandler(this.btn_DepositLogout_Click);
            // 
            // btn_depositviewDeposit
            // 
            this.btn_depositviewDeposit.Location = new System.Drawing.Point(102, 141);
            this.btn_depositviewDeposit.Name = "btn_depositviewDeposit";
            this.btn_depositviewDeposit.Size = new System.Drawing.Size(109, 39);
            this.btn_depositviewDeposit.TabIndex = 7;
            this.btn_depositviewDeposit.Text = "Deposit";
            this.btn_depositviewDeposit.UseVisualStyleBackColor = true;
            this.btn_depositviewDeposit.Click += new System.EventHandler(this.btn_depositviewDeposit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Input Deposit Amount:\r\n";
            // 
            // panel_mainview
            // 
            this.panel_mainview.Controls.Add(this.btn_mainviewLogout);
            this.panel_mainview.Controls.Add(this.btn_mainviewWithdraw);
            this.panel_mainview.Controls.Add(this.lbl_mainviewBalance);
            this.panel_mainview.Controls.Add(this.btn_mainviewDeposit);
            this.panel_mainview.Controls.Add(this.lbl_jumlahUang);
            this.panel_mainview.Location = new System.Drawing.Point(119, 178);
            this.panel_mainview.Name = "panel_mainview";
            this.panel_mainview.Size = new System.Drawing.Size(365, 216);
            this.panel_mainview.TabIndex = 8;
            // 
            // btn_mainviewLogout
            // 
            this.btn_mainviewLogout.Location = new System.Drawing.Point(191, 18);
            this.btn_mainviewLogout.Name = "btn_mainviewLogout";
            this.btn_mainviewLogout.Size = new System.Drawing.Size(109, 39);
            this.btn_mainviewLogout.TabIndex = 9;
            this.btn_mainviewLogout.Text = "Logout";
            this.btn_mainviewLogout.UseVisualStyleBackColor = true;
            this.btn_mainviewLogout.Click += new System.EventHandler(this.btn_mainviewLogout_Click);
            // 
            // btn_mainviewWithdraw
            // 
            this.btn_mainviewWithdraw.Location = new System.Drawing.Point(191, 139);
            this.btn_mainviewWithdraw.Name = "btn_mainviewWithdraw";
            this.btn_mainviewWithdraw.Size = new System.Drawing.Size(109, 39);
            this.btn_mainviewWithdraw.TabIndex = 6;
            this.btn_mainviewWithdraw.Text = "Withdraw";
            this.btn_mainviewWithdraw.UseVisualStyleBackColor = true;
            this.btn_mainviewWithdraw.Click += new System.EventHandler(this.btn_mainviewWithdraw_Click);
            // 
            // lbl_mainviewBalance
            // 
            this.lbl_mainviewBalance.AutoSize = true;
            this.lbl_mainviewBalance.Location = new System.Drawing.Point(18, 71);
            this.lbl_mainviewBalance.Name = "lbl_mainviewBalance";
            this.lbl_mainviewBalance.Size = new System.Drawing.Size(67, 20);
            this.lbl_mainviewBalance.TabIndex = 1;
            this.lbl_mainviewBalance.Text = "Balance";
            // 
            // btn_mainviewDeposit
            // 
            this.btn_mainviewDeposit.Location = new System.Drawing.Point(191, 98);
            this.btn_mainviewDeposit.Name = "btn_mainviewDeposit";
            this.btn_mainviewDeposit.Size = new System.Drawing.Size(109, 35);
            this.btn_mainviewDeposit.TabIndex = 5;
            this.btn_mainviewDeposit.Text = "Deposit";
            this.btn_mainviewDeposit.UseVisualStyleBackColor = true;
            this.btn_mainviewDeposit.Click += new System.EventHandler(this.btn_mainviewDeposit_Click);
            // 
            // lbl_jumlahUang
            // 
            this.lbl_jumlahUang.AutoSize = true;
            this.lbl_jumlahUang.Location = new System.Drawing.Point(18, 103);
            this.lbl_jumlahUang.Name = "lbl_jumlahUang";
            this.lbl_jumlahUang.Size = new System.Drawing.Size(65, 20);
            this.lbl_jumlahUang.TabIndex = 2;
            this.lbl_jumlahUang.Text = "Rp.0,00";
            // 
            // panel_withdrawView
            // 
            this.panel_withdrawView.Controls.Add(this.lbl_withdrawViewbalance);
            this.panel_withdrawView.Controls.Add(this.lbl_withdrawviewJumlahUang);
            this.panel_withdrawView.Controls.Add(this.tb_withdrawViewInput);
            this.panel_withdrawView.Controls.Add(this.btn_withdrawviewLogout);
            this.panel_withdrawView.Controls.Add(this.btn_withdrawViewWD);
            this.panel_withdrawView.Controls.Add(this.lbl_withdrawViewInput);
            this.panel_withdrawView.Location = new System.Drawing.Point(122, 161);
            this.panel_withdrawView.Name = "panel_withdrawView";
            this.panel_withdrawView.Size = new System.Drawing.Size(331, 283);
            this.panel_withdrawView.TabIndex = 10;
            // 
            // lbl_withdrawViewbalance
            // 
            this.lbl_withdrawViewbalance.AutoSize = true;
            this.lbl_withdrawViewbalance.Location = new System.Drawing.Point(124, 82);
            this.lbl_withdrawViewbalance.Name = "lbl_withdrawViewbalance";
            this.lbl_withdrawViewbalance.Size = new System.Drawing.Size(67, 20);
            this.lbl_withdrawViewbalance.TabIndex = 10;
            this.lbl_withdrawViewbalance.Text = "Balance";
            // 
            // lbl_withdrawviewJumlahUang
            // 
            this.lbl_withdrawviewJumlahUang.AutoSize = true;
            this.lbl_withdrawviewJumlahUang.Location = new System.Drawing.Point(124, 114);
            this.lbl_withdrawviewJumlahUang.Name = "lbl_withdrawviewJumlahUang";
            this.lbl_withdrawviewJumlahUang.Size = new System.Drawing.Size(65, 20);
            this.lbl_withdrawviewJumlahUang.TabIndex = 11;
            this.lbl_withdrawviewJumlahUang.Text = "Rp.0,00";
            // 
            // tb_withdrawViewInput
            // 
            this.tb_withdrawViewInput.Location = new System.Drawing.Point(66, 189);
            this.tb_withdrawViewInput.Name = "tb_withdrawViewInput";
            this.tb_withdrawViewInput.Size = new System.Drawing.Size(183, 26);
            this.tb_withdrawViewInput.TabIndex = 7;
            // 
            // btn_withdrawviewLogout
            // 
            this.btn_withdrawviewLogout.Location = new System.Drawing.Point(191, 18);
            this.btn_withdrawviewLogout.Name = "btn_withdrawviewLogout";
            this.btn_withdrawviewLogout.Size = new System.Drawing.Size(109, 39);
            this.btn_withdrawviewLogout.TabIndex = 8;
            this.btn_withdrawviewLogout.Text = "Logout";
            this.btn_withdrawviewLogout.UseVisualStyleBackColor = true;
            this.btn_withdrawviewLogout.Click += new System.EventHandler(this.btn_withdrawviewLogout_Click);
            // 
            // btn_withdrawViewWD
            // 
            this.btn_withdrawViewWD.Location = new System.Drawing.Point(104, 221);
            this.btn_withdrawViewWD.Name = "btn_withdrawViewWD";
            this.btn_withdrawViewWD.Size = new System.Drawing.Size(109, 39);
            this.btn_withdrawViewWD.TabIndex = 7;
            this.btn_withdrawViewWD.Text = "Withdraw";
            this.btn_withdrawViewWD.UseVisualStyleBackColor = true;
            this.btn_withdrawViewWD.Click += new System.EventHandler(this.btn_withdrawViewWD_Click);
            // 
            // lbl_withdrawViewInput
            // 
            this.lbl_withdrawViewInput.AutoSize = true;
            this.lbl_withdrawViewInput.Location = new System.Drawing.Point(67, 158);
            this.lbl_withdrawViewInput.Name = "lbl_withdrawViewInput";
            this.lbl_withdrawViewInput.Size = new System.Drawing.Size(192, 20);
            this.lbl_withdrawViewInput.TabIndex = 1;
            this.lbl_withdrawViewInput.Text = "Input Withdrawal Amount:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1476, 964);
            this.Controls.Add(this.panel_withdrawView);
            this.Controls.Add(this.panel_mainview);
            this.Controls.Add(this.panel_depositview);
            this.Controls.Add(this.panel_regisView);
            this.Controls.Add(this.panel_loginview);
            this.Controls.Add(this.lbl_ucbank);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_loginview.ResumeLayout(false);
            this.panel_loginview.PerformLayout();
            this.panel_regisView.ResumeLayout(false);
            this.panel_regisView.PerformLayout();
            this.panel_depositview.ResumeLayout(false);
            this.panel_depositview.PerformLayout();
            this.panel_mainview.ResumeLayout(false);
            this.panel_mainview.PerformLayout();
            this.panel_withdrawView.ResumeLayout(false);
            this.panel_withdrawView.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_ucbank;
        private System.Windows.Forms.Label lbl_loginViewUser;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.TextBox tb_loginViewUsername;
        private System.Windows.Forms.TextBox tb_loginViewPassword;
        private System.Windows.Forms.Button btn_loginviewLogin;
        private System.Windows.Forms.Button btn_loginviewRegister;
        private System.Windows.Forms.Panel panel_loginview;
        private System.Windows.Forms.Panel panel_regisView;
        private System.Windows.Forms.TextBox tb_regisUser;
        private System.Windows.Forms.Button btn_registermenu;
        private System.Windows.Forms.Label lbl_regisUser;
        private System.Windows.Forms.Label lbl_regisPassword;
        private System.Windows.Forms.TextBox tb_regisPassword;
        private System.Windows.Forms.Panel panel_depositview;
        private System.Windows.Forms.TextBox tb_depositviewInputDeposit;
        private System.Windows.Forms.Button btn_DepositLogout;
        private System.Windows.Forms.Button btn_depositviewDeposit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel_mainview;
        private System.Windows.Forms.Button btn_mainviewLogout;
        private System.Windows.Forms.Button btn_mainviewWithdraw;
        private System.Windows.Forms.Label lbl_mainviewBalance;
        private System.Windows.Forms.Button btn_mainviewDeposit;
        private System.Windows.Forms.Label lbl_jumlahUang;
        private System.Windows.Forms.Panel panel_withdrawView;
        private System.Windows.Forms.TextBox tb_withdrawViewInput;
        private System.Windows.Forms.Button btn_withdrawviewLogout;
        private System.Windows.Forms.Button btn_withdrawViewWD;
        private System.Windows.Forms.Label lbl_withdrawViewInput;
        private System.Windows.Forms.Label lbl_withdrawViewbalance;
        private System.Windows.Forms.Label lbl_withdrawviewJumlahUang;
    }
}

