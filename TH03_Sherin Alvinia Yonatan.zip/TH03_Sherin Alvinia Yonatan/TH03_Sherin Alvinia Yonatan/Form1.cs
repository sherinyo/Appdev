﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Sherin_Alvinia_Yonatan
{
    public partial class Form1 : Form
    {
        DataTable UserPass = new DataTable();
        string simpan_username = string.Empty;
        string simpan_password = string.Empty;
        string simpanlogin = string.Empty;

        public Form1()
        {
            InitializeComponent();
            CekBalancePerUser();
            UserPass.Columns.Add("Username", typeof(string));
            UserPass.Columns.Add("Password", typeof(string));
            UserPass.Columns.Add("Balance", typeof(long));

            panel_regisView.Visible = false;
            panel_mainview.Visible = false;
            panel_depositview.Visible = false;
            panel_withdrawView.Visible = false;

        }


        private void btn_loginviewLogin_Click(object sender, EventArgs e) // Login View
        {
            simpan_username = tb_loginViewUsername.Text;
            simpan_password = tb_loginViewPassword.Text;

            if (tb_loginViewUsername.Text == "" || tb_loginViewPassword.Text == "")
            {
                MessageBox.Show("Please Field The Text");
                return;
            }
            else if (!simpan_username.Contains(simpan_username))
            {
                MessageBox.Show("Please Register First");
                return;
            }

            int cnt = 0;
            foreach (DataRow bagianrow in UserPass.Rows)
            {
                
               
                if (bagianrow["Username"].ToString() == simpan_username)
                {
                    cnt += 1;
                    if (bagianrow["Password"].ToString() == simpan_password)
                    {
                        simpanlogin = bagianrow["Username"].ToString(); 
                        MessageBox.Show("Welcome!");
                        panel_mainview.Visible = true;
                        panel_loginview.Visible = false;
                        lbl_jumlahUang.Text = string.Format("Rp {0:N2}", Convert.ToInt32(bagianrow["Balance"]));
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Password");
                    }
                }
               
            }
            if (cnt == 0)
            {
                MessageBox.Show("user not found");
            }
            tb_loginViewUsername.Clear();
            tb_loginViewPassword.Clear();
        }

        private void btn_loginviewRegister_Click(object sender, EventArgs e) // Login View
        {
            panel_regisView.Visible = true;
            panel_loginview.Visible = false;
            panel_depositview.Visible = false;
            panel_mainview.Visible = false;
            panel_withdrawView.Visible = false;
        }

        private void btn_registermenu_Click(object sender, EventArgs e) // register menu
        {
            simpan_username = tb_regisUser.Text;
            simpan_password = tb_regisPassword.Text;
            bool cek = false;

            if (tb_regisPassword.Text == "" || tb_regisUser.Text == "")
            {
                MessageBox.Show("Please Field The Text");
                return;
            }
            foreach (DataRow bagianRow in UserPass.Rows)
            {
                if (bagianRow["Username"].ToString() == simpan_username)
                {
                    MessageBox.Show("Username has been used");
                    cek = true;
                }
            }

            if (!cek)
            {
                UserPass.Rows.Add(simpan_username, simpan_password, 0);
                MessageBox.Show("Register Successful");
            }
            panel_loginview.Visible = true;
            panel_regisView.Visible = false;
            panel_mainview.Visible = false;
            panel_depositview.Visible = false;

            tb_regisUser.Clear();
            tb_regisPassword.Clear();
        }

        private void btn_mainviewLogout_Click(object sender, EventArgs e) // Main View
        {
            CekBalancePerUser();
            panel_regisView.Visible = false;
            panel_loginview.Visible = true;
            panel_mainview.Visible = false;
            panel_depositview.Visible = false;
            panel_withdrawView.Visible = false;
        }
        private void btn_mainviewDeposit_Click(object sender, EventArgs e) // main view
        {
            panel_regisView.Visible = false;
            panel_loginview.Visible = false;
            panel_mainview.Visible = false;
            panel_depositview.Visible = true;
            panel_withdrawView.Visible = false;
        }
        private void btn_mainviewWithdraw_Click(object sender, EventArgs e)
        {
            panel_regisView.Visible = false;
            panel_loginview.Visible = false;
            panel_mainview.Visible = false;
            panel_depositview.Visible = false;
            panel_withdrawView.Visible = true;

            foreach (DataRow bagianrow in UserPass.Rows)
            {
                if (bagianrow["Username"].ToString() == simpanlogin)
                {
                    lbl_withdrawviewJumlahUang.Text = string.Format("Rp {0:N2}", Convert.ToInt32(bagianrow["Balance"]));
                }
            }
        }

        private void btn_DepositLogout_Click(object sender, EventArgs e) // Deposit View
        {
            CekBalancePerUser();
            panel_regisView.Visible = false;
            panel_loginview.Visible = true;
            panel_mainview.Visible = false;
            panel_depositview.Visible = false;
            panel_withdrawView.Visible = false;
        }

        private void btn_depositviewDeposit_Click(object sender, EventArgs e) // Deposit View
        {
            int inputDeposit = Convert.ToInt32(tb_depositviewInputDeposit.Text);

            if (inputDeposit > 0)
            {
                foreach (DataRow bagianrow in UserPass.Rows)
                {
                    if (bagianrow["Username"].ToString() == simpanlogin)
                    {
                        bagianrow["Balance"] = Convert.ToInt32(bagianrow["Balance"]) + inputDeposit;

                        MessageBox.Show("Successfully Add Deposit");
                        panel_depositview.Visible = false;
                        lbl_withdrawviewJumlahUang.Text = string.Format("Rp {0:N2}", Convert.ToInt32(bagianrow["Balance"]));
                        lbl_jumlahUang.Text = string.Format("Rp {0:N2}", Convert.ToInt32(bagianrow["Balance"]));
                        CekBalancePerUser();

                    }
                }
                tb_depositviewInputDeposit.Clear();
                panel_mainview.Visible = true;

            }
            else if (inputDeposit <= 0)
            {
                MessageBox.Show("Deposit Amount Cant Be Less Than 1");
            }
        }


        private void btn_withdrawviewLogout_Click(object sender, EventArgs e)
        {
            CekBalancePerUser();
            panel_regisView.Visible = false;
            panel_loginview.Visible = true;
            panel_mainview.Visible = false;
            panel_depositview.Visible = false;
            panel_withdrawView.Visible = false;
        }

        private void btn_withdrawViewWD_Click(object sender, EventArgs e)
        {
            panel_withdrawView.Visible = true;
            int inputanWithdraw = Convert.ToInt32(tb_withdrawViewInput.Text);


            if (inputanWithdraw <= 0)
            {
                MessageBox.Show("Unable to process withdrawal if the amount is 0 or negative");
                return;
            }
            foreach (DataRow bagianrow in UserPass.Rows)
            {
                if (bagianrow["Username"].ToString() == simpanlogin)
                {
                    if (inputanWithdraw <= Convert.ToInt32(bagianrow["Balance"]))
                    {
                        bagianrow["Balance"] = Convert.ToInt32(bagianrow["Balance"]) - inputanWithdraw;
                        panel_withdrawView.Visible = false;
                        lbl_withdrawviewJumlahUang.Text = string.Format("Rp {0:N2}", Convert.ToInt32(bagianrow["Balance"]));
                        lbl_jumlahUang.Text = string.Format("Rp {0:N2}", Convert.ToInt32(bagianrow["Balance"]));
                        CekBalancePerUser();
                        
                    }
                    else if (inputanWithdraw > Convert.ToInt32(bagianrow["Balance"]))
                    {
                        MessageBox.Show("Unable to withdraw if withdrawn amount is more than Balance");
                        return;
                    }
                }
            }
            tb_withdrawViewInput.Clear();
            panel_mainview.Visible = true;
        }

        private void CekBalancePerUser()
        {
            foreach (DataRow bagianrow in UserPass.Rows)
            {
                if (bagianrow["Username"].ToString() == simpanlogin)
                {
                    break;
                }
            }
        }


    }
}


