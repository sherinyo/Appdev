﻿namespace TH05_Sherin_Alvinia_Yonatan
{
    partial class toko
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_product = new System.Windows.Forms.Label();
            this.dgv_Product = new System.Windows.Forms.DataGridView();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.lbl_namaCategory = new System.Windows.Forms.Label();
            this.tb_namaCategory = new System.Windows.Forms.TextBox();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.tb_namaDetails = new System.Windows.Forms.TextBox();
            this.tb_hargaDetails = new System.Windows.Forms.TextBox();
            this.tb_stockDetails = new System.Windows.Forms.TextBox();
            this.cb_categoryDetails = new System.Windows.Forms.ComboBox();
            this.lbl_category = new System.Windows.Forms.Label();
            this.lbl_details = new System.Windows.Forms.Label();
            this.lbl_namaDetails = new System.Windows.Forms.Label();
            this.lbl_categoryDetails = new System.Windows.Forms.Label();
            this.lbl_hargaDetails = new System.Windows.Forms.Label();
            this.lbl_stockDetails = new System.Windows.Forms.Label();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.btn_editProduct = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_product
            // 
            this.lbl_product.AutoSize = true;
            this.lbl_product.BackColor = System.Drawing.Color.Transparent;
            this.lbl_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_product.Location = new System.Drawing.Point(88, 68);
            this.lbl_product.Name = "lbl_product";
            this.lbl_product.Size = new System.Drawing.Size(119, 32);
            this.lbl_product.TabIndex = 0;
            this.lbl_product.Text = "Product";
            // 
            // dgv_Product
            // 
            this.dgv_Product.AllowUserToAddRows = false;
            this.dgv_Product.AllowUserToDeleteRows = false;
            this.dgv_Product.AllowUserToResizeColumns = false;
            this.dgv_Product.AllowUserToResizeRows = false;
            this.dgv_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Product.Location = new System.Drawing.Point(93, 121);
            this.dgv_Product.Name = "dgv_Product";
            this.dgv_Product.RowHeadersWidth = 62;
            this.dgv_Product.RowTemplate.Height = 28;
            this.dgv_Product.Size = new System.Drawing.Size(532, 311);
            this.dgv_Product.TabIndex = 1;
            this.dgv_Product.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Product_CellMouseClick);
            // 
            // dgv_category
            // 
            this.dgv_category.AllowUserToAddRows = false;
            this.dgv_category.AllowUserToDeleteRows = false;
            this.dgv_category.AllowUserToResizeRows = false;
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_category.Location = new System.Drawing.Point(743, 121);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.RowHeadersWidth = 62;
            this.dgv_category.RowTemplate.Height = 28;
            this.dgv_category.Size = new System.Drawing.Size(339, 311);
            this.dgv_category.TabIndex = 2;
            this.dgv_category.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_category_CellMouseClick);
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(305, 72);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(75, 43);
            this.btn_all.TabIndex = 3;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(386, 72);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(75, 43);
            this.btn_filter.TabIndex = 4;
            this.btn_filter.Text = "Filter:";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(467, 80);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(158, 28);
            this.cb_filter.TabIndex = 5;
            this.cb_filter.SelectionChangeCommitted += new System.EventHandler(this.cb_filter_SelectionChangeCommitted);
            // 
            // lbl_namaCategory
            // 
            this.lbl_namaCategory.AutoSize = true;
            this.lbl_namaCategory.BackColor = System.Drawing.Color.Transparent;
            this.lbl_namaCategory.Location = new System.Drawing.Point(754, 465);
            this.lbl_namaCategory.Name = "lbl_namaCategory";
            this.lbl_namaCategory.Size = new System.Drawing.Size(59, 20);
            this.lbl_namaCategory.TabIndex = 7;
            this.lbl_namaCategory.Text = "Nama: ";
            // 
            // tb_namaCategory
            // 
            this.tb_namaCategory.Location = new System.Drawing.Point(855, 459);
            this.tb_namaCategory.Name = "tb_namaCategory";
            this.tb_namaCategory.Size = new System.Drawing.Size(227, 26);
            this.tb_namaCategory.TabIndex = 8;
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.BackColor = System.Drawing.Color.LawnGreen;
            this.btn_addCategory.Location = new System.Drawing.Point(877, 501);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(104, 87);
            this.btn_addCategory.TabIndex = 9;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = false;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.Red;
            this.btn_removeCategory.Location = new System.Drawing.Point(987, 501);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(95, 87);
            this.btn_removeCategory.TabIndex = 10;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // tb_namaDetails
            // 
            this.tb_namaDetails.Location = new System.Drawing.Point(234, 495);
            this.tb_namaDetails.Name = "tb_namaDetails";
            this.tb_namaDetails.Size = new System.Drawing.Size(375, 26);
            this.tb_namaDetails.TabIndex = 16;
            // 
            // tb_hargaDetails
            // 
            this.tb_hargaDetails.Location = new System.Drawing.Point(234, 581);
            this.tb_hargaDetails.Name = "tb_hargaDetails";
            this.tb_hargaDetails.Size = new System.Drawing.Size(227, 26);
            this.tb_hargaDetails.TabIndex = 17;
            this.tb_hargaDetails.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_hargaDetails_KeyPress);
            // 
            // tb_stockDetails
            // 
            this.tb_stockDetails.Location = new System.Drawing.Point(234, 619);
            this.tb_stockDetails.Name = "tb_stockDetails";
            this.tb_stockDetails.Size = new System.Drawing.Size(227, 26);
            this.tb_stockDetails.TabIndex = 18;
            this.tb_stockDetails.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stockDetails_KeyPress);
            // 
            // cb_categoryDetails
            // 
            this.cb_categoryDetails.FormattingEnabled = true;
            this.cb_categoryDetails.Location = new System.Drawing.Point(234, 537);
            this.cb_categoryDetails.Name = "cb_categoryDetails";
            this.cb_categoryDetails.Size = new System.Drawing.Size(158, 28);
            this.cb_categoryDetails.TabIndex = 19;
            // 
            // lbl_category
            // 
            this.lbl_category.AutoSize = true;
            this.lbl_category.BackColor = System.Drawing.Color.Transparent;
            this.lbl_category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.Location = new System.Drawing.Point(737, 68);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(137, 32);
            this.lbl_category.TabIndex = 23;
            this.lbl_category.Text = "Category";
            // 
            // lbl_details
            // 
            this.lbl_details.AutoSize = true;
            this.lbl_details.BackColor = System.Drawing.Color.Transparent;
            this.lbl_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_details.Location = new System.Drawing.Point(87, 452);
            this.lbl_details.Name = "lbl_details";
            this.lbl_details.Size = new System.Drawing.Size(109, 32);
            this.lbl_details.TabIndex = 24;
            this.lbl_details.Text = "Details";
            // 
            // lbl_namaDetails
            // 
            this.lbl_namaDetails.AutoSize = true;
            this.lbl_namaDetails.BackColor = System.Drawing.Color.Transparent;
            this.lbl_namaDetails.Location = new System.Drawing.Point(90, 501);
            this.lbl_namaDetails.Name = "lbl_namaDetails";
            this.lbl_namaDetails.Size = new System.Drawing.Size(59, 20);
            this.lbl_namaDetails.TabIndex = 25;
            this.lbl_namaDetails.Text = "Nama: ";
            // 
            // lbl_categoryDetails
            // 
            this.lbl_categoryDetails.AutoSize = true;
            this.lbl_categoryDetails.BackColor = System.Drawing.Color.Transparent;
            this.lbl_categoryDetails.Location = new System.Drawing.Point(89, 540);
            this.lbl_categoryDetails.Name = "lbl_categoryDetails";
            this.lbl_categoryDetails.Size = new System.Drawing.Size(77, 20);
            this.lbl_categoryDetails.TabIndex = 26;
            this.lbl_categoryDetails.Text = "Category:";
            // 
            // lbl_hargaDetails
            // 
            this.lbl_hargaDetails.AutoSize = true;
            this.lbl_hargaDetails.BackColor = System.Drawing.Color.Transparent;
            this.lbl_hargaDetails.Location = new System.Drawing.Point(90, 587);
            this.lbl_hargaDetails.Name = "lbl_hargaDetails";
            this.lbl_hargaDetails.Size = new System.Drawing.Size(57, 20);
            this.lbl_hargaDetails.TabIndex = 27;
            this.lbl_hargaDetails.Text = "Harga:";
            // 
            // lbl_stockDetails
            // 
            this.lbl_stockDetails.AutoSize = true;
            this.lbl_stockDetails.BackColor = System.Drawing.Color.Transparent;
            this.lbl_stockDetails.Location = new System.Drawing.Point(90, 625);
            this.lbl_stockDetails.Name = "lbl_stockDetails";
            this.lbl_stockDetails.Size = new System.Drawing.Size(54, 20);
            this.lbl_stockDetails.TabIndex = 28;
            this.lbl_stockDetails.Text = "Stock:";
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.BackColor = System.Drawing.Color.LawnGreen;
            this.btn_addProduct.Location = new System.Drawing.Point(301, 651);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(104, 87);
            this.btn_addProduct.TabIndex = 29;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = false;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeProduct.Location = new System.Drawing.Point(514, 651);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(95, 87);
            this.btn_removeProduct.TabIndex = 30;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = false;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // btn_editProduct
            // 
            this.btn_editProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editProduct.Location = new System.Drawing.Point(414, 651);
            this.btn_editProduct.Name = "btn_editProduct";
            this.btn_editProduct.Size = new System.Drawing.Size(94, 87);
            this.btn_editProduct.TabIndex = 31;
            this.btn_editProduct.Text = "Edit Product";
            this.btn_editProduct.UseVisualStyleBackColor = false;
            this.btn_editProduct.Click += new System.EventHandler(this.btn_editProduct_Click);
            // 
            // toko
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::TH05_Sherin_Alvinia_Yonatan.Properties.Resources.Peach_and_Brown_Modern_Abstract_Shape_Linktree_Background__1_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1196, 823);
            this.Controls.Add(this.btn_editProduct);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.lbl_stockDetails);
            this.Controls.Add(this.lbl_hargaDetails);
            this.Controls.Add(this.lbl_categoryDetails);
            this.Controls.Add(this.lbl_namaDetails);
            this.Controls.Add(this.lbl_details);
            this.Controls.Add(this.lbl_category);
            this.Controls.Add(this.cb_categoryDetails);
            this.Controls.Add(this.tb_stockDetails);
            this.Controls.Add(this.tb_hargaDetails);
            this.Controls.Add(this.tb_namaDetails);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.tb_namaCategory);
            this.Controls.Add(this.lbl_namaCategory);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.dgv_Product);
            this.Controls.Add(this.lbl_product);
            this.DoubleBuffered = true;
            this.Name = "toko";
            this.Text = "toko";
            this.Load += new System.EventHandler(this.toko_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_product;
        private System.Windows.Forms.DataGridView dgv_Product;
        private System.Windows.Forms.DataGridView dgv_category;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Label lbl_namaCategory;
        private System.Windows.Forms.TextBox tb_namaCategory;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.TextBox tb_namaDetails;
        private System.Windows.Forms.TextBox tb_hargaDetails;
        private System.Windows.Forms.TextBox tb_stockDetails;
        private System.Windows.Forms.ComboBox cb_categoryDetails;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.Label lbl_details;
        private System.Windows.Forms.Label lbl_namaDetails;
        private System.Windows.Forms.Label lbl_categoryDetails;
        private System.Windows.Forms.Label lbl_hargaDetails;
        private System.Windows.Forms.Label lbl_stockDetails;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.Button btn_editProduct;
    }
}

