﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Sherin_Alvinia_Yonatan
{
    public partial class toko : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();

        public toko()
        {
            InitializeComponent();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            // untuk filter
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");

            // data awal
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "26", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
        }

        private void toko_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                string idProduct = dtProdukSimpan.Rows[i][0].ToString();
                string namaProduct = dtProdukSimpan.Rows[i][1].ToString();
                string harga = dtProdukSimpan.Rows[i][2].ToString();
                string stock = dtProdukSimpan.Rows[i][3].ToString();
                string category = dtProdukSimpan.Rows[i][4].ToString();

                dtProdukTampil.Rows.Add(idProduct, namaProduct, harga, stock, category);
            }

            dgv_Product.DataSource = dtProdukTampil;
            dgv_category.DataSource = dtCategory;
            cb_filter.Items.Clear();
            cb_categoryDetails.Items.Clear();   

            // memasukkan Nama Category ke comboBox
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_categoryDetails.Items.Add(dtCategory.Rows[i][1].ToString());
                cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
            }

            dgv_Product.ClearSelection();
            dgv_category.ClearSelection();
        }

        private void btn_filter_Click(object sender, EventArgs e) 
        {
            cb_filter.Enabled = true;
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            cb_filter.SelectedIndex = -1;
            dtProdukTampil.Clear();


            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                string idProduct = dtProdukSimpan.Rows[i][0].ToString();
                string namaProduct = dtProdukSimpan.Rows[i][1].ToString();
                string harga = dtProdukSimpan.Rows[i][2].ToString();
                string stock = dtProdukSimpan.Rows[i][3].ToString();
                string category = dtProdukSimpan.Rows[i][4].ToString();

                dtProdukTampil.Rows.Add(idProduct, namaProduct, harga, stock, category);
            }
        }

        private void dgv_Product_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // menampilkan di details
            int indexPilih = dgv_Product .CurrentCell.RowIndex;
            string idProduct = dtProdukSimpan.Rows[indexPilih][0].ToString();
            string namaProduct = dtProdukSimpan.Rows[indexPilih][1].ToString();
            string harga = dtProdukSimpan.Rows[indexPilih][2].ToString();
            string stock = dtProdukSimpan.Rows[indexPilih][3].ToString();
            string category = dtProdukSimpan.Rows[indexPilih][4].ToString();

            tb_namaDetails.Text = namaProduct;
            tb_hargaDetails.Text = harga;
            tb_stockDetails.Text = stock;


            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == category)
                {
                    cb_categoryDetails.SelectedIndex = i;
                    break;
                }
            }
        } 

        private void dgv_category_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indexPilih = dgv_category.CurrentCell.RowIndex;
            string namaCategory = dtCategory.Rows[indexPilih][1].ToString();

            tb_namaCategory.Text = namaCategory;

        }

        private void cb_filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dtProdukTampil.Clear();

            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtCategory.Rows[cb_filter.SelectedIndex][0].ToString() == dtProdukSimpan.Rows[i][4].ToString())
                {
                    string idProduct = dtProdukSimpan.Rows[i][0].ToString();
                    string namaProduct = dtProdukSimpan.Rows[i][1].ToString();
                    string harga = dtProdukSimpan.Rows[i][2].ToString();
                    string stock = dtProdukSimpan.Rows[i][3].ToString();
                    string category = dtProdukSimpan.Rows[i][4].ToString();

                    dtProdukTampil.Rows.Add(idProduct, namaProduct, harga, stock, category);
                }
            }
        }

        private void perbarui()
        {
            dtProdukTampil.Clear();
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                string idProduct = dtProdukSimpan.Rows[i][0].ToString();
                string namaProduct = dtProdukSimpan.Rows[i][1].ToString();
                string harga = dtProdukSimpan.Rows[i][2].ToString();
                string stock = dtProdukSimpan.Rows[i][3].ToString();
                string category = dtProdukSimpan.Rows[i][4].ToString();

                dtProdukTampil.Rows.Add(idProduct, namaProduct, harga, stock, category);
            }
        }

        
        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaDetails.Text == "" || tb_stockDetails.Text == "" || tb_hargaDetails.Text == "" || cb_categoryDetails.SelectedIndex == -1)
            {
                 MessageBox.Show("Tolong input yang lengkap", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string idProductBaru = "";
                string idProduct_input = tb_namaDetails.Text.Substring(0, 1).ToUpper();
                int cnt = 0;
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString().Contains(idProduct_input + "00"))
                    {
                        cnt = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(3, 1));
                    }
                    else if (dtProdukSimpan.Rows[i][0].ToString().Contains(idProduct_input + "0"))
                    {
                        cnt = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(2, 2));
                    }
                    else if (dtProdukSimpan.Rows[i][0].ToString().Contains(idProduct_input))
                    {
                        cnt = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1, 3));
                    }
                }
                cnt = cnt + 1;

                if (cnt < 10)
                {
                   idProductBaru = idProduct_input + "00" + cnt.ToString();
                }
                else if (cnt < 100)
                {
                    idProductBaru = idProduct_input + "0" + cnt.ToString();
                }
                else
                {
                    idProductBaru = idProduct_input + cnt.ToString();
                }

                int kategoriAdd = cb_categoryDetails.SelectedIndex;


                
                dtProdukSimpan.Rows.Add(idProductBaru, tb_namaDetails.Text, tb_hargaDetails.Text, tb_stockDetails.Text, dtCategory.Rows[kategoriAdd][0].ToString());
                perbarui();
                tb_namaDetails.Clear();
                tb_hargaDetails.Clear();
                tb_stockDetails.Clear();
                cb_filter.Text = "";
                cb_categoryDetails.SelectedIndex = -1;
            }
        }

        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaDetails.Text == "" || tb_stockDetails.Text == "" || tb_hargaDetails.Text == "" || dgv_Product.SelectedCells.Count == 0)
            {
                MessageBox.Show("Tolong pilih row bro", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int indexPilih = dgv_Product.CurrentCell.RowIndex;
                string idProduct = dtProdukTampil.Rows[indexPilih][0].ToString();
                string namaProduct = tb_namaDetails.Text;
                string harga = tb_hargaDetails.Text;
                string stock = tb_stockDetails.Text;
                string category = "";
                string kategoriBaru = cb_categoryDetails.SelectedItem.ToString();
                foreach(DataRow dr in dtCategory.Rows)
                {
                    if (dr[1].ToString() == kategoriBaru)
                    {
                        category = dr[0].ToString();
                    }
                }


                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == idProduct)
                    {
                        dtProdukSimpan.Rows[i][1] = namaProduct;
                        dtProdukSimpan.Rows[i][2] = harga;
                        dtProdukSimpan.Rows[i][3] = stock;
                        dtProdukSimpan.Rows[i][4] = category;

                        if (tb_stockDetails.Text == "0")
                        {
                            dtProdukSimpan.Rows[i].Delete();
                        }
                        break;
                    }
                }
                
            }
            perbarui();
            tb_namaDetails.Clear();
            tb_hargaDetails.Clear();
            tb_stockDetails.Clear();
            cb_categoryDetails.SelectedIndex = -1;
        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (tb_namaDetails.Text == "" || tb_stockDetails.Text == "" || tb_hargaDetails.Text == "" || cb_categoryDetails.SelectedIndex == -1)
            {
                tb_namaDetails.Clear();
                //MessageBox.Show("Tolong input yang lengkap", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int indexPilih = dgv_Product.CurrentCell.RowIndex;
                string idProduct = dtProdukTampil.Rows[indexPilih][0].ToString();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == idProduct)
                    {
                        dtProdukSimpan.Rows[i].Delete();
                    }
                }
                dtProdukTampil.Clear();
                perbarui();
                tb_hargaDetails.Clear();
                tb_namaDetails.Clear();
                tb_stockDetails.Clear();
                cb_categoryDetails.SelectedIndex = -1;
            }
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            if (tb_namaCategory.Text == "")
            {
                MessageBox.Show("Tolong input sesuatu hhh", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool cek = true;

                foreach (DataRow row in dtCategory.Rows)
                {
                    if (row["Nama category"].ToString() == tb_namaCategory.Text.ToString())
                    {
                        cek = false;
                        break;
                    }
                } 

                if (cek)
                {
                    int newID = 0;
                    if (dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Length == 2)
                    {
                        newID = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 1));
                    }
                    else if (dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Length == 3)
                    {
                        newID = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 2));
                    }
                    else
                    {
                        newID = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1, 3));
                    }
                    newID = newID + 1;

                    string tambah = "C" + newID.ToString();
                    dtCategory.Rows.Add(tambah, tb_namaCategory.Text);
                    cb_categoryDetails.Items.Add(tb_namaCategory.Text);
                    cb_filter.Items.Add(tb_namaCategory.Text);
                }
                else
                {
                    MessageBox.Show("Nama kategori sudah tersedia, isi yang lain", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                tb_namaCategory.Clear();
            }
        }

        bool remove = false;
        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            if (dgv_category.SelectedCells.Count != 0)
            {
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][4].ToString() == dtCategory.Rows[dgv_category.CurrentCell.RowIndex][0].ToString())
                    {
                        dtProdukSimpan.Rows[i].Delete();
                        i = 0;
                    }
                }
                dtCategory.Rows[dgv_category.CurrentCell.RowIndex].Delete();
                cb_categoryDetails.SelectedIndex = -1;
                cb_filter.SelectedIndex = -1;
                perbarui();
                cb_categoryDetails.Items.Clear();
                cb_filter.Items.Clear();

                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    cb_categoryDetails.Items.Add(dtCategory.Rows[i][1].ToString());
                    cb_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                }
                tb_namaCategory.Clear();
            }
            else 
            {
                remove = true;
                MessageBox.Show("Tolong pilih row", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_namaCategory.Clear();
            }
        }


        private void tb_hargaDetails_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void tb_stockDetails_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
